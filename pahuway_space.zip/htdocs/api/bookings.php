<?php

session_start();

require_once "db.php";
require_once "property_helpers.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "You must be logged in."
    ]);
    exit;
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT
        bookings.booking_id,
        bookings.property_id,
        bookings.total_amount,
        properties.property_code,
        properties.title,
        cities.city_name AS location,
        (SELECT pi.image_path
           FROM property_images pi
          WHERE pi.property_id = properties.property_id
          ORDER BY pi.is_primary DESC, pi.sort_order ASC, pi.image_id ASC
          LIMIT 1) AS image,
        properties.price_unit,
        bookings.check_in,
        bookings.check_out,
        bookings.guests,
        bookings.total_amount,
        bookings.booking_status,
        bookings.created_at
     FROM bookings
     INNER JOIN properties
        ON bookings.property_id = properties.property_id
     INNER JOIN cities
        ON properties.city_id = cities.city_id
     WHERE bookings.user_id = ?
     ORDER BY bookings.created_at DESC, bookings.booking_id DESC"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

$bookings = [];

while ($row = $result->fetch_assoc()) {
    $bookings[] = [
        "booking_id" => (int) $row["booking_id"],
        "property_id" => (int) $row["property_id"],
        "property_code" => $row["property_code"],
        "title" => $row["title"],
        "location" => $row["location"],
        "image" => $row["image"] ?? "",
        "price_unit" => $row["price_unit"],
        "check_in" => $row["check_in"],
        "check_out" => checkout_for_api($row["check_out"]),
        "guests" => (int) $row["guests"],
        "nights" => booking_nights($row["check_in"], $row["check_out"]),
        "total_amount" => (float) $row["total_amount"],
        "booking_status" => $row["booking_status"],
        "created_at" => $row["created_at"]
    ];
}

echo json_encode([
    "success" => true,
    "bookings" => $bookings
]);

$stmt->close();
$conn->close();

?>
