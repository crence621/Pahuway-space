<?php

/*
 * Shared helpers for the normalized schema.
 *
 * The database is split into lookup tables (property_types, cities, amenities,
 * utilities, roles, payment_methods) and link tables (property_amenities,
 * property_utilities, property_images). The front end still expects the
 * original flat JSON (property_type, location, image, amenities[],
 * electricity_included, parking_nearby ...), so everything here flattens the
 * normalized rows back into that shape. Nothing in the HTML/JS needs to change.
 */

/*
 * The database has no NULLs. "Not provided" is stored as a placeholder, and the
 * API turns the placeholder back into an empty value so the front end (and the
 * edit form) never sees it. These must match the DEFAULTs in the SQL schema.
 */
const PH_DESCRIPTION = "No description provided";
const PH_AREA = "N/A";
const PH_PET_CONDITIONS = "None";
const PH_NO_CHECKOUT = "Not checked out";   // open-ended (monthly) stay
const PH_NOT_PAID = "Not paid";

/* Utility coverage <-> the 0 / 1 / 2 numbers the front end uses.
 *   1 = covered by rent, 0 = paid separately, 2 = not available */
const UTILITY_CODES = ["electricity", "water", "internet"];

function coverage_to_int(string $coverage): int
{
    if ($coverage === "included") return 1;
    if ($coverage === "unavailable") return 2;
    return 0;
}

function int_to_coverage(int $value): string
{
    if ($value === 1) return "included";
    if ($value === 2) return "unavailable";
    return "separate";
}

/* Prepare + bind + execute in one go. Throws on any failure so callers can roll back. */
function db_run(mysqli $conn, string $sql, string $types = "", array $params = []): mysqli_stmt
{
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException("Database error: " . $conn->error);
    }
    if ($types !== "") {
        $stmt->bind_param($types, ...$params);
    }
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException("Database error: " . $err);
    }
    return $stmt;
}

/*
 * One property per row, with type and city joined in and the primary image
 * picked. Column aliases match the old flat table, so rows can be used as-is.
 * Append your own WHERE / ORDER BY.
 */
function property_select_sql(string $extra_columns = "", string $extra_joins = ""): string
{
    return "SELECT
                $extra_columns
                p.property_id,
                p.owner_id,
                p.property_code,
                t.type_name AS property_type,
                p.title,
                c.city_name AS location,
                p.description,
                p.price,
                p.price_unit,
                p.bedrooms,
                p.bathrooms,
                p.area,
                (SELECT pi.image_path
                   FROM property_images pi
                  WHERE pi.property_id = p.property_id
                  ORDER BY pi.is_primary DESC, pi.sort_order ASC, pi.image_id ASC
                  LIMIT 1) AS image,
                p.verified,
                p.status,
                p.pets_allowed,
                p.pet_conditions,
                (p.parking <> 'none') AS parking_nearby,
                IF(p.parking = 'none', NULL, p.parking) AS parking_fee,
                p.created_at
            FROM properties p
            INNER JOIN property_types t ON t.type_id = p.type_id
            INNER JOIN cities c ON c.city_id = p.city_id
            $extra_joins";
}

/*
 * Adds amenities[] and the three *_included numbers to a list of property rows
 * (two small queries for the whole list, not two per property).
 */
function attach_property_extras(mysqli $conn, array &$rows): void
{
    $ids = [];
    foreach ($rows as $i => $row) {
        $ids[] = (int) $row["property_id"];
        $rows[$i]["amenities"] = [];
        $rows[$i]["electricity_included"] = 0;
        $rows[$i]["water_included"] = 0;
        $rows[$i]["internet_included"] = 0;
    }

    if (!$ids) return;

    $index = [];
    foreach ($rows as $i => $row) {
        $index[(int) $row["property_id"]] = $i;
    }

    $in = implode(",", array_unique($ids)); // ints only

    $res = $conn->query(
        "SELECT pa.property_id, a.amenity_code
           FROM property_amenities pa
           INNER JOIN amenities a ON a.amenity_id = pa.amenity_id
          WHERE pa.property_id IN ($in)
          ORDER BY a.amenity_id ASC"
    );
    while ($res && ($r = $res->fetch_assoc())) {
        $rows[$index[(int) $r["property_id"]]]["amenities"][] = $r["amenity_code"];
    }

    $res = $conn->query(
        "SELECT pu.property_id, u.utility_code, pu.coverage
           FROM property_utilities pu
           INNER JOIN utilities u ON u.utility_id = pu.utility_id
          WHERE pu.property_id IN ($in)"
    );
    while ($res && ($r = $res->fetch_assoc())) {
        $key = $r["utility_code"] . "_included";
        if (in_array($r["utility_code"], UTILITY_CODES, true)) {
            $rows[$index[(int) $r["property_id"]]][$key] = coverage_to_int($r["coverage"]);
        }
    }
}

/* Cast the common fields the same way the old endpoints did. */
function cast_property_row(array $row): array
{
    $row["property_id"] = (int) $row["property_id"];
    if (isset($row["owner_id"])) $row["owner_id"] = (int) $row["owner_id"];
    $row["price"] = (float) $row["price"];
    $row["bedrooms"] = (int) $row["bedrooms"];
    $row["bathrooms"] = (int) $row["bathrooms"];
    if (isset($row["verified"])) $row["verified"] = (bool) $row["verified"];
    $row["pets_allowed"] = (bool) $row["pets_allowed"];
    $row["parking_nearby"] = (bool) $row["parking_nearby"];
    $row["image"] = $row["image"] ?? "";
    $row["description"] = ($row["description"] === PH_DESCRIPTION) ? "" : (string) $row["description"];
    if (array_key_exists("area", $row)) {
        $row["area"] = ($row["area"] === PH_AREA) ? "" : (string) $row["area"];
    }
    if (array_key_exists("pet_conditions", $row)) {
        $row["pet_conditions"] = ($row["pet_conditions"] === PH_PET_CONDITIONS) ? null : $row["pet_conditions"];
    }
    return $row;
}

/* id of the property type with this name, or 0 when it is not in the table. */
function property_type_id(mysqli $conn, string $name): int
{
    $stmt = db_run($conn, "SELECT type_id FROM property_types WHERE type_name = ? LIMIT 1", "s", [$name]);
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ? (int) $row["type_id"] : 0;
}

/* id of the city/location, creating it the first time it is used. */
function city_id_for(mysqli $conn, string $name): int
{
    $name = mb_substr(trim($name), 0, 255);

    $stmt = db_run(
        $conn,
        "INSERT INTO cities (city_name) VALUES (?)
         ON DUPLICATE KEY UPDATE city_id = LAST_INSERT_ID(city_id)",
        "s",
        [$name]
    );
    $id = (int) $stmt->insert_id;
    $stmt->close();
    return $id;
}

/* Combine the old two form fields into the single parking value. */
function parking_value(bool $nearby, ?string $fee): string
{
    if (!$nearby) return "none";
    return $fee === "paid" ? "paid" : "free";
}

/*
 * Replace a property's amenities, utilities and (optionally) primary image.
 * $utilities is e.g. ["electricity" => 1, "water" => 0, "internet" => 2].
 * $image: "" leaves the current image alone.

 * Call inside a transaction.
 */
function save_property_relations(
    mysqli $conn,
    int $property_id,
    array $amenity_codes,
    array $utilities,
    string $image
): void {

    db_run($conn, "DELETE FROM property_amenities WHERE property_id = ?", "i", [$property_id])->close();

    foreach (array_unique($amenity_codes) as $code) {
        db_run(
            $conn,
            "INSERT IGNORE INTO property_amenities (property_id, amenity_id)
             SELECT ?, amenity_id FROM amenities WHERE amenity_code = ?",
            "is",
            [$property_id, $code]
        )->close();
    }

    foreach (UTILITY_CODES as $code) {
        $coverage = int_to_coverage((int) ($utilities[$code] ?? 0));
        db_run(
            $conn,
            "INSERT INTO property_utilities (property_id, utility_id, coverage)
             SELECT ?, utility_id, ? FROM utilities WHERE utility_code = ?
             ON DUPLICATE KEY UPDATE coverage = VALUES(coverage)",
            "iss",
            [$property_id, $coverage, $code]
        )->close();
    }

    if ($image !== "") {
        db_run($conn, "DELETE FROM property_images WHERE property_id = ? AND is_primary = 1", "i", [$property_id])->close();
        db_run(
            $conn,
            "INSERT INTO property_images (property_id, image_path, is_primary, sort_order)
             VALUES (?, ?, 1, 0)",
            "is",
            [$property_id, mb_substr($image, 0, 255)]
        )->close();
    }
}

/*
 * Property photo upload
 *
 * Reads the file posted as "image_file", checks it really is a JPG / PNG / WebP
 * picture under 5 MB, and saves it under assets/uploads/properties/ with a random
 * name. Returns the site-relative path (what is stored in property_images), or
 * null when no file was sent. Throws UploadException with a user-facing message.
 */
class UploadException extends RuntimeException {}

const UPLOAD_DIR = "assets/uploads/properties/";
const UPLOAD_MAX_BYTES = 5 * 1024 * 1024;

function handle_image_upload(string $field = "image_file"): ?string
{
    if (!isset($_FILES[$field]) || $_FILES[$field]["error"] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $file = $_FILES[$field];

    if ($file["error"] === UPLOAD_ERR_INI_SIZE || $file["error"] === UPLOAD_ERR_FORM_SIZE) {
        throw new UploadException("That image is too large. Please choose one under 2 MB.");
    }
    if ($file["error"] !== UPLOAD_ERR_OK) {
        throw new UploadException("The image could not be uploaded. Please try again.");
    }
    if ($file["size"] > UPLOAD_MAX_BYTES) {
        throw new UploadException("That image is too large. Please choose one under 5 MB.");
    }
    if (!is_uploaded_file($file["tmp_name"])) {
        throw new UploadException("The image could not be uploaded. Please try again.");
    }

    // Look at the real file contents, not the name or the browser's claimed type.
    $info = @getimagesize($file["tmp_name"]);
    $types = [
        IMAGETYPE_JPEG => "jpg",
        IMAGETYPE_PNG => "png",
        IMAGETYPE_WEBP => "webp"
    ];

    if (!$info || !isset($types[$info[2]])) {
        throw new UploadException("Please upload a JPG, PNG or WebP image.");
    }

    $dir = __DIR__ . "/../" . UPLOAD_DIR;

    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        throw new UploadException("The server could not save the image.");
    }

    $name = bin2hex(random_bytes(10)) . "." . $types[$info[2]];

    if (!move_uploaded_file($file["tmp_name"], $dir . $name)) {
        throw new UploadException("The server could not save the image.");
    }

    return UPLOAD_DIR . $name;
}

/* Delete an uploaded photo from disk (only ever files inside the uploads folder). */
function delete_uploaded_image(?string $path): void
{
    if (!$path || strpos($path, UPLOAD_DIR) !== 0 || strpos($path, "..") !== false) return;
    $full = __DIR__ . "/../" . $path;
    if (is_file($full)) @unlink($full);
}

/* The stored check-out placeholder means "no check-out date": the API sends null. */
function checkout_for_api(?string $check_out): ?string
{
    return ($check_out === null || $check_out === PH_NO_CHECKOUT) ? null : $check_out;
}

/* Whole days between two dates; 0 when there is no check-out (monthly stays). */
function booking_nights(?string $check_in, ?string $check_out): int
{
    $check_out = checkout_for_api($check_out);
    if (!$check_in || !$check_out) return 0;
    $a = DateTime::createFromFormat("Y-m-d", $check_in);
    $b = DateTime::createFromFormat("Y-m-d", $check_out);
    if (!$a || !$b) return 0;
    return max(0, (int) $a->diff($b)->days);
}

?>
