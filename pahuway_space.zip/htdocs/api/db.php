
<?php
 
/*
 * Any uncaught error (e.g. a missing column) used to give an empty 500 page,
 * which the front end could not read. Return it as JSON instead.
 */
ini_set("display_errors", "0");
set_exception_handler(function ($e) {
    error_log("[pahuway] " . $e->getMessage());
    if (!headers_sent()) {
        http_response_code(500);
        header("Content-Type: application/json");
    }
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
});
 
// InfinityFree MySQL credentials
$host = "sql304.infinityfree.com";
$username = "if0_43236778";
$password = "raritymlp12345";
$database = "if0_43236778_pahuway_space";
 
$conn = new mysqli($host, $username, $password, $database);
 
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
 
$conn->set_charset("utf8mb4");
 
?>