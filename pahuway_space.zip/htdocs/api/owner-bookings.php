<?php

session_start();

require_once "db.php";
require_once "property_helpers.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "You must be logged in."
    ]);
    exit;
}

$owner_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT
        bookings.booking_id,
        bookings.property_id,
        bookings.total_amount,
        properties.property_code,
        properties.title,
        cities.city_name AS location,
        (SELECT pi.image_path
           FROM property_images pi
          WHERE pi.property_id = properties.property_id
          ORDER BY pi.is_primary DESC, pi.sort_order ASC, pi.image_id ASC
          LIMIT 1) AS image,
        properties.price_unit,
        bookings.user_id AS guest_id,
        guests.full_name AS guest_name,
        guests.email AS guest_email,
        bookings.check_in,
        bookings.check_out,
        bookings.guests,
        bookings.total_amount,
        bookings.booking_status,
        bookings.created_at
     FROM bookings
     INNER JOIN properties
        ON bookings.property_id = properties.property_id
     INNER JOIN cities
        ON properties.city_id = cities.city_id
     INNER JOIN users AS guests
        ON bookings.user_id = guests.user_id
     WHERE properties.owner_id = ?
     ORDER BY bookings.created_at DESC, bookings.booking_id DESC"
);

$stmt->bind_param("i", $owner_id);
$stmt->execute();

$result = $stmt->get_result();

$bookings = [];

while ($row = $result->fetch_assoc()) {
    $bookings[] = [
        "booking_id" => (int) $row["booking_id"],
        "property_id" => (int) $row["property_id"],
        "property_code" => $row["property_code"],
        "title" => $row["title"],
        "location" => $row["location"],
        "image" => $row["image"] ?? "",
        "price_unit" => $row["price_unit"],
        "guest_id" => (int) $row["guest_id"],
        "guest_name" => $row["guest_name"],
        "guest_email" => $row["guest_email"],
        "check_in" => $row["check_in"],
        "check_out" => checkout_for_api($row["check_out"]),
        "guests" => (int) $row["guests"],
        "nights" => booking_nights($row["check_in"], $row["check_out"]),
        "total_amount" => (float) $row["total_amount"],
        "booking_status" => $row["booking_status"],
        "created_at" => $row["created_at"]
    ];
}

echo json_encode([
    "success" => true,
    "bookings" => $bookings
]);

$stmt->close();
$conn->close();

?>
