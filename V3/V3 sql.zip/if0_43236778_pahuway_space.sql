-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql304.infinityfree.com
-- Generation Time: Nov 06, 2026 at 05:09 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43236778_pahuway_space`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_otp`
--

CREATE TABLE `admin_otp` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `salt` char(32) NOT NULL,
  `code_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_otp`
--

INSERT INTO `admin_otp` (`user_id`, `salt`, `code_hash`, `expires_at`, `attempts`, `sent_at`) VALUES
(1, 'bdc92a39eea605d96e339a16b3709ea1', '2060642f05ef13f0c463eb6f36f3592778e3cea8d04e2f06dec730e8ef30ff04', '2026-11-02 06:25:13', 0, '2026-11-02 14:15:13');

-- --------------------------------------------------------

--
-- Table structure for table `amenities`
--

CREATE TABLE `amenities` (
  `amenity_id` smallint(5) UNSIGNED NOT NULL,
  `amenity_code` varchar(50) NOT NULL,
  `amenity_name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amenities`
--

INSERT INTO `amenities` (`amenity_id`, `amenity_code`, `amenity_name`) VALUES
(1, 'aircon', 'Air conditioning'),
(2, 'heating', 'Heating'),
(3, 'refrigerator', 'Refrigerator'),
(4, 'microwave', 'Microwave'),
(5, 'washing_machine', 'Washing machine'),
(6, 'tv', 'Television');

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `actor_id` int(10) UNSIGNED DEFAULT NULL,
  `actor_name` varchar(150) NOT NULL DEFAULT 'Guest',
  `category` enum('auth','security','admin') NOT NULL,
  `action` varchar(40) NOT NULL,
  `target_type` varchar(30) DEFAULT NULL,
  `target_id` int(10) UNSIGNED DEFAULT NULL,
  `summary` varchar(255) NOT NULL,
  `ip` varchar(45) NOT NULL DEFAULT '',
  `result` enum('success','failure') NOT NULL DEFAULT 'success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`log_id`, `created_at`, `actor_id`, `actor_name`, `category`, `action`, `target_type`, `target_id`, `summary`, `ip`, `result`) VALUES
(1, '2026-10-29 11:40:40', 1, 'clarence, i.', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.19', 'success'),
(2, '2026-10-29 11:42:12', 1, 'clarence, i.', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.19', 'success'),
(3, '2026-10-29 11:42:23', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.19', 'success'),
(4, '2026-10-29 11:42:43', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.19', 'success'),
(5, '2026-10-29 11:43:02', 13, 'hottog', 'security', 'unlock_failed', NULL, NULL, 'Wrong password for the admin panel', '136.158.42.19', 'failure'),
(6, '2026-10-29 11:43:16', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.19', 'success'),
(7, '2026-10-29 11:58:17', 13, 'hottog', 'admin', 'verify_change', 'user', 10, 'Verified user Peter Ferrer Ramizares (#10)', '136.158.42.19', 'success'),
(8, '2026-10-29 11:58:18', 13, 'hottog', 'admin', 'verify_change', 'user', 10, 'Unverified user Peter Ferrer Ramizares (#10)', '136.158.42.19', 'success'),
(9, '2026-10-29 12:18:01', 13, 'hottog', 'admin', 'export', NULL, NULL, 'Downloaded dashboard report (full) for Week: 26 Oct – 1 Nov 2026', '136.158.42.19', 'success'),
(10, '2026-10-29 12:42:38', 13, 'hottog', 'security', 'panel_locked', NULL, NULL, 'Admin panel locked manually', '136.158.42.19', 'success'),
(11, '2026-10-29 13:08:25', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.121.37', 'success'),
(12, '2026-10-29 13:08:51', 2, 'Peter Linus R Ferrer', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.121.37', 'success'),
(13, '2026-10-29 13:10:52', 2, 'Peter Linus R Ferrer', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.121.37', 'success'),
(14, '2026-10-29 13:11:06', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.19', 'success'),
(15, '2026-10-29 13:11:27', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.19', 'success'),
(16, '2026-10-29 13:11:41', 2, 'Peter Linus R Ferrer', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.121.37', 'success'),
(17, '2026-10-29 13:30:22', 2, 'Peter Linus R Ferrer', 'admin', 'verify_change', 'property', 54, 'Unverified property Modern townhouse in gated community, Antipolo (#54)', '112.211.121.37', 'success'),
(18, '2026-10-29 13:30:24', 2, 'Peter Linus R Ferrer', 'admin', 'verify_change', 'property', 54, 'Verified property Modern townhouse in gated community, Antipolo (#54)', '112.211.121.37', 'success'),
(19, '2026-10-29 13:30:26', 2, 'Peter Linus R Ferrer', 'admin', 'verify_change', 'property', 54, 'Unverified property Modern townhouse in gated community, Antipolo (#54)', '112.211.121.37', 'success'),
(20, '2026-10-29 13:30:31', 2, 'Peter Linus R Ferrer', 'admin', 'verify_change', 'property', 54, 'Verified property Modern townhouse in gated community, Antipolo (#54)', '112.211.121.37', 'success'),
(21, '2026-10-29 13:30:32', 2, 'Peter Linus R Ferrer', 'admin', 'verify_change', 'property', 54, 'Unverified property Modern townhouse in gated community, Antipolo (#54)', '112.211.121.37', 'success'),
(22, '2026-10-29 13:30:39', 2, 'Peter Linus R Ferrer', 'admin', 'verify_change', 'property', 54, 'Verified property Modern townhouse in gated community, Antipolo (#54)', '112.211.121.37', 'success'),
(23, '2026-10-29 13:45:16', 15, 'MARY BLESS BERBOSIDAD', 'auth', 'login_success', NULL, NULL, 'Signed in', '138.84.137.93', 'success'),
(24, '2026-10-29 15:09:04', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.19', 'success'),
(25, '2026-10-29 15:09:31', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.19', 'success'),
(26, '2026-11-01 00:46:57', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(27, '2026-11-02 01:43:16', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(28, '2026-11-02 08:24:40', 1, 'clarence, i.', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.62', 'success'),
(29, '2026-11-02 08:44:50', 1, 'clarence, i.', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.62', 'success'),
(30, '2026-11-02 10:19:31', 9, 'Gale Nuez', 'auth', 'logout', NULL, NULL, 'Signed out', '112.211.125.48', 'success'),
(31, '2026-11-02 10:20:50', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(32, '2026-11-02 10:23:04', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(33, '2026-11-02 13:57:25', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.121.37', 'success'),
(34, '2026-11-02 13:57:57', 2, 'Peter Linus R Ferrer', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.121.37', 'success'),
(35, '2026-11-02 13:58:41', 2, 'Peter Linus R Ferrer', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.121.37', 'success'),
(36, '2026-11-02 14:00:19', 2, 'Peter Linus R Ferrer', 'admin', 'export', NULL, NULL, 'Downloaded dashboard report (full) for All time: All time', '112.211.121.37', 'success'),
(37, '2026-11-02 14:14:43', 1, 'clarence, i.', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.62', 'success'),
(38, '2026-11-02 14:15:15', 1, 'clarence, i.', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.62', 'success'),
(39, '2026-11-02 14:15:57', 1, 'clarence, i.', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.62', 'success'),
(40, '2026-11-02 14:16:32', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(41, '2026-11-02 14:16:35', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(42, '2026-11-02 14:16:43', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(43, '2026-11-02 14:16:46', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(44, '2026-11-02 14:16:46', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(45, '2026-11-02 14:16:47', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(46, '2026-11-02 14:16:48', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(47, '2026-11-02 14:16:49', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(48, '2026-11-02 14:16:53', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(49, '2026-11-02 14:36:35', 1, 'clarence, i.', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.62', 'success'),
(50, '2026-11-02 14:36:44', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(51, '2026-11-02 14:36:54', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.62', 'success'),
(52, '2026-11-02 14:37:13', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.62', 'success'),
(53, '2026-11-02 14:37:41', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.62', 'success'),
(54, '2026-11-02 15:03:41', 13, 'hottog', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.62', 'success'),
(55, '2026-11-02 15:04:12', 1, 'clarence, i.', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.62', 'success'),
(56, '2026-11-02 15:41:02', 1, 'clarence, i.', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.62', 'success'),
(57, '2026-11-02 15:42:12', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.62', 'failure'),
(58, '2026-11-02 15:42:23', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.62', 'success'),
(59, '2026-11-02 15:42:36', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.62', 'success'),
(60, '2026-11-02 15:43:03', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.62', 'success'),
(61, '2026-11-03 04:44:29', 17, 'MARY BLESS BERBOSIDAD', 'auth', 'login_success', NULL, NULL, 'Signed in', '138.84.137.93', 'success'),
(62, '2026-11-03 07:12:32', 18, 'Michaela Merez', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.59.227', 'success'),
(63, '2026-11-03 07:20:58', 19, 'Loria, Kathrine Denise A.', 'auth', 'login_failed', NULL, NULL, 'Failed login for kthrinedenise@gmail.com (wrong password)', '209.35.161.13', 'failure'),
(64, '2026-11-03 07:21:10', 19, 'Loria, Kathrine Denise A.', 'auth', 'login_success', NULL, NULL, 'Signed in', '209.35.161.13', 'success'),
(65, '2026-11-03 07:25:26', 20, 'Ghian Andrei J. Cruz', 'auth', 'login_success', NULL, NULL, 'Signed in', '175.158.221.183', 'success'),
(66, '2026-11-03 07:40:06', 22, 'Reece Arron Aguanta', 'auth', 'login_failed', NULL, NULL, 'Failed login for reecearroncaguanta@gmail.com (wrong password)', '209.35.163.69', 'failure'),
(67, '2026-11-03 07:40:09', 22, 'Reece Arron Aguanta', 'auth', 'login_failed', NULL, NULL, 'Failed login for reecearroncaguanta@gmail.com (wrong password)', '209.35.163.69', 'failure'),
(68, '2026-11-03 07:40:48', 22, 'Reece Arron Aguanta', 'auth', 'login_success', NULL, NULL, 'Signed in', '209.35.163.69', 'success'),
(69, '2026-11-03 07:42:04', 23, 'Christine Espino', 'auth', 'login_success', NULL, NULL, 'Signed in', '113.19.143.100', 'success'),
(70, '2026-11-03 07:45:38', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for bebiyayadelapena@gmail.com (no such account)', '138.84.155.30', 'failure'),
(71, '2026-11-03 07:45:58', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for bebiyayadelapena@gmail.com (no such account)', '138.84.155.30', 'failure'),
(72, '2026-11-03 07:46:11', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for bebiyayadelapena@gmail.com (no such account)', '138.84.155.30', 'failure'),
(73, '2026-11-03 07:46:18', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for bebiyayadelapena@gmail.com (no such account)', '138.84.155.30', 'failure'),
(74, '2026-11-03 07:48:17', 24, 'Bebiyaya Dela Peña', 'auth', 'login_success', NULL, NULL, 'Signed in', '138.84.155.30', 'success'),
(75, '2026-11-03 08:34:06', 25, 'Angelo Ramos', 'auth', 'login_success', NULL, NULL, 'Signed in', '131.226.105.208', 'success'),
(76, '2026-11-03 11:08:28', 17, 'MARY BLESS BERBOSIDAD', 'auth', 'login_success', NULL, NULL, 'Signed in', '138.84.137.93', 'success'),
(77, '2026-11-03 12:01:31', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(78, '2026-11-03 12:01:53', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(79, '2026-11-03 12:02:14', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.220', 'success'),
(80, '2026-11-03 12:02:45', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.220', 'success'),
(81, '2026-11-03 12:03:23', 13, 'hottog', 'admin', 'verify_change', 'user', 21, 'Verified user Cabrera, Khimberly Rhein O. (#21)', '136.158.42.220', 'success'),
(82, '2026-11-03 12:03:25', 13, 'hottog', 'admin', 'verify_change', 'user', 16, 'Verified user gale nuez (#16)', '136.158.42.220', 'success'),
(83, '2026-11-03 12:03:36', 13, 'hottog', 'admin', 'verify_change', 'user', 10, 'Verified user Peter Ferrer Ramizares (#10)', '136.158.42.220', 'success'),
(84, '2026-11-03 12:04:05', 13, 'hottog', 'admin', 'role_change', 'user', 9, 'Changed role of user Gale Nuez (#9): user → admin', '136.158.42.220', 'success'),
(85, '2026-11-03 12:04:55', 13, 'hottog', 'admin', 'status_change', 'property', 4, 'Changed status of property Test3 - Image (#4): available → inactive', '136.158.42.220', 'success'),
(86, '2026-11-03 12:04:56', 13, 'hottog', 'admin', 'status_change', 'property', 3, 'Changed status of property Test2 (#3): available → inactive', '136.158.42.220', 'success'),
(87, '2026-11-03 12:04:58', 13, 'hottog', 'admin', 'status_change', 'property', 1, 'Changed status of property Test (#1): available → inactive', '136.158.42.220', 'success'),
(88, '2026-11-03 12:05:14', 13, 'hottog', 'admin', 'delete', 'payment', 2, 'Deleted payment #2 (booking #2)', '136.158.42.220', 'success'),
(89, '2026-11-03 12:05:19', 13, 'hottog', 'admin', 'delete', 'payment', 1, 'Deleted payment #1 (booking #1)', '136.158.42.220', 'success'),
(90, '2026-11-03 12:05:33', 13, 'hottog', 'admin', 'delete', 'booking', 6, 'Deleted booking #6 (Test3 - Image)', '136.158.42.220', 'success'),
(91, '2026-11-03 12:05:44', 13, 'hottog', 'admin', 'delete', 'booking', 1, 'Deleted booking #1 (Test)', '136.158.42.220', 'success'),
(92, '2026-11-03 12:05:50', 13, 'hottog', 'admin', 'delete', 'booking', 2, 'Deleted booking #2 (Test2)', '136.158.42.220', 'success'),
(93, '2026-11-03 12:05:57', 13, 'hottog', 'admin', 'delete', 'booking', 3, 'Deleted booking #3 (Test3 - Image)', '136.158.42.220', 'success'),
(94, '2026-11-03 12:06:21', 13, 'hottog', 'admin', 'delete', 'property', 4, 'Deleted property Test3 - Image (#4)', '136.158.42.220', 'success'),
(95, '2026-11-03 12:06:26', 13, 'hottog', 'admin', 'delete', 'property', 3, 'Deleted property Test2 (#3)', '136.158.42.220', 'success'),
(96, '2026-11-03 12:06:31', 13, 'hottog', 'admin', 'delete', 'property', 1, 'Deleted property Test (#1)', '136.158.42.220', 'success'),
(97, '2026-11-03 12:06:53', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.125.48', 'success'),
(98, '2026-11-03 12:07:17', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.125.48', 'success'),
(99, '2026-11-03 12:09:37', 27, 'Paul Peter', 'auth', 'login_failed', NULL, NULL, 'Login blocked for paulpeter@gmail.com (email not verified)', '136.158.59.217', 'failure'),
(100, '2026-11-03 12:09:54', 26, 'Francis Balce', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.56.71', 'success'),
(101, '2026-11-03 12:10:06', 9, 'Gale Nuez', 'auth', 'logout', NULL, NULL, 'Signed out', '112.211.125.48', 'success'),
(102, '2026-11-03 12:10:20', 13, 'hottog', 'security', 'panel_locked', NULL, NULL, 'Admin panel locked manually', '136.158.42.220', 'success'),
(103, '2026-11-03 12:11:15', 28, 'Paul Peter Garcia', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.59.217', 'success'),
(104, '2026-11-03 12:20:56', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(105, '2026-11-03 12:21:21', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.125.48', 'success'),
(106, '2026-11-03 12:21:38', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.125.48', 'success'),
(107, '2026-11-03 12:21:55', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(108, '2026-11-03 12:22:06', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.220', 'success'),
(109, '2026-11-03 12:22:23', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.220', 'success'),
(110, '2026-11-03 12:42:11', 9, 'Gale Nuez', 'security', 'panel_locked', NULL, NULL, 'Admin panel locked manually', '112.211.125.48', 'success'),
(111, '2026-11-03 12:42:19', 9, 'Gale Nuez', 'auth', 'logout', NULL, NULL, 'Signed out', '112.211.125.48', 'success'),
(112, '2026-11-03 12:49:34', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(113, '2026-11-03 12:50:05', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.125.48', 'success'),
(114, '2026-11-03 12:50:21', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.125.48', 'success'),
(115, '2026-11-03 12:50:27', 13, 'hottog', 'admin', 'export', NULL, NULL, 'Downloaded dashboard report (full) for Year: 2026', '136.158.42.220', 'success'),
(116, '2026-11-03 12:57:50', 36, 'Gene Lim', 'auth', 'login_success', NULL, NULL, 'Signed in', '119.95.14.132', 'success'),
(117, '2026-11-03 13:12:21', 37, 'Precious Kyla', 'auth', 'login_success', NULL, NULL, 'Signed in', '49.150.47.153', 'success'),
(118, '2026-11-03 13:17:59', 38, 'Earl Tan', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.198.104.195', 'success'),
(119, '2026-11-03 13:18:25', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.125.48', 'success'),
(120, '2026-11-03 13:18:48', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.125.48', 'success'),
(121, '2026-11-03 13:25:55', 39, 'Stephanie Datu', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.204.162.25', 'success'),
(122, '2026-11-03 13:40:41', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.220', 'success'),
(123, '2026-11-03 13:40:57', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(124, '2026-11-03 13:40:59', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.220', 'success'),
(125, '2026-11-03 14:05:28', 44, 'Kath Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.121.37', 'success'),
(126, '2026-11-03 14:17:15', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.220', 'success'),
(127, '2026-11-03 14:17:34', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.220', 'success'),
(128, '2026-11-03 14:24:24', 46, 'Liam Dimabasa', 'auth', 'login_success', NULL, NULL, 'Signed in', '113.19.141.43', 'success'),
(129, '2026-11-03 14:27:24', 47, 'sharie infante', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.209.177.1', 'success'),
(130, '2026-11-03 14:36:00', 48, 'Raven Ganda', 'auth', 'login_success', NULL, NULL, 'Signed in', '110.235.160.156', 'success'),
(131, '2026-11-03 14:36:55', 48, 'Raven Ganda', 'auth', 'logout', NULL, NULL, 'Signed out', '110.235.160.156', 'success'),
(132, '2026-11-03 14:38:24', 52, 'Burat Delos Santos', 'auth', 'login_success', NULL, NULL, 'Signed in', '27.49.19.42', 'success'),
(133, '2026-11-03 14:38:46', 53, 'Reuben Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.58.114', 'success'),
(134, '2026-11-03 14:40:01', 51, 'Raven SoCute', 'auth', 'login_success', NULL, NULL, 'Signed in', '110.235.160.156', 'success'),
(135, '2026-11-03 14:40:38', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(136, '2026-11-03 14:40:52', 51, 'Raven SoCute', 'auth', 'logout', NULL, NULL, 'Signed out', '110.235.160.156', 'success');
INSERT INTO `audit_log` (`log_id`, `created_at`, `actor_id`, `actor_name`, `category`, `action`, `target_type`, `target_id`, `summary`, `ip`, `result`) VALUES
(137, '2026-11-03 14:40:54', 54, 'Eferson Nathan Villanueva', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.121.37', 'success'),
(138, '2026-11-03 14:41:26', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.125.48', 'success'),
(139, '2026-11-03 14:42:02', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.125.48', 'success'),
(140, '2026-11-03 14:42:06', 58, 'Reece Bella', 'auth', 'login_success', NULL, NULL, 'Signed in', '110.235.160.156', 'success'),
(141, '2026-11-03 14:43:00', 9, 'Gale Nuez', 'admin', 'delete', 'user', 50, 'Deleted user Jewel Macapangal (#50)', '112.211.125.48', 'success'),
(142, '2026-11-03 14:49:47', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.121.37', 'success'),
(143, '2026-11-03 14:50:06', 2, 'Peter Linus R Ferrer', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.121.37', 'success'),
(144, '2026-11-03 14:50:25', 2, 'Peter Linus R Ferrer', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.121.37', 'success'),
(145, '2026-11-03 14:52:02', 2, 'Peter Linus R Ferrer', 'admin', 'delete', 'user', 49, 'Deleted user fuck niggas (#49) (bulk delete)', '112.211.121.37', 'success'),
(146, '2026-11-03 15:09:02', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(147, '2026-11-03 15:12:34', 59, 'Jose F.', 'auth', 'login_failed', NULL, NULL, 'Failed login for jeferrer1987@gmail.com (wrong password)', '112.211.121.37', 'failure'),
(148, '2026-11-03 15:12:45', 59, 'Jose F.', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.121.37', 'success'),
(149, '2026-11-03 15:23:24', 60, 'Deejay', 'auth', 'login_success', NULL, NULL, 'Signed in', '124.104.85.44', 'success'),
(150, '2026-11-03 15:25:34', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(151, '2026-11-03 15:29:24', 2, 'Peter Linus R Ferrer', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.220', 'success'),
(152, '2026-11-03 15:29:35', 1, 'clarence, i.', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(153, '2026-11-03 15:30:38', 1, 'clarence, i.', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.220', 'success'),
(154, '2026-11-03 15:30:48', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for clarenceignacio7@gmail.com (no such account)', '136.158.42.220', 'failure'),
(155, '2026-11-03 15:31:49', 61, 'Clarence TESTER', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(156, '2026-11-03 15:33:59', 61, 'Clarence TESTER', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.220', 'success'),
(157, '2026-11-03 15:34:56', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '136.158.42.220', 'success'),
(158, '2026-11-03 15:35:09', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '136.158.42.220', 'success'),
(159, '2026-11-03 15:35:17', 13, 'hottog', 'admin', 'verify_change', 'user', 62, 'Verified user Frankie Lapenna (#62)', '136.158.42.220', 'success'),
(160, '2026-11-03 15:35:40', 62, 'Frankie Lapenna', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(161, '2026-11-03 15:46:57', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '112.211.125.48', 'success'),
(162, '2026-11-03 15:47:14', 9, 'Gale Nuez', 'security', 'otp_failed', NULL, NULL, 'Wrong sign-in code entered', '112.211.125.48', 'failure'),
(163, '2026-11-03 15:47:27', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '112.211.125.48', 'success'),
(164, '2026-11-03 15:58:04', 33, 'Rosita Marie Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(165, '2026-11-03 16:20:20', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '112.211.125.48', 'success'),
(166, '2026-11-03 22:07:18', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for lexilouhveloso2006@gmail.com (no such account)', '209.35.160.2', 'failure'),
(167, '2026-11-03 22:09:16', 63, 'Lexi Veloso', 'auth', 'login_success', NULL, NULL, 'Signed in', '209.35.160.2', 'success'),
(168, '2026-11-04 00:04:48', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '136.158.42.220', 'success'),
(169, '2026-11-04 00:14:46', 9, 'Gale Nuez', 'auth', 'login_success', NULL, NULL, 'Signed in', '122.55.206.130', 'success'),
(170, '2026-11-04 00:15:07', 9, 'Gale Nuez', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '202.90.138.99', 'success'),
(171, '2026-11-04 00:16:02', 9, 'Gale Nuez', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '202.90.138.99', 'success'),
(172, '2026-11-04 01:45:32', 2, 'Peter Linus R Ferrer', 'auth', 'logout', NULL, NULL, 'Signed out', '202.90.138.99', 'success'),
(173, '2026-11-04 01:45:43', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '202.90.138.99', 'success'),
(174, '2026-11-04 01:45:49', 2, 'Peter Linus R Ferrer', 'auth', 'logout', NULL, NULL, 'Signed out', '202.90.138.99', 'success'),
(175, '2026-11-04 01:46:36', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '202.90.138.99', 'success'),
(176, '2026-11-04 01:47:54', 2, 'Peter Linus R Ferrer', 'auth', 'logout', NULL, NULL, 'Signed out', '202.90.138.99', 'success'),
(177, '2026-11-04 01:48:10', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in', '202.90.138.99', 'success'),
(178, '2026-11-04 01:48:47', 13, 'hottog', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '202.90.138.99', 'success'),
(179, '2026-11-04 01:49:04', 13, 'hottog', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '202.90.138.99', 'success'),
(180, '2026-11-04 01:51:32', 13, 'hottog', 'admin', 'delete', 'booking', 11, 'Deleted booking #11 (TEST) (bulk delete)', '202.90.138.99', 'success'),
(181, '2026-11-04 01:51:32', 13, 'hottog', 'admin', 'delete', 'booking', 10, 'Deleted booking #10 (TEST) (bulk delete)', '202.90.138.99', 'success'),
(182, '2026-11-04 01:51:32', 13, 'hottog', 'admin', 'delete', 'booking', 9, 'Deleted booking #9 (TEST) (bulk delete)', '202.90.138.99', 'success'),
(183, '2026-11-04 01:52:00', 13, 'hottog', 'admin', 'delete', 'property', 56, 'Deleted property TEST (#56) (bulk delete)', '202.90.138.99', 'success'),
(184, '2026-11-04 01:52:17', 13, 'hottog', 'security', 'panel_locked', NULL, NULL, 'Admin panel locked manually', '202.90.138.99', 'success'),
(185, '2026-11-04 03:15:10', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '202.90.138.99', 'success'),
(186, '2026-11-04 03:15:25', 2, 'Peter Linus R Ferrer', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '122.55.206.130', 'success'),
(187, '2026-11-04 03:16:04', 2, 'Peter Linus R Ferrer', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '202.90.138.99', 'success'),
(188, '2026-11-04 03:34:45', 2, 'Peter Linus R Ferrer', 'auth', 'logout', NULL, NULL, 'Signed out', '202.90.138.99', 'success'),
(189, '2026-11-04 03:37:24', 64, 'Ezikiel Dawa', 'auth', 'login_success', NULL, NULL, 'Signed in', '202.90.138.99', 'success'),
(190, '2026-11-04 03:43:15', 64, 'Ezikiel Dawa', 'auth', 'logout', NULL, NULL, 'Signed out', '122.55.206.130', 'success'),
(191, '2026-11-04 03:43:20', 2, 'Peter Linus R Ferrer', 'auth', 'login_success', NULL, NULL, 'Signed in', '202.90.138.99', 'success'),
(192, '2026-11-04 03:48:03', 2, 'Peter Linus R Ferrer', 'security', 'otp_sent', NULL, NULL, 'Admin sign-in code emailed', '122.55.206.130', 'success'),
(193, '2026-11-04 03:48:17', 2, 'Peter Linus R Ferrer', 'security', 'unlock_success', NULL, NULL, 'Admin panel unlocked (password + email code)', '122.55.206.130', 'success'),
(194, '2026-11-04 03:55:18', 2, 'Peter Linus R Ferrer', 'security', 'panel_locked', NULL, NULL, 'Admin panel locked manually', '122.55.206.130', 'success'),
(195, '2026-11-06 05:31:00', 2, 'Peter Linus R Ferrer', 'auth', 'login_password_ok', NULL, NULL, 'Password accepted, waiting for sign-in code', '136.158.42.180', 'success'),
(196, '2026-11-06 05:34:28', 13, 'hottog', 'auth', 'login_password_ok', NULL, NULL, 'Password accepted, waiting for sign-in code', '136.158.42.180', 'success'),
(197, '2026-11-06 05:34:56', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in (two-step verified)', '136.158.42.180', 'success'),
(198, '2026-11-06 05:44:18', 13, 'hottog', 'auth', 'logout', NULL, NULL, 'Signed out', '136.158.42.180', 'success'),
(199, '2026-11-06 05:44:45', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for monkeman6302@gmail.com (no such account)', '136.158.42.180', 'failure'),
(200, '2026-11-06 05:44:53', NULL, 'Guest', 'auth', 'login_failed', NULL, NULL, 'Failed login for manmonke6302@gmail.com (no such account)', '136.158.42.180', 'failure'),
(201, '2026-11-06 07:40:39', 61, 'Clarence TESTER', 'auth', 'login_password_ok', NULL, NULL, 'Password accepted, waiting for sign-in code', '136.158.42.180', 'success'),
(202, '2026-11-06 07:41:14', 61, 'Clarence TESTER', 'auth', 'login_success', NULL, NULL, 'Signed in (two-step verified)', '136.158.42.180', 'success'),
(203, '2026-11-06 07:52:59', 61, 'Clarence TESTER', 'security', 'owner_unlock_ok', NULL, NULL, 'Owner panel unlocked', '136.158.42.180', 'success'),
(204, '2026-11-06 07:54:22', 61, 'Clarence TESTER', 'security', 'owner_locked', NULL, NULL, 'Owner panel locked manually', '136.158.42.180', 'success'),
(205, '2026-11-06 07:57:16', 13, 'hottog', 'auth', 'login_password_ok', NULL, NULL, 'Password accepted, waiting for sign-in code', '136.158.42.180', 'success'),
(206, '2026-11-06 07:57:28', 13, 'hottog', 'auth', 'login_success', NULL, NULL, 'Signed in (two-step verified)', '136.158.42.180', 'success'),
(207, '2026-11-06 08:00:22', 13, 'hottog', 'security', 'owner_unlock_ok', NULL, NULL, 'Owner panel unlocked', '136.158.42.180', 'success'),
(208, '2026-11-06 08:00:30', 13, 'hottog', 'admin', 'owner_request_confirmed', 'booking', 66, 'Owner approved request #66 (TESTING)', '136.158.42.180', 'success'),
(209, '2026-11-06 08:01:34', 13, 'hottog', 'admin', 'owner_pay_confirm', 'payment', 46, 'Owner confirmed payment for booking #66', '136.158.42.180', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `check_in` date NOT NULL,
  `check_out` varchar(20) NOT NULL DEFAULT 'Not checked out',
  `guests` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `total_amount` decimal(10,2) NOT NULL,
  `booking_status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `user_id`, `property_id`, `check_in`, `check_out`, `guests`, `total_amount`, `booking_status`, `created_at`) VALUES
(4, 17, 5, '2027-10-03', 'Not checked out', 1, '31200.00', 'pending', '2026-11-03 05:21:10'),
(5, 17, 7, '2028-09-03', 'Not checked out', 1, '24300.00', 'pending', '2026-11-03 05:22:09'),
(7, 17, 27, '2028-09-03', 'Not checked out', 1, '9400.00', 'pending', '2026-11-03 11:08:48'),
(8, 28, 33, '2026-12-12', 'Not checked out', 3, '71000.00', 'pending', '2026-11-03 12:13:25'),
(12, 33, 55, '2026-11-23', 'Not checked out', 1, '25500.00', 'pending', '2026-11-03 15:59:17'),
(13, 2, 57, '2026-11-05', 'Not checked out', 1, '121212.00', 'pending', '2026-11-04 03:45:54'),
(14, 19, 6, '2026-08-01', 'Not checked out', 2, '21700.00', 'confirmed', '2026-07-21 01:03:05'),
(15, 62, 24, '2026-08-08', '2026-08-12', 2, '20000.00', 'confirmed', '2026-08-01 21:17:56'),
(16, 17, 42, '2026-08-20', '2026-08-23', 1, '15600.00', 'confirmed', '2026-08-10 18:17:08'),
(17, 47, 47, '2026-09-05', '2026-09-10', 2, '29500.00', 'confirmed', '2026-08-31 01:00:15'),
(18, 51, 64, '2026-09-10', 'Not checked out', 4, '54000.00', 'confirmed', '2026-09-03 00:58:32'),
(19, 36, 13, '2026-09-01', 'Not checked out', 2, '18000.00', 'confirmed', '2026-08-25 18:04:56'),
(20, 53, 11, '2026-09-15', 'Not checked out', 1, '3900.00', 'confirmed', '2026-09-05 16:10:50'),
(21, 52, 63, '2026-09-12', '2026-09-16', 2, '6000.00', 'confirmed', '2026-09-08 17:44:25'),
(22, 24, 25, '2026-09-19', '2026-09-26', 2, '10500.00', 'confirmed', '2026-09-12 15:13:02'),
(23, 20, 61, '2026-09-01', 'Not checked out', 1, '3800.00', 'confirmed', '2026-08-25 17:12:23'),
(24, 44, 61, '2026-09-15', 'Not checked out', 1, '3800.00', 'confirmed', '2026-09-05 23:01:25'),
(25, 38, 48, '2026-09-24', '2026-09-28', 2, '23200.00', 'confirmed', '2026-09-17 18:04:38'),
(26, 46, 18, '2026-10-01', 'Not checked out', 2, '19800.00', 'confirmed', '2026-09-22 19:46:22'),
(27, 28, 66, '2026-10-05', '2026-10-08', 3, '22500.00', 'confirmed', '2026-09-28 21:28:12'),
(28, 38, 65, '2026-10-05', 'Not checked out', 1, '3200.00', 'confirmed', '2026-09-28 19:55:46'),
(29, 33, 62, '2026-10-10', 'Not checked out', 2, '22000.00', 'confirmed', '2026-10-02 20:01:33'),
(30, 20, 9, '2026-10-14', '2026-10-17', 1, '6300.00', 'confirmed', '2026-10-11 01:23:15'),
(31, 28, 28, '2026-10-15', 'Not checked out', 3, '48400.00', 'confirmed', '2026-10-06 22:25:29'),
(32, 52, 41, '2026-10-20', 'Not checked out', 1, '2000.00', 'confirmed', '2026-10-12 21:26:46'),
(33, 44, 53, '2026-10-25', 'Not checked out', 1, '4500.00', 'confirmed', '2026-10-18 21:47:57'),
(34, 33, 43, '2026-10-26', '2026-10-30', 1, '5600.00', 'confirmed', '2026-10-21 01:47:49'),
(35, 17, 69, '2026-10-28', 'Not checked out', 1, '6800.00', 'confirmed', '2026-10-22 19:14:50'),
(36, 60, 10, '2026-12-01', 'Not checked out', 2, '17000.00', 'confirmed', '2026-10-20 15:46:52'),
(37, 62, 58, '2026-11-01', 'Not checked out', 1, '18500.00', 'confirmed', '2026-10-26 17:07:03'),
(38, 39, 37, '2026-11-03', '2026-11-10', 2, '31500.00', 'confirmed', '2026-10-30 20:59:29'),
(39, 22, 8, '2026-11-15', 'Not checked out', 2, '40700.00', 'confirmed', '2026-11-01 21:49:28'),
(40, 18, 59, '2026-11-20', 'Not checked out', 2, '38500.00', 'confirmed', '2026-11-03 22:30:35'),
(41, 26, 12, '2026-12-10', 'Not checked out', 4, '56900.00', 'confirmed', '2026-10-28 03:20:29'),
(42, 47, 19, '2026-11-12', 'Not checked out', 1, '10900.00', 'confirmed', '2026-11-02 04:50:39'),
(43, 38, 20, '2026-12-01', 'Not checked out', 5, '58600.00', 'confirmed', '2026-10-30 19:35:44'),
(44, 22, 60, '2026-12-05', 'Not checked out', 4, '62000.00', 'confirmed', '2026-11-03 17:48:21'),
(45, 53, 40, '2026-11-25', 'Not checked out', 3, '30100.00', 'confirmed', '2026-11-03 02:45:20'),
(46, 36, 65, '2026-11-10', 'Not checked out', 1, '3200.00', 'confirmed', '2026-11-02 04:51:20'),
(47, 39, 45, '2026-12-15', 'Not checked out', 3, '36300.00', 'confirmed', '2026-11-05 01:51:18'),
(48, 60, 26, '2026-12-01', 'Not checked out', 2, '53200.00', 'confirmed', '2026-11-02 19:05:31'),
(49, 44, 30, '2026-11-16', 'Not checked out', 1, '4900.00', 'confirmed', '2026-11-03 20:09:08'),
(50, 46, 67, '2026-11-18', 'Not checked out', 2, '14500.00', 'confirmed', '2026-11-05 02:54:18'),
(51, 26, 49, '2026-11-22', 'Not checked out', 1, '8200.00', 'confirmed', '2026-11-04 19:59:28'),
(52, 62, 54, '2026-12-20', 'Not checked out', 3, '29300.00', 'confirmed', '2026-11-05 21:10:39'),
(53, 19, 61, '2026-11-12', 'Not checked out', 1, '3800.00', 'confirmed', '2026-11-03 03:28:06'),
(54, 33, 32, '2026-12-08', 'Not checked out', 4, '45900.00', 'pending', '2026-11-04 18:45:42'),
(55, 19, 34, '2026-11-28', 'Not checked out', 3, '15200.00', 'pending', '2026-11-06 04:32:15'),
(56, 20, 46, '2026-11-30', 'Not checked out', 1, '3500.00', 'pending', '2026-11-05 19:59:10'),
(57, 28, 36, '2027-01-05', 'Not checked out', 5, '72800.00', 'pending', '2026-11-06 01:46:22'),
(58, 46, 9, '2026-11-14', '2026-11-18', 2, '8400.00', 'pending', '2026-11-06 03:29:22'),
(59, 36, 66, '2026-11-21', '2026-11-24', 3, '22500.00', 'pending', '2026-11-04 23:27:58'),
(60, 17, 63, '2026-11-10', '2026-11-13', 2, '4500.00', 'pending', '2026-11-06 03:44:15'),
(61, 60, 24, '2026-12-23', '2026-12-28', 2, '25000.00', 'pending', '2026-11-05 23:19:46'),
(62, 52, 39, '2026-10-18', 'Not checked out', 2, '29000.00', 'cancelled', '2026-10-02 21:14:25'),
(63, 39, 44, '2026-10-10', 'Not checked out', 1, '7400.00', 'cancelled', '2026-09-29 00:09:58'),
(64, 47, 35, '2026-11-08', 'Not checked out', 1, '6000.00', 'cancelled', '2026-10-28 19:49:36'),
(65, 44, 21, '2026-09-14', 'Not checked out', 1, '15400.00', 'cancelled', '2026-09-02 02:35:23'),
(66, 61, 70, '2026-11-06', '2026-11-11', 1, '1234.00', 'confirmed', '2026-11-06 07:59:44');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` int(10) UNSIGNED NOT NULL,
  `city_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `city_name`) VALUES
(12, 'Antipolo'),
(15, 'Cavite'),
(13, 'Cebu City'),
(14, 'Iloilo City'),
(7, 'Makati'),
(3, 'Malolos'),
(10, 'Mandaluyong'),
(5, 'Manila'),
(11, 'Marikina'),
(16, 'Paco, Manila'),
(9, 'Pasig'),
(6, 'Quezon City'),
(8, 'Taguig'),
(1, 'Valenzuela city');

-- --------------------------------------------------------

--
-- Table structure for table `email_verifications`
--

CREATE TABLE `email_verifications` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_verifications`
--

INSERT INTO `email_verifications` (`user_id`, `token_hash`, `expires_at`, `attempts`, `created_at`) VALUES
(10, 'd54ce895a8e82816646ceb207687a8c9886fae84d83ac834853e49eb0d66b581', '2026-10-29 00:07:49', 0, '2026-10-28 07:07:49'),
(16, 'faf829990acedca4e497e60321feab362fdcf7396b8505abab05f8de48a3c8bc', '2026-11-02 05:41:05', 0, '2026-11-02 13:26:05'),
(21, 'aafa2a14874c6e82d6d8c4d1418d4ac5f4abfa034bfe3bf3be90f5c9cb6af6c0', '2026-11-02 23:50:49', 0, '2026-11-03 07:35:49'),
(27, 'dea41ebfff203e611d16f80cfc2ab32636ab3afe26d74ac99dc325480ef0e0e8', '2026-11-03 04:24:10', 0, '2026-11-03 12:09:10'),
(34, '49fbf9b316ae97ff7cd623b06f850093af698f25c3c360a35c5dc96e97e20e6f', '2026-11-03 04:40:16', 0, '2026-11-03 12:25:16'),
(55, '694ddacc35ee4a96a2e8d21631650efb98aa63d15a518c3575605fd0781b6fae', '2026-11-03 06:54:13', 0, '2026-11-03 14:39:13'),
(62, 'e4cc2b00b4e2070bea7164077fa497b4d2f4071650e64e01ece1634fa7db4c0d', '2026-11-03 07:49:33', 0, '2026-11-03 15:34:33');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`user_id`, `property_id`, `created_at`) VALUES
(9, 58, '2026-11-01 19:37:32'),
(13, 7, '2026-11-04 01:56:27'),
(17, 8, '2026-11-06 03:54:55'),
(17, 12, '2026-09-05 18:02:40'),
(17, 20, '2026-10-04 23:50:39'),
(18, 7, '2026-09-02 22:09:45'),
(18, 8, '2026-09-05 16:42:04'),
(19, 8, '2026-11-05 00:33:55'),
(19, 59, '2026-11-04 22:49:39'),
(20, 11, '2026-10-05 01:08:37'),
(20, 61, '2026-09-02 02:53:59'),
(22, 12, '2026-09-02 23:09:56'),
(22, 26, '2026-10-02 23:18:48'),
(24, 9, '2026-11-05 16:08:57'),
(24, 63, '2026-11-03 03:01:47'),
(26, 20, '2026-11-06 05:16:35'),
(26, 64, '2026-11-03 05:04:20'),
(28, 40, '2026-10-02 21:20:05'),
(33, 8, '2026-09-04 18:44:20'),
(33, 62, '2026-09-06 05:08:38'),
(36, 19, '2026-09-04 19:46:05'),
(36, 65, '2026-09-02 00:21:32'),
(38, 60, '2026-11-05 22:50:42'),
(39, 45, '2026-11-02 05:43:46'),
(39, 59, '2026-09-03 02:33:30'),
(44, 30, '2026-09-05 04:32:59'),
(44, 61, '2026-10-01 16:46:16'),
(46, 8, '2026-10-05 05:35:07'),
(46, 69, '2026-10-01 20:25:39'),
(47, 10, '2026-11-03 02:35:47'),
(51, 66, '2026-11-02 16:51:22'),
(52, 12, '2026-11-03 18:25:49'),
(53, 65, '2026-11-05 23:58:33'),
(60, 26, '2026-11-05 03:50:52'),
(60, 59, '2026-11-06 04:58:53'),
(62, 54, '2026-10-06 04:03:13'),
(62, 67, '2026-10-04 22:02:40');

-- --------------------------------------------------------

--
-- Table structure for table `login_mfa`
--

CREATE TABLE `login_mfa` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `method` varchar(5) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_mfa_log`
--

CREATE TABLE `login_mfa_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `method` varchar(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_mfa_log`
--

INSERT INTO `login_mfa_log` (`id`, `user_id`, `method`, `created_at`) VALUES
(1, 13, 'email', '2026-11-06 05:34:31'),
(2, 61, 'email', '2026-11-06 07:40:41'),
(3, 13, 'email', '2026-11-06 07:57:18');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(10) UNSIGNED NOT NULL,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `method_id` tinyint(3) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  `paid_at` varchar(30) NOT NULL DEFAULT 'Not paid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `proof_image` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `booking_id`, `method_id`, `amount`, `payment_status`, `paid_at`, `created_at`, `proof_image`) VALUES
(3, 14, 2, '21700.00', 'paid', '2026-07-28 18:54:20', '2026-07-22 17:15:00', 'assets/uploads/payments/demo_proof_01.png'),
(4, 15, 2, '20000.00', 'paid', '2026-08-04 09:57:07', '2026-08-03 01:00:41', 'assets/uploads/payments/demo_proof_02.png'),
(5, 16, 4, '15600.00', 'paid', '2026-08-12 11:21:56', '2026-08-11 17:19:37', 'assets/uploads/payments/demo_proof_03.png'),
(6, 17, 14, '29500.00', 'paid', '2026-09-02 17:00:04', '2026-09-01 02:49:44', 'assets/uploads/payments/demo_proof_04.png'),
(7, 18, 14, '54000.00', 'paid', '2026-09-08 17:14:44', '2026-09-04 04:46:30', 'assets/uploads/payments/demo_proof_05.png'),
(8, 19, 2, '18000.00', 'paid', '2026-09-02 17:27:46', '2026-08-27 20:45:26', 'assets/uploads/payments/demo_proof_06.png'),
(9, 20, 3, '3900.00', 'paid', '2026-09-09 18:18:48', '2026-09-07 03:26:05', 'assets/uploads/payments/demo_proof_07.png'),
(10, 21, 3, '6000.00', 'paid', '2026-09-11 12:20:48', '2026-09-09 21:13:28', 'assets/uploads/payments/demo_proof_08.png'),
(11, 22, 2, '10500.00', 'paid', '2026-09-15 18:03:42', '2026-09-13 22:45:35', 'assets/uploads/payments/demo_proof_09.png'),
(12, 23, 2, '3800.00', 'paid', '2026-08-29 16:18:14', '2026-08-27 01:27:06', 'assets/uploads/payments/demo_proof_10.png'),
(13, 24, 3, '3800.00', 'paid', '2026-09-10 16:38:01', '2026-09-06 15:05:23', 'assets/uploads/payments/demo_proof_11.png'),
(14, 25, 2, '23200.00', 'paid', '2026-09-22 09:30:32', '2026-09-18 22:13:19', 'assets/uploads/payments/demo_proof_12.png'),
(15, 26, 4, '19800.00', 'paid', '2026-09-29 13:34:01', '2026-09-25 00:22:22', 'assets/uploads/payments/demo_proof_13.png'),
(16, 27, 14, '22500.00', 'paid', '2026-10-03 18:16:48', '2026-09-29 16:32:56', 'assets/uploads/payments/demo_proof_14.png'),
(17, 28, 3, '3200.00', 'paid', '2026-10-08 19:30:52', '2026-09-30 03:30:22', 'assets/uploads/payments/demo_proof_15.png'),
(18, 29, 2, '22000.00', 'paid', '2026-10-14 14:06:45', '2026-10-03 22:24:33', 'assets/uploads/payments/demo_proof_16.png'),
(19, 30, 3, '6300.00', 'paid', '2026-10-13 19:23:18', '2026-10-11 20:04:02', 'assets/uploads/payments/demo_proof_17.png'),
(20, 31, 14, '48400.00', 'paid', '2026-10-14 20:28:41', '2026-10-09 02:35:30', 'assets/uploads/payments/demo_proof_18.png'),
(21, 32, 3, '2000.00', 'paid', '2026-10-21 12:38:36', '2026-10-13 17:15:37', 'assets/uploads/payments/demo_proof_19.png'),
(22, 33, 2, '4500.00', 'paid', '2026-10-21 11:20:33', '2026-10-19 23:20:26', 'assets/uploads/payments/demo_proof_20.png'),
(23, 34, 3, '5600.00', 'paid', '2026-10-27 10:37:51', '2026-10-21 17:49:23', 'assets/uploads/payments/demo_proof_21.png'),
(24, 35, 2, '6800.00', 'paid', '2026-10-30 19:43:46', '2026-10-24 01:49:14', 'assets/uploads/payments/demo_proof_22.png'),
(25, 36, 4, '17000.00', 'paid', '2026-10-30 17:20:49', '2026-10-22 23:47:36', 'assets/uploads/payments/demo_proof_23.png'),
(26, 37, 4, '18500.00', 'paid', '2026-11-02 10:23:43', '2026-10-28 04:41:01', 'assets/uploads/payments/demo_proof_24.png'),
(27, 38, 2, '31500.00', 'paid', '2026-11-02 13:08:43', '2026-11-01 03:43:19', 'assets/uploads/payments/demo_proof_25.png'),
(28, 39, 2, '40700.00', 'paid', '2026-11-03 16:16:03', '2026-11-02 23:39:58', 'assets/uploads/payments/demo_proof_26.png'),
(29, 40, 2, '38500.00', 'paid', '2026-11-05 13:26:51', '2026-11-04 05:08:31', 'assets/uploads/payments/demo_proof_27.png'),
(30, 41, 4, '56900.00', 'paid', '2026-11-04 16:10:47', '2026-10-28 18:11:26', 'assets/uploads/payments/demo_proof_28.png'),
(31, 42, 2, '10900.00', 'pending', 'Not paid', '2026-11-03 02:57:34', 'assets/uploads/payments/demo_proof_29.png'),
(32, 43, 4, '58600.00', 'pending', 'Not paid', '2026-10-31 19:23:30', 'assets/uploads/payments/demo_proof_30.png'),
(33, 44, 3, '62000.00', 'pending', 'Not paid', '2026-11-04 18:23:03', 'assets/uploads/payments/demo_proof_31.png'),
(34, 45, 14, '30100.00', 'pending', 'Not paid', '2026-11-03 20:56:23', 'assets/uploads/payments/demo_proof_32.png'),
(35, 46, 2, '3200.00', 'pending', 'Not paid', '2026-11-02 20:46:07', 'assets/uploads/payments/demo_proof_33.png'),
(36, 47, 2, '36300.00', 'pending', 'Not paid', '2026-11-06 00:15:09', 'assets/uploads/payments/demo_proof_34.png'),
(37, 48, 6, '53200.00', 'pending', 'Not paid', '2026-11-03 21:40:47', ''),
(38, 49, 6, '4900.00', 'pending', 'Not paid', '2026-11-05 02:40:06', ''),
(39, 50, 6, '14500.00', 'pending', 'Not paid', '2026-11-05 17:00:18', ''),
(40, 51, 6, '8200.00', 'pending', 'Not paid', '2026-11-05 17:23:24', ''),
(41, 52, 6, '29300.00', 'pending', 'Not paid', '2026-11-05 23:55:39', ''),
(42, 53, 6, '3800.00', 'pending', 'Not paid', '2026-11-03 17:14:30', ''),
(43, 62, 2, '29000.00', 'refunded', '2026-10-05 15:25:23', '2026-10-03 23:50:09', 'assets/uploads/payments/demo_proof_35.png'),
(44, 63, 3, '7400.00', 'failed', 'Not paid', '2026-09-30 01:12:27', 'assets/uploads/payments/demo_proof_36.png'),
(45, 65, 2, '15400.00', 'refunded', '2026-09-05 18:32:17', '2026-09-02 21:47:55', 'assets/uploads/payments/demo_proof_37.png'),
(46, 66, 14, '1234.00', 'paid', '2026-11-06 03:01:34', '2026-11-06 08:00:30', 'assets/uploads/payments/3f8e0b6a093a8d1b49fd02c7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `method_id` tinyint(3) UNSIGNED NOT NULL,
  `method_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`method_id`, `method_name`) VALUES
(4, 'Bank Transfer'),
(1, 'Cash'),
(5, 'Credit/Debit Card'),
(2, 'GCash'),
(14, 'MariBank'),
(3, 'Maya'),
(6, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `property_id` int(10) UNSIGNED NOT NULL,
  `owner_id` int(10) UNSIGNED NOT NULL,
  `property_code` varchar(50) NOT NULL,
  `type_id` smallint(5) UNSIGNED NOT NULL,
  `city_id` int(10) UNSIGNED NOT NULL,
  `street_address` varchar(255) NOT NULL DEFAULT 'N/A',
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL DEFAULT 'No description provided',
  `price` decimal(10,2) NOT NULL,
  `price_unit` enum('daily','monthly') NOT NULL DEFAULT 'monthly',
  `bedrooms` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `bathrooms` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `area` varchar(50) NOT NULL DEFAULT 'N/A',
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('available','rented','inactive') NOT NULL DEFAULT 'available',
  `pets_allowed` tinyint(1) NOT NULL DEFAULT 0,
  `pet_conditions` varchar(255) NOT NULL DEFAULT 'None',
  `parking` enum('none','free','paid') NOT NULL DEFAULT 'none',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `slots` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`property_id`, `owner_id`, `property_code`, `type_id`, `city_id`, `street_address`, `title`, `description`, `price`, `price_unit`, `bedrooms`, `bathrooms`, `area`, `verified`, `status`, `pets_allowed`, `pet_conditions`, `parking`, `created_at`, `slots`) VALUES
(5, 1, 'DEMO-001', 8, 13, 'Banilad, Cebu City', 'Fully furnished 3-bedroom condo, Banilad', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Walking distance to schools, a mall and a clinic. Great for students and young families.', '31200.00', 'monthly', 3, 1, '36 sqm', 1, 'available', 0, 'None', 'none', '2026-08-20 19:09:06', 1),
(6, 1, 'DEMO-002', 1, 6, 'Katipunan Avenue, Quezon City', 'Bright 3-bedroom apartment in Quezon City', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '21700.00', 'monthly', 3, 2, '33 sqm', 1, 'rented', 1, 'Pets allowed with a deposit; no large breeds', 'free', '2026-07-05 09:09:06', 1),
(7, 1, 'DEMO-003', 8, 7, 'Bel-Air, Makati', 'Fully furnished 1-bedroom condo, Bel-Air', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '24300.00', 'monthly', 1, 1, '35 sqm', 1, 'available', 0, 'None', 'none', '2026-07-21 05:09:06', 1),
(8, 1, 'DEMO-004', 8, 8, 'BGC 26th Street, Taguig', 'High-floor condo with skyline view', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '40700.00', 'monthly', 2, 1, '56 sqm', 1, 'available', 1, 'Small pets only, owner to be informed first', 'none', '2026-08-18 02:09:06', 1),
(9, 1, 'DEMO-005', 5, 9, 'Ugong, Pasig', 'Private room for rent, Ugong', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '2100.00', 'daily', 1, 1, '18 sqm', 1, 'available', 0, 'None', 'none', '2026-10-09 23:09:06', 1),
(10, 1, 'DEMO-006', 6, 10, 'Boni Avenue, Mandaluyong', 'Corner townhouse with carport, Boni Avenue', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Walking distance to schools, a mall and a clinic. Great for students and young families.', '17000.00', 'monthly', 2, 2, '93 sqm', 1, 'available', 0, 'None', 'none', '2026-10-05 17:09:06', 1),
(11, 1, 'DEMO-007', 10, 11, 'Marikina Heights, Marikina', 'Female bed space with lockers, Marikina Heights', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Newly painted with good natural light and ventilation. Management is responsive and friendly.', '3900.00', 'monthly', 0, 1, '8 sqm', 1, 'rented', 0, 'None', 'none', '2026-08-31 15:09:06', 1),
(12, 1, 'DEMO-008', 8, 12, 'Marcos Highway, Antipolo', 'Fully furnished 3-bedroom condo, Marcos Highway', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Newly painted with good natural light and ventilation. Management is responsive and friendly.', '56900.00', 'monthly', 3, 2, '47 sqm', 1, 'available', 0, 'None', 'none', '2026-09-05 01:09:06', 1),
(13, 1, 'DEMO-009', 1, 13, 'Lahug, Cebu City', 'Bright 1-bedroom apartment in Cebu City', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Walking distance to schools, a mall and a clinic. Great for students and young families.', '18000.00', 'monthly', 1, 1, '60 sqm', 1, 'rented', 0, 'None', 'paid', '2026-07-06 03:09:06', 1),
(14, 1, 'DEMO-010', 1, 14, 'La Paz, Iloilo City', 'Cozy apartment near La Paz', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '5200.00', 'daily', 2, 1, '70 sqm', 0, 'inactive', 1, 'Pets allowed with a deposit; no large breeds', 'none', '2026-09-09 07:09:06', 1),
(15, 1, 'DEMO-011', 9, 15, 'Imus, Cavite', 'Women\'s dormitory with study area, Imus', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '7900.00', 'monthly', 1, 1, '24 sqm', 0, 'inactive', 0, 'None', 'none', '2026-06-10 19:09:06', 1),
(16, 1, 'DEMO-012', 8, 5, 'Taft Avenue, Manila', 'Modern condo unit at Taft Avenue', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends.', '8700.00', 'daily', 2, 2, '32 sqm', 1, 'inactive', 0, 'None', 'free', '2026-06-27 13:09:06', 1),
(17, 1, 'DEMO-013', 2, 6, 'Cubao, Quezon City', 'Quiet corner house near Cubao', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '55900.00', 'monthly', 5, 4, '172 sqm', 1, 'inactive', 0, 'None', 'paid', '2026-09-16 21:09:06', 1),
(18, 1, 'DEMO-014', 2, 13, 'IT Park, Cebu City', 'Quiet corner house near IT Park', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends.', '19800.00', 'monthly', 2, 2, '162 sqm', 1, 'rented', 0, 'None', 'none', '2026-06-26 11:09:06', 1),
(19, 1, 'DEMO-015', 5, 8, 'McKinley Hill, Taguig', 'Furnished room with own entrance, Taguig', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Newly painted with good natural light and ventilation. Management is responsive and friendly.', '10900.00', 'monthly', 1, 1, '12 sqm', 1, 'available', 0, 'None', 'paid', '2026-10-22 05:09:06', 1),
(20, 1, 'DEMO-016', 2, 9, 'Ugong, Pasig', '4-bedroom house with garden, Ugong', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Walking distance to schools, a mall and a clinic. Great for students and young families.', '58600.00', 'monthly', 4, 2, '209 sqm', 1, 'available', 0, 'None', 'free', '2026-09-08 15:09:06', 1),
(21, 1, 'DEMO-017', 1, 15, 'Bacoor, Cavite', 'Bright 1-bedroom apartment in Cavite', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '15400.00', 'monthly', 1, 1, '28 sqm', 0, 'available', 1, 'Small pets only, owner to be informed first', 'free', '2026-07-22 10:09:06', 1),
(22, 1, 'DEMO-018', 5, 11, 'Concepcion Uno, Marikina', 'Furnished room with own entrance, Marikina', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport.', '8700.00', 'monthly', 1, 1, '15 sqm', 0, 'available', 0, 'None', 'none', '2026-10-02 13:09:06', 1),
(23, 1, 'DEMO-019', 6, 7, 'Legazpi Village, Makati', 'Two-storey townhouse, Legazpi Village', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Walking distance to schools, a mall and a clinic. Great for students and young families.', '20100.00', 'monthly', 4, 1, '54 sqm', 0, 'available', 1, 'Pet-friendly; keep common areas clean', 'free', '2026-06-20 02:09:06', 1),
(24, 1, 'DEMO-020', 1, 13, 'Mabolo, Cebu City', 'Bright 1-bedroom apartment in Cebu City', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '5000.00', 'daily', 1, 1, '65 sqm', 0, 'available', 0, 'None', 'free', '2026-06-05 18:09:06', 1),
(25, 1, 'DEMO-021', 5, 14, 'Jaro, Iloilo City', 'Bedspace-free private room near Jaro', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Newly painted with good natural light and ventilation. Management is responsive and friendly.', '1500.00', 'daily', 1, 1, '22 sqm', 0, 'available', 0, 'None', 'none', '2026-09-06 14:09:06', 1),
(26, 1, 'DEMO-022', 8, 15, 'Dasmarinas, Cavite', 'Fully furnished 1-bedroom condo, Dasmarinas', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport.', '53200.00', 'monthly', 1, 1, '73 sqm', 1, 'available', 0, 'None', 'free', '2026-06-19 22:09:06', 1),
(27, 1, 'DEMO-023', 1, 5, 'Malate, Manila', 'Bright 1-bedroom apartment in Manila', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Newly painted with good natural light and ventilation. Management is responsive and friendly.', '9400.00', 'monthly', 1, 1, '37 sqm', 0, 'available', 0, 'None', 'paid', '2026-07-14 21:09:06', 1),
(28, 1, 'DEMO-024', 6, 6, 'Cubao, Quezon City', 'Modern townhouse in gated community, Quezon City', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends.', '48400.00', 'monthly', 2, 2, '96 sqm', 1, 'rented', 1, 'Pets allowed with a deposit; no large breeds', 'free', '2026-08-20 20:09:06', 1),
(29, 1, 'DEMO-025', 9, 7, 'Rockwell, Makati', 'Women\'s dormitory with study area, Rockwell', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '7100.00', 'monthly', 1, 1, '28 sqm', 0, 'available', 0, 'None', 'none', '2026-10-11 06:09:06', 1),
(30, 1, 'DEMO-026', 9, 8, 'Fort Bonifacio, Taguig', 'Women\'s dormitory with study area, Fort Bonifacio', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Walking distance to schools, a mall and a clinic. Great for students and young families.', '4900.00', 'monthly', 1, 1, '13 sqm', 1, 'available', 0, 'None', 'none', '2026-07-29 21:09:06', 1),
(31, 1, 'DEMO-027', 10, 9, 'Kapitolyo, Pasig', 'Affordable bed space near Kapitolyo', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '2300.00', 'monthly', 1, 1, '8 sqm', 1, 'inactive', 0, 'None', 'none', '2026-08-20 18:09:06', 1),
(32, 1, 'DEMO-028', 2, 10, 'Shaw Boulevard, Mandaluyong', 'Spacious family house in Mandaluyong', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '45900.00', 'monthly', 4, 3, '86 sqm', 1, 'available', 1, 'Small pets only, owner to be informed first', 'paid', '2026-09-17 20:09:06', 1),
(33, 1, 'DEMO-029', 2, 7, 'Salcedo Village, Makati', 'Quiet corner house near Salcedo Village', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Walking distance to schools, a mall and a clinic. Great for students and young families.', '71000.00', 'monthly', 2, 2, '168 sqm', 0, 'available', 1, 'Cats allowed, no dogs', 'free', '2026-09-19 17:09:06', 1),
(34, 1, 'DEMO-030', 8, 12, 'Taytay Road, Antipolo', 'Modern condo unit at Taytay Road', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '15200.00', 'monthly', 3, 2, '32 sqm', 1, 'available', 0, 'None', 'paid', '2026-08-07 04:09:06', 1),
(35, 1, 'DEMO-031', 5, 13, 'Lahug, Cebu City', 'Furnished room with own entrance, Cebu City', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '6000.00', 'monthly', 1, 1, '21 sqm', 0, 'available', 0, 'None', 'paid', '2026-06-19 06:09:06', 1),
(36, 1, 'DEMO-032', 2, 14, 'Smallville, Iloilo City', 'Quiet corner house near Smallville', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '72800.00', 'monthly', 5, 2, '105 sqm', 1, 'available', 0, 'None', 'free', '2026-10-24 06:09:06', 1),
(37, 1, 'DEMO-033', 1, 9, 'Ortigas Center, Pasig', 'Bright 2-bedroom apartment in Pasig', 'Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries. Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport.', '4500.00', 'daily', 2, 1, '61 sqm', 1, 'rented', 0, 'None', 'free', '2026-06-18 03:09:06', 1),
(38, 1, 'DEMO-034', 1, 5, 'Quiapo, Manila', 'Renovated apartment with city view, Quiapo', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '24200.00', 'monthly', 1, 1, '53 sqm', 0, 'inactive', 0, 'None', 'free', '2026-07-14 09:09:06', 1),
(39, 1, 'DEMO-035', 8, 6, 'Commonwealth Avenue, Quezon City', 'Fully furnished 2-bedroom condo, Commonwealth Avenue', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '29000.00', 'monthly', 2, 1, '44 sqm', 0, 'available', 0, 'None', 'none', '2026-06-01 22:09:06', 1),
(40, 1, 'DEMO-036', 2, 7, 'Rockwell, Makati', '3-bedroom house with garden, Rockwell', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '30100.00', 'monthly', 3, 3, '139 sqm', 1, 'available', 0, 'None', 'paid', '2026-06-29 05:09:06', 1),
(41, 1, 'DEMO-037', 10, 8, 'Pembo, Taguig', 'Female bed space with lockers, Pembo', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '2000.00', 'monthly', 1, 1, '7 sqm', 0, 'rented', 0, 'None', 'none', '2026-08-26 15:09:06', 1),
(42, 1, 'DEMO-038', 1, 9, 'Ortigas Center, Pasig', 'Bright 1-bedroom apartment in Pasig', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '5200.00', 'daily', 1, 1, '42 sqm', 1, 'available', 0, 'None', 'none', '2026-06-28 15:09:06', 1),
(43, 1, 'DEMO-039', 5, 11, 'Marikina Heights, Marikina', 'Furnished room with own entrance, Marikina', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Walking distance to schools, a mall and a clinic. Great for students and young families.', '1400.00', 'daily', 1, 1, '11 sqm', 1, 'available', 0, 'None', 'none', '2026-10-12 02:09:06', 1),
(44, 1, 'DEMO-040', 5, 11, 'Sumulong Highway, Marikina', 'Private room for rent, Sumulong Highway', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends.', '7400.00', 'monthly', 1, 1, '12 sqm', 1, 'available', 0, 'None', 'none', '2026-09-06 18:09:06', 1),
(45, 1, 'DEMO-041', 6, 11, 'Marikina Heights, Marikina', 'Modern townhouse in gated community, Marikina', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Walking distance to schools, a mall and a clinic. Great for students and young families.', '36300.00', 'monthly', 2, 2, '87 sqm', 1, 'available', 1, 'Small pets only, owner to be informed first', 'none', '2026-10-05 09:09:06', 1),
(46, 1, 'DEMO-042', 10, 7, 'Salcedo Village, Makati', 'Affordable bed space near Salcedo Village', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Walking distance to schools, a mall and a clinic. Great for students and young families.', '3500.00', 'monthly', 1, 1, '8 sqm', 1, 'available', 0, 'None', 'none', '2026-09-21 15:09:06', 1),
(47, 1, 'DEMO-043', 8, 8, 'McKinley Hill, Taguig', 'Modern condo unit at McKinley Hill', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Newly painted with good natural light and ventilation. Management is responsive and friendly.', '5900.00', 'daily', 2, 2, '59 sqm', 0, 'available', 0, 'None', 'none', '2026-08-25 20:09:06', 1),
(48, 1, 'DEMO-044', 8, 12, 'Taytay Road, Antipolo', 'Fully furnished 2-bedroom condo, Taytay Road', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '5800.00', 'daily', 2, 2, '79 sqm', 0, 'available', 1, 'Small pets only, owner to be informed first', 'paid', '2026-08-23 08:09:06', 1),
(49, 1, 'DEMO-045', 9, 5, 'Espana Boulevard, Manila', 'Student dormitory room near Espana Boulevard', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '8200.00', 'monthly', 1, 1, '14 sqm', 1, 'available', 0, 'None', 'paid', '2026-07-23 18:09:06', 1),
(50, 1, 'DEMO-046', 9, 6, 'Timog Avenue, Quezon City', 'Student dormitory room near Timog Avenue', 'Newly painted with good natural light and ventilation. Management is responsive and friendly. Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute.', '8800.00', 'monthly', 1, 1, '28 sqm', 0, 'available', 0, 'None', 'none', '2026-10-19 14:09:06', 1),
(51, 1, 'DEMO-047', 10, 7, 'Rockwell, Makati', 'Affordable bed space near Rockwell', 'Comes with a flexible lease and a reasonable deposit. Viewing is available on weekends. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '3600.00', 'monthly', 1, 1, '8 sqm', 1, 'available', 0, 'None', 'paid', '2026-07-11 00:09:06', 1),
(52, 1, 'DEMO-048', 6, 8, 'Fort Bonifacio, Taguig', 'Corner townhouse with carport, Fort Bonifacio', 'Walking distance to schools, a mall and a clinic. Great for students and young families. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '31900.00', 'monthly', 2, 2, '105 sqm', 1, 'available', 0, 'None', 'none', '2026-06-12 04:09:06', 1),
(53, 1, 'DEMO-049', 9, 7, 'Salcedo Village, Makati', 'Co-ed dorm, walking distance to schools, Makati', 'Quiet and safe neighbourhood with 24/7 security. Ideal for professionals who want a short commute. Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport.', '4500.00', 'monthly', 1, 1, '19 sqm', 1, 'rented', 0, 'None', 'none', '2026-10-12 23:09:06', 1),
(54, 1, 'DEMO-050', 6, 12, 'Cogeo, Antipolo', 'Modern townhouse in gated community, Antipolo', 'Well-lit hallways, CCTV on the premises and a caretaker on site. Easy to reach by public transport. Clean, well-kept and ready to move in. Close to jeepney and transport routes, groceries and eateries.', '29300.00', 'monthly', 3, 1, '70 sqm', 1, 'available', 0, 'None', 'free', '2026-10-25 08:09:06', 1);
INSERT INTO `properties` (`property_id`, `owner_id`, `property_code`, `type_id`, `city_id`, `street_address`, `title`, `description`, `price`, `price_unit`, `bedrooms`, `bathrooms`, `area`, `verified`, `status`, `pets_allowed`, `pet_conditions`, `parking`, `created_at`, `slots`) VALUES
(55, 9, 'PS-VOIAKMJG', 8, 16, 'N/A', '2-bedroom Condominium Unit, Peninsula Garden', 'No description provided', '25500.00', 'monthly', 2, 1, '42 sqm', 0, 'available', 1, 'None', 'free', '2026-11-03 14:13:56', 1),
(57, 64, 'PS-0UR8W3H6', 1, 5, 'N/A', 'Test', '123', '121212.00', 'monthly', 2, 1, '56', 0, 'available', 1, 'None', 'free', '2026-11-04 03:42:49', 1),
(58, 2, 'DEMO-051', 4, 7, 'Poblacion, Makati', 'Cozy studio steps from Poblacion nightlife', 'Compact, fully furnished studio on a high floor with floor-to-ceiling windows. Fast fibre internet is included in the rent. Restaurants, cafes and the Makati Avenue jeepney line are a short walk away.', '18500.00', 'monthly', 1, 1, '24 sqm', 1, 'rented', 0, 'None', 'paid', '2026-08-12 14:30:00', 1),
(59, 2, 'DEMO-052', 8, 8, 'Uptown Bonifacio, Taguig', 'Sky-view 1BR with balcony, Uptown Bonifacio', 'Bright one-bedroom unit with a private balcony facing the BGC skyline. Building has a pool, gym and 24/7 security. Walkable to malls, offices and the BGC bus lines.', '38500.00', 'monthly', 1, 1, '38 sqm', 1, 'available', 1, 'Cats and small dogs only; PHP 1,000 monthly pet fee', 'paid', '2026-09-10 16:15:00', 1),
(60, 13, 'DEMO-053', 2, 6, 'Teachers Village, Quezon City', 'Spacious 4-bedroom family house, Teachers Village', 'Quiet corner house in a gated village with a covered garage for two cars and a small garden. Four bedrooms, three bathrooms and a separate maid\'s room. Near schools, churches and the Quezon Avenue corridor.', '62000.00', 'monthly', 4, 3, '180 sqm', 1, 'available', 1, 'Pets welcome, no exotic animals', 'free', '2026-09-22 20:40:00', 1),
(61, 13, 'DEMO-054', 9, 5, 'Sampaloc, Manila', 'Co-ed dorm near UST with study hall', 'Clean shared rooms with four beds each, individual lockers and a quiet study hall open until midnight. Rent includes water, electricity and Wi-Fi. A five-minute walk to UST and the España jeepney terminal.', '3800.00', 'monthly', 1, 1, 'Shared room, 4 beds', 1, 'available', 0, 'None', 'none', '2026-08-10 17:00:00', 8),
(62, 54, 'DEMO-055', 1, 13, 'Mabolo, Cebu City', 'Modern 2BR apartment in Mabolo', 'Well-ventilated two-bedroom apartment on the second floor with a covered parking slot. Close to Ayala-side malls, hospitals and the airport road. Good for small families or two working professionals.', '22000.00', 'monthly', 2, 1, '55 sqm', 1, 'available', 1, 'Small pets with owner approval', 'free', '2026-09-02 15:20:00', 1),
(63, 54, 'DEMO-056', 5, 14, 'Jaro, Iloilo City', 'Fan room for students near Jaro Plaza', 'Simple, tidy private room good for short stays. Shared kitchen, caretaker on site and a small sari-sari store downstairs. Walking distance to Jaro Cathedral and the plaza.', '1500.00', 'daily', 1, 1, '12 sqm', 1, 'available', 0, 'None', 'none', '2026-09-06 22:10:00', 1),
(64, 59, 'DEMO-057', 6, 9, 'Kapitolyo, Pasig', '3-storey townhouse in Kapitolyo', 'Modern three-storey townhouse with a roof deck, three bedrooms with their own bathrooms and covered parking. Steps from Kapitolyo\'s restaurant strip and a short ride to Ortigas.', '54000.00', 'monthly', 3, 3, '120 sqm', 1, 'rented', 1, 'Dogs and cats allowed', 'free', '2026-08-12 18:25:00', 1),
(65, 59, 'DEMO-058', 10, 10, 'Shaw Boulevard, Mandaluyong', 'Bed space for professionals near Shaw MRT', 'Air-conditioned shared room with only two beds per room, a personal locker and a reading light. Utilities and Wi-Fi are covered. Two minutes from the Shaw Boulevard MRT station.', '3200.00', 'monthly', 1, 1, 'Shared room, 2 beds', 1, 'available', 0, 'None', 'none', '2026-09-15 23:45:00', 4),
(66, 61, 'DEMO-059', 8, 7, 'Salcedo Village, Makati', 'Fully furnished 2BR in Salcedo Village', 'Executive two-bedroom condo rented by the night for business trips and short relocations. All utilities and internet are included, with a concierge and a pool on the amenity deck.', '7500.00', 'daily', 2, 2, '65 sqm', 1, 'available', 0, 'None', 'paid', '2026-09-01 19:00:00', 1),
(67, 61, 'DEMO-060', 1, 12, 'Sumulong Highway, Antipolo', 'Garden apartment with mountain view, Antipolo', 'Ground-floor apartment with a private garden and a view of the hills. Cooler weather all year round and a quiet neighbourhood. Close to the Antipolo cathedral and the Sumulong Highway jeepney route.', '14500.00', 'monthly', 2, 1, '48 sqm', 0, 'available', 1, 'Small pets only', 'free', '2026-10-20 16:05:00', 1),
(68, 63, 'DEMO-061', 2, 15, 'Bacoor, Cavite', 'Two-storey house with garage, Bacoor', 'Three-bedroom house with a garage and a small yard, in a subdivision with 24/7 gate security. The owner has paused new bookings while the roof is being repaired.', '33000.00', 'monthly', 3, 2, '110 sqm', 1, 'inactive', 1, 'Pets allowed', 'free', '2026-08-28 21:30:00', 1),
(69, 63, 'DEMO-062', 5, 11, 'Concepcion Uno, Marikina', 'Private room with own CR, Marikina', 'Private room with its own toilet and bath on the second floor of a family home. Internet and water are included. A short walk to the jeepney terminal and the public market.', '6800.00', 'monthly', 1, 1, '14 sqm', 1, 'available', 0, 'None', 'none', '2026-10-14 17:50:00', 1),
(70, 13, 'PS-KET0KCUD', 1, 5, 'N/A', 'TESTING', '12345', '1234.00', 'monthly', 4, 1, '67', 0, 'available', 1, 'None', 'none', '2026-11-06 07:58:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `property_amenities`
--

CREATE TABLE `property_amenities` (
  `property_id` int(10) UNSIGNED NOT NULL,
  `amenity_id` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_amenities`
--

INSERT INTO `property_amenities` (`property_id`, `amenity_id`) VALUES
(5, 1),
(6, 1),
(8, 1),
(9, 1),
(13, 1),
(14, 1),
(16, 1),
(18, 1),
(20, 1),
(21, 1),
(23, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(30, 1),
(36, 1),
(40, 1),
(42, 1),
(48, 1),
(49, 1),
(52, 1),
(54, 1),
(55, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(64, 1),
(65, 1),
(66, 1),
(68, 1),
(69, 1),
(70, 1),
(5, 2),
(6, 2),
(8, 2),
(9, 2),
(14, 2),
(17, 2),
(20, 2),
(21, 2),
(23, 2),
(31, 2),
(33, 2),
(34, 2),
(36, 2),
(37, 2),
(38, 2),
(40, 2),
(41, 2),
(45, 2),
(47, 2),
(48, 2),
(49, 2),
(50, 2),
(52, 2),
(54, 2),
(55, 2),
(7, 3),
(9, 3),
(10, 3),
(12, 3),
(14, 3),
(15, 3),
(17, 3),
(20, 3),
(23, 3),
(27, 3),
(28, 3),
(32, 3),
(33, 3),
(34, 3),
(35, 3),
(36, 3),
(37, 3),
(39, 3),
(40, 3),
(42, 3),
(44, 3),
(46, 3),
(47, 3),
(51, 3),
(52, 3),
(54, 3),
(55, 3),
(58, 3),
(59, 3),
(60, 3),
(61, 3),
(62, 3),
(63, 3),
(64, 3),
(65, 3),
(66, 3),
(67, 3),
(68, 3),
(69, 3),
(6, 4),
(7, 4),
(8, 4),
(11, 4),
(15, 4),
(16, 4),
(17, 4),
(20, 4),
(21, 4),
(27, 4),
(29, 4),
(33, 4),
(36, 4),
(37, 4),
(40, 4),
(46, 4),
(50, 4),
(52, 4),
(53, 4),
(58, 4),
(59, 4),
(64, 4),
(66, 4),
(5, 5),
(6, 5),
(7, 5),
(8, 5),
(12, 5),
(14, 5),
(15, 5),
(17, 5),
(18, 5),
(21, 5),
(22, 5),
(23, 5),
(24, 5),
(27, 5),
(31, 5),
(33, 5),
(36, 5),
(37, 5),
(41, 5),
(42, 5),
(47, 5),
(48, 5),
(50, 5),
(53, 5),
(54, 5),
(59, 5),
(60, 5),
(62, 5),
(64, 5),
(66, 5),
(67, 5),
(68, 5),
(6, 6),
(7, 6),
(8, 6),
(17, 6),
(19, 6),
(20, 6),
(24, 6),
(26, 6),
(27, 6),
(28, 6),
(29, 6),
(31, 6),
(32, 6),
(33, 6),
(38, 6),
(42, 6),
(43, 6),
(45, 6),
(49, 6),
(54, 6),
(55, 6),
(58, 6),
(59, 6),
(62, 6),
(64, 6),
(66, 6);

-- --------------------------------------------------------

--
-- Table structure for table `property_blocked_dates`
--

CREATE TABLE `property_blocked_dates` (
  `block_id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `note` varchar(120) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_blocked_dates`
--

INSERT INTO `property_blocked_dates` (`block_id`, `property_id`, `start_date`, `end_date`, `note`, `created_at`) VALUES
(3, 12, '2026-11-18', '2026-11-22', 'Owner staying over', '2026-11-04 17:00:00'),
(4, 20, '2026-11-10', '2026-11-14', 'Aircon servicing', '2026-11-04 17:00:00'),
(5, 23, '2026-12-24', '2027-01-02', 'Holiday - family use', '2026-11-04 17:00:00'),
(6, 32, '2026-11-10', '2026-11-12', 'Plumbing repair', '2026-11-04 17:00:00'),
(7, 34, '2026-11-15', '2026-11-20', 'Repainting', '2026-11-04 17:00:00'),
(8, 43, '2026-11-12', '2026-11-15', 'Owner use', '2026-11-04 17:00:00'),
(9, 42, '2026-12-01', '2026-12-05', 'Maintenance', '2026-11-04 17:00:00'),
(10, 60, '2026-11-16', '2026-11-19', 'Garden works', '2026-11-04 17:00:00'),
(11, 47, '2026-11-26', '2026-11-30', 'Booked offline', '2026-11-04 17:00:00'),
(12, 48, '2026-12-15', '2026-12-19', 'Owner use', '2026-11-04 17:00:00'),
(13, 25, '2026-11-08', '2026-11-10', 'Deep cleaning', '2026-11-04 17:00:00'),
(14, 50, '2026-12-10', '2026-12-14', 'Owner use', '2026-11-04 17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `property_images`
--

CREATE TABLE `property_images` (
  `image_id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_images`
--

INSERT INTO `property_images` (`image_id`, `property_id`, `image_path`, `is_primary`, `sort_order`, `created_at`) VALUES
(2, 5, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(3, 6, 'assets/images/balcony-taguig.jpg', 1, 0, '2026-10-29 13:09:07'),
(4, 6, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(5, 6, 'assets/images/condo-ortigas.jpg', 0, 2, '2026-10-29 13:09:07'),
(6, 7, 'assets/images/balcony-taguig.jpg', 1, 0, '2026-10-29 13:09:07'),
(7, 8, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(8, 8, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(9, 8, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-10-29 13:09:07'),
(10, 9, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(11, 9, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(12, 10, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(13, 10, 'assets/images/marikina-townhouse.jpg', 0, 1, '2026-10-29 13:09:07'),
(14, 11, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(15, 11, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(16, 12, 'assets/images/balcony-taguig.jpg', 1, 0, '2026-10-29 13:09:07'),
(17, 12, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-10-29 13:09:07'),
(18, 13, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(19, 13, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(20, 13, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-10-29 13:09:07'),
(21, 14, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(22, 14, 'assets/images/balcony-taguig.jpg', 0, 1, '2026-10-29 13:09:07'),
(23, 15, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(24, 16, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(25, 16, 'assets/images/balcony-taguig.jpg', 0, 1, '2026-10-29 13:09:07'),
(26, 16, 'assets/images/bedroom-taft.jpg', 0, 2, '2026-10-29 13:09:07'),
(27, 17, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(28, 17, 'assets/images/house-cavite.jpg', 0, 1, '2026-10-29 13:09:07'),
(29, 18, 'assets/images/house-cavite.jpg', 1, 0, '2026-10-29 13:09:07'),
(30, 18, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-10-29 13:09:07'),
(31, 19, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(32, 20, 'assets/images/house-cavite.jpg', 1, 0, '2026-10-29 13:09:07'),
(33, 20, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-10-29 13:09:07'),
(34, 21, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(35, 22, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(36, 23, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(37, 23, 'assets/images/marikina-townhouse.jpg', 0, 1, '2026-10-29 13:09:07'),
(38, 24, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(39, 25, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(40, 26, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(41, 26, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(42, 26, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-10-29 13:09:07'),
(43, 27, 'assets/images/balcony-taguig.jpg', 1, 0, '2026-10-29 13:09:07'),
(44, 27, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-10-29 13:09:07'),
(45, 28, 'assets/images/marikina-townhouse.jpg', 1, 0, '2026-10-29 13:09:07'),
(46, 28, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-10-29 13:09:07'),
(47, 29, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(48, 29, 'assets/images/dorm-ust.jpg', 0, 1, '2026-10-29 13:09:07'),
(49, 30, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(50, 30, 'assets/images/dorm-ust.jpg', 0, 1, '2026-10-29 13:09:07'),
(51, 31, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(52, 31, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(53, 32, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(54, 33, 'assets/images/house-cavite.jpg', 1, 0, '2026-10-29 13:09:07'),
(55, 34, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(56, 34, 'assets/images/balcony-taguig.jpg', 0, 1, '2026-10-29 13:09:07'),
(57, 35, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(58, 35, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(59, 36, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(60, 36, 'assets/images/house-cavite.jpg', 0, 1, '2026-10-29 13:09:07'),
(61, 37, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(62, 37, 'assets/images/balcony-taguig.jpg', 0, 1, '2026-10-29 13:09:07'),
(63, 37, 'assets/images/condo-ortigas.jpg', 0, 2, '2026-10-29 13:09:07'),
(64, 38, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(65, 39, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(66, 39, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(67, 40, 'assets/images/house-cavite.jpg', 1, 0, '2026-10-29 13:09:07'),
(68, 41, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(69, 41, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(70, 42, 'assets/images/balcony-taguig.jpg', 1, 0, '2026-10-29 13:09:07'),
(71, 42, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-10-29 13:09:07'),
(72, 42, 'assets/images/bedroom-taft.jpg', 0, 2, '2026-10-29 13:09:07'),
(73, 43, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(74, 43, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(75, 44, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(76, 44, 'assets/images/dorm-ust.jpg', 0, 1, '2026-10-29 13:09:07'),
(77, 45, 'assets/images/marikina-townhouse.jpg', 1, 0, '2026-10-29 13:09:07'),
(78, 45, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-10-29 13:09:07'),
(79, 46, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(80, 47, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-10-29 13:09:07'),
(81, 47, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(82, 47, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-10-29 13:09:07'),
(83, 48, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(84, 49, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(85, 50, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(86, 50, 'assets/images/dorm-ust.jpg', 0, 1, '2026-10-29 13:09:07'),
(87, 51, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-29 13:09:07'),
(88, 51, 'assets/images/dorm-ust.jpg', 0, 1, '2026-10-29 13:09:07'),
(89, 52, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(90, 52, 'assets/images/marikina-townhouse.jpg', 0, 1, '2026-10-29 13:09:07'),
(91, 53, 'assets/images/dorm-ust.jpg', 1, 0, '2026-10-29 13:09:07'),
(92, 53, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-10-29 13:09:07'),
(93, 54, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-29 13:09:07'),
(94, 54, 'assets/images/marikina-townhouse.jpg', 0, 1, '2026-10-29 13:09:07'),
(98, 55, 'assets/uploads/properties/e9a0668124cb7eb6ccbb.jpg', 1, 0, '2026-11-03 15:54:38'),
(99, 57, 'assets/uploads/properties/3024a42378339eace7fc.jpg', 1, 0, '2026-11-04 03:42:49'),
(100, 58, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-08-12 14:30:00'),
(101, 58, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-08-12 14:30:00'),
(102, 58, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-08-12 14:30:00'),
(103, 59, 'assets/images/balcony-taguig.jpg', 1, 0, '2026-09-10 16:15:00'),
(104, 59, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-09-10 16:15:00'),
(105, 59, 'assets/images/bedroom-taft.jpg', 0, 2, '2026-09-10 16:15:00'),
(106, 60, 'assets/images/house-cavite.jpg', 1, 0, '2026-09-22 20:40:00'),
(107, 60, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-09-22 20:40:00'),
(108, 60, 'assets/images/marikina-townhouse.jpg', 0, 2, '2026-09-22 20:40:00'),
(109, 61, 'assets/images/dorm-ust.jpg', 1, 0, '2026-08-10 17:00:00'),
(110, 61, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-08-10 17:00:00'),
(111, 62, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-09-02 15:20:00'),
(112, 62, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-09-02 15:20:00'),
(113, 62, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-09-02 15:20:00'),
(114, 63, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-09-06 22:10:00'),
(115, 63, 'assets/images/dorm-ust.jpg', 0, 1, '2026-09-06 22:10:00'),
(116, 64, 'assets/images/marikina-townhouse.jpg', 1, 0, '2026-08-12 18:25:00'),
(117, 64, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-08-12 18:25:00'),
(118, 64, 'assets/images/house-cavite.jpg', 0, 2, '2026-08-12 18:25:00'),
(119, 65, 'assets/images/dorm-ust.jpg', 1, 0, '2026-09-15 23:45:00'),
(120, 65, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-09-15 23:45:00'),
(121, 66, 'assets/images/condo-ortigas.jpg', 1, 0, '2026-09-01 19:00:00'),
(122, 66, 'assets/images/balcony-taguig.jpg', 0, 1, '2026-09-01 19:00:00'),
(123, 66, 'assets/images/bedroom-taft.jpg', 0, 2, '2026-09-01 19:00:00'),
(124, 67, 'assets/images/duplex-antipolo.jpg', 1, 0, '2026-10-20 16:05:00'),
(125, 67, 'assets/images/house-cavite.jpg', 0, 1, '2026-10-20 16:05:00'),
(126, 68, 'assets/images/house-cavite.jpg', 1, 0, '2026-08-28 21:30:00'),
(127, 68, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-08-28 21:30:00'),
(128, 69, 'assets/images/bedroom-taft.jpg', 1, 0, '2026-10-14 17:50:00'),
(129, 69, 'assets/images/marikina-townhouse.jpg', 0, 1, '2026-10-14 17:50:00'),
(130, 5, 'assets/images/balcony-taguig.jpg', 0, 1, '2026-11-05 18:00:00'),
(131, 5, 'assets/images/bedroom-taft.jpg', 0, 2, '2026-11-05 18:00:00'),
(132, 7, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-11-05 18:00:00'),
(133, 7, 'assets/images/bedroom-taft.jpg', 0, 2, '2026-11-05 18:00:00'),
(134, 15, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-11-05 18:00:00'),
(135, 19, 'assets/images/dorm-ust.jpg', 0, 1, '2026-11-05 18:00:00'),
(136, 19, 'assets/images/condo-ortigas.jpg', 0, 2, '2026-11-05 18:00:00'),
(137, 21, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-11-05 18:00:00'),
(138, 21, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-11-05 18:00:00'),
(139, 22, 'assets/images/dorm-ust.jpg', 0, 1, '2026-11-05 18:00:00'),
(140, 22, 'assets/images/condo-ortigas.jpg', 0, 2, '2026-11-05 18:00:00'),
(141, 24, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-11-05 18:00:00'),
(142, 24, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-11-05 18:00:00'),
(143, 25, 'assets/images/dorm-ust.jpg', 0, 1, '2026-11-05 18:00:00'),
(144, 25, 'assets/images/condo-ortigas.jpg', 0, 2, '2026-11-05 18:00:00'),
(145, 32, 'assets/images/house-cavite.jpg', 0, 1, '2026-11-05 18:00:00'),
(146, 32, 'assets/images/marikina-townhouse.jpg', 0, 2, '2026-11-05 18:00:00'),
(147, 33, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-11-05 18:00:00'),
(148, 33, 'assets/images/marikina-townhouse.jpg', 0, 2, '2026-11-05 18:00:00'),
(149, 38, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-11-05 18:00:00'),
(150, 38, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-11-05 18:00:00'),
(151, 40, 'assets/images/duplex-antipolo.jpg', 0, 1, '2026-11-05 18:00:00'),
(152, 40, 'assets/images/marikina-townhouse.jpg', 0, 2, '2026-11-05 18:00:00'),
(153, 46, 'assets/images/bedroom-taft.jpg', 0, 1, '2026-11-05 18:00:00'),
(154, 48, 'assets/images/condo-ortigas.jpg', 0, 1, '2026-11-05 18:00:00'),
(155, 48, 'assets/images/balcony-taguig.jpg', 0, 2, '2026-11-05 18:00:00'),
(156, 49, 'assets/images/dorm-ust.jpg', 0, 1, '2026-11-05 18:00:00'),
(157, 70, 'assets/uploads/properties/7158603155e012a06e99.jpg', 1, 0, '2026-11-06 07:58:45');

-- --------------------------------------------------------

--
-- Table structure for table `property_payment_methods`
--

CREATE TABLE `property_payment_methods` (
  `property_id` int(10) UNSIGNED NOT NULL,
  `method_id` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_payment_methods`
--

INSERT INTO `property_payment_methods` (`property_id`, `method_id`) VALUES
(5, 2),
(6, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(15, 2),
(16, 2),
(17, 2),
(18, 2),
(19, 2),
(20, 2),
(21, 2),
(22, 2),
(23, 2),
(24, 2),
(25, 2),
(26, 2),
(27, 2),
(28, 2),
(29, 2),
(30, 2),
(31, 2),
(32, 2),
(33, 2),
(34, 2),
(35, 2),
(36, 2),
(37, 2),
(38, 2),
(39, 2),
(40, 2),
(41, 2),
(42, 2),
(43, 2),
(44, 2),
(45, 2),
(46, 2),
(47, 2),
(48, 2),
(49, 2),
(50, 2),
(51, 2),
(52, 2),
(53, 2),
(54, 2),
(55, 2),
(57, 2),
(58, 2),
(59, 2),
(60, 2),
(61, 2),
(62, 2),
(63, 2),
(64, 2),
(65, 2),
(66, 2),
(67, 2),
(68, 2),
(69, 2),
(6, 3),
(7, 3),
(9, 3),
(11, 3),
(12, 3),
(14, 3),
(16, 3),
(17, 3),
(19, 3),
(21, 3),
(22, 3),
(24, 3),
(26, 3),
(27, 3),
(29, 3),
(31, 3),
(32, 3),
(34, 3),
(36, 3),
(37, 3),
(39, 3),
(41, 3),
(42, 3),
(43, 3),
(44, 3),
(46, 3),
(47, 3),
(49, 3),
(51, 3),
(52, 3),
(54, 3),
(58, 3),
(60, 3),
(61, 3),
(63, 3),
(65, 3),
(66, 3),
(69, 3),
(5, 4),
(7, 4),
(9, 4),
(10, 4),
(12, 4),
(14, 4),
(15, 4),
(17, 4),
(18, 4),
(19, 4),
(20, 4),
(22, 4),
(24, 4),
(25, 4),
(27, 4),
(29, 4),
(30, 4),
(32, 4),
(34, 4),
(35, 4),
(37, 4),
(39, 4),
(40, 4),
(42, 4),
(44, 4),
(45, 4),
(47, 4),
(49, 4),
(50, 4),
(52, 4),
(54, 4),
(55, 4),
(58, 4),
(59, 4),
(60, 4),
(64, 4),
(66, 4),
(67, 4),
(69, 4),
(8, 14),
(9, 14),
(13, 14),
(14, 14),
(18, 14),
(19, 14),
(23, 14),
(24, 14),
(28, 14),
(29, 14),
(33, 14),
(34, 14),
(38, 14),
(39, 14),
(40, 14),
(43, 14),
(44, 14),
(47, 14),
(48, 14),
(49, 14),
(53, 14),
(54, 14),
(59, 14),
(62, 14),
(64, 14),
(66, 14),
(68, 14),
(70, 14);

-- --------------------------------------------------------

--
-- Table structure for table `property_tags`
--

CREATE TABLE `property_tags` (
  `property_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_tags`
--

INSERT INTO `property_tags` (`property_id`, `tag_id`, `sort_order`) VALUES
(5, 11, 1),
(5, 14, 2),
(5, 16, 3),
(5, 19, 0),
(6, 3, 1),
(6, 16, 2),
(6, 17, 0),
(7, 11, 2),
(7, 14, 3),
(7, 16, 0),
(7, 19, 1),
(8, 11, 1),
(8, 14, 2),
(8, 16, 3),
(8, 19, 0),
(9, 1, 1),
(9, 16, 0),
(9, 17, 2),
(10, 1, 1),
(10, 3, 0),
(10, 13, 2),
(11, 3, 2),
(11, 15, 1),
(11, 16, 0),
(12, 11, 3),
(12, 14, 0),
(12, 16, 1),
(12, 19, 2),
(13, 1, 1),
(13, 3, 0),
(13, 16, 2),
(14, 1, 0),
(14, 3, 3),
(14, 16, 1),
(14, 17, 2),
(15, 3, 1),
(15, 15, 2),
(15, 16, 3),
(15, 17, 0),
(16, 11, 1),
(16, 14, 0),
(16, 16, 2),
(17, 1, 2),
(17, 3, 0),
(17, 4, 1),
(17, 13, 3),
(18, 1, 1),
(18, 3, 3),
(18, 4, 2),
(18, 13, 0),
(19, 3, 0),
(19, 16, 2),
(19, 17, 1),
(20, 1, 1),
(20, 3, 0),
(20, 4, 3),
(20, 13, 2),
(21, 1, 0),
(21, 3, 1),
(21, 17, 2),
(22, 1, 2),
(22, 3, 1),
(22, 17, 0),
(23, 1, 3),
(23, 3, 1),
(23, 4, 2),
(23, 13, 0),
(24, 1, 0),
(24, 3, 1),
(24, 16, 2),
(24, 17, 3),
(25, 1, 3),
(25, 3, 0),
(25, 16, 1),
(25, 17, 2),
(26, 11, 2),
(26, 14, 1),
(26, 16, 0),
(26, 19, 3),
(27, 1, 3),
(27, 3, 0),
(27, 16, 2),
(27, 17, 1),
(28, 1, 2),
(28, 4, 0),
(28, 13, 1),
(29, 3, 0),
(29, 15, 1),
(29, 16, 3),
(29, 17, 2),
(30, 3, 2),
(30, 15, 3),
(30, 16, 0),
(30, 17, 1),
(31, 15, 1),
(31, 16, 0),
(31, 17, 2),
(32, 3, 2),
(32, 4, 1),
(32, 13, 0),
(33, 1, 0),
(33, 4, 1),
(33, 13, 2),
(34, 11, 0),
(34, 14, 3),
(34, 16, 2),
(34, 19, 1),
(35, 1, 1),
(35, 3, 3),
(35, 16, 0),
(35, 17, 2),
(36, 1, 2),
(36, 3, 0),
(36, 4, 1),
(37, 1, 3),
(37, 3, 1),
(37, 16, 0),
(37, 17, 2),
(38, 1, 0),
(38, 3, 2),
(38, 17, 1),
(39, 11, 1),
(39, 14, 3),
(39, 16, 0),
(39, 19, 2),
(40, 1, 3),
(40, 3, 2),
(40, 4, 0),
(40, 13, 1),
(41, 3, 2),
(41, 15, 0),
(41, 16, 1),
(41, 17, 3),
(42, 1, 1),
(42, 3, 3),
(42, 16, 2),
(42, 17, 0),
(43, 1, 1),
(43, 3, 0),
(43, 16, 2),
(44, 1, 2),
(44, 3, 3),
(44, 16, 0),
(44, 17, 1),
(45, 1, 0),
(45, 4, 2),
(45, 13, 1),
(46, 3, 3),
(46, 15, 0),
(46, 16, 2),
(46, 17, 1),
(47, 11, 1),
(47, 14, 2),
(47, 16, 0),
(48, 11, 3),
(48, 14, 1),
(48, 16, 0),
(48, 19, 2),
(49, 3, 1),
(49, 16, 2),
(49, 17, 0),
(50, 3, 3),
(50, 15, 2),
(50, 16, 0),
(50, 17, 1),
(51, 3, 3),
(51, 15, 2),
(51, 16, 0),
(51, 17, 1),
(52, 1, 2),
(52, 3, 1),
(52, 13, 0),
(53, 3, 0),
(53, 15, 3),
(53, 16, 2),
(53, 17, 1),
(54, 1, 1),
(54, 4, 2),
(54, 13, 0),
(55, 1, 0),
(55, 2, 1),
(55, 3, 2),
(55, 4, 3),
(58, 14, 1),
(58, 16, 0),
(58, 18, 2),
(58, 19, 3),
(59, 11, 0),
(59, 13, 2),
(59, 16, 3),
(59, 19, 1),
(60, 1, 1),
(60, 3, 0),
(60, 4, 3),
(60, 13, 2),
(61, 3, 1),
(61, 15, 0),
(61, 16, 3),
(61, 17, 2),
(62, 1, 3),
(62, 11, 0),
(62, 12, 1),
(62, 16, 2),
(63, 1, 0),
(63, 3, 1),
(63, 17, 2),
(64, 12, 2),
(64, 13, 3),
(64, 16, 1),
(64, 18, 0),
(65, 11, 1),
(65, 14, 0),
(65, 16, 2),
(66, 11, 0),
(66, 16, 1),
(66, 18, 3),
(66, 19, 2),
(67, 1, 0),
(67, 3, 2),
(67, 13, 1),
(68, 1, 1),
(68, 3, 0),
(68, 16, 2),
(68, 17, 3),
(69, 12, 2),
(69, 16, 1),
(69, 17, 0);

-- --------------------------------------------------------

--
-- Table structure for table `property_types`
--

CREATE TABLE `property_types` (
  `type_id` smallint(5) UNSIGNED NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_types`
--

INSERT INTO `property_types` (`type_id`, `type_name`) VALUES
(1, 'Apartment'),
(10, 'Bed Space'),
(3, 'Condo'),
(8, 'Condominium'),
(9, 'Dormitory'),
(2, 'House'),
(5, 'Room'),
(4, 'Studio'),
(6, 'Townhouse');

-- --------------------------------------------------------

--
-- Table structure for table `property_utilities`
--

CREATE TABLE `property_utilities` (
  `property_id` int(10) UNSIGNED NOT NULL,
  `utility_id` tinyint(3) UNSIGNED NOT NULL,
  `coverage` enum('included','separate','unavailable') NOT NULL DEFAULT 'separate'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_utilities`
--

INSERT INTO `property_utilities` (`property_id`, `utility_id`, `coverage`) VALUES
(5, 1, 'separate'),
(5, 2, 'included'),
(5, 3, 'included'),
(6, 1, 'separate'),
(6, 2, 'separate'),
(6, 3, 'separate'),
(7, 1, 'separate'),
(7, 2, 'included'),
(7, 3, 'separate'),
(8, 1, 'separate'),
(8, 2, 'separate'),
(8, 3, 'separate'),
(9, 1, 'separate'),
(9, 2, 'separate'),
(9, 3, 'included'),
(10, 1, 'separate'),
(10, 2, 'separate'),
(10, 3, 'unavailable'),
(11, 1, 'included'),
(11, 2, 'included'),
(11, 3, 'separate'),
(12, 1, 'separate'),
(12, 2, 'separate'),
(12, 3, 'separate'),
(13, 1, 'separate'),
(13, 2, 'included'),
(13, 3, 'separate'),
(14, 1, 'included'),
(14, 2, 'separate'),
(14, 3, 'separate'),
(15, 1, 'included'),
(15, 2, 'included'),
(15, 3, 'included'),
(16, 1, 'included'),
(16, 2, 'separate'),
(16, 3, 'separate'),
(17, 1, 'separate'),
(17, 2, 'separate'),
(17, 3, 'separate'),
(18, 1, 'separate'),
(18, 2, 'separate'),
(18, 3, 'unavailable'),
(19, 1, 'included'),
(19, 2, 'included'),
(19, 3, 'separate'),
(20, 1, 'separate'),
(20, 2, 'separate'),
(20, 3, 'separate'),
(21, 1, 'separate'),
(21, 2, 'included'),
(21, 3, 'included'),
(22, 1, 'separate'),
(22, 2, 'separate'),
(22, 3, 'separate'),
(23, 1, 'included'),
(23, 2, 'separate'),
(23, 3, 'separate'),
(24, 1, 'separate'),
(24, 2, 'separate'),
(24, 3, 'separate'),
(25, 1, 'separate'),
(25, 2, 'separate'),
(25, 3, 'unavailable'),
(26, 1, 'separate'),
(26, 2, 'included'),
(26, 3, 'included'),
(27, 1, 'separate'),
(27, 2, 'separate'),
(27, 3, 'unavailable'),
(28, 1, 'included'),
(28, 2, 'separate'),
(28, 3, 'included'),
(29, 1, 'included'),
(29, 2, 'included'),
(29, 3, 'included'),
(30, 1, 'included'),
(30, 2, 'included'),
(30, 3, 'separate'),
(31, 1, 'included'),
(31, 2, 'included'),
(31, 3, 'included'),
(32, 1, 'separate'),
(32, 2, 'separate'),
(32, 3, 'separate'),
(33, 1, 'included'),
(33, 2, 'separate'),
(33, 3, 'separate'),
(34, 1, 'separate'),
(34, 2, 'separate'),
(34, 3, 'included'),
(35, 1, 'separate'),
(35, 2, 'included'),
(35, 3, 'separate'),
(36, 1, 'included'),
(36, 2, 'separate'),
(36, 3, 'included'),
(37, 1, 'separate'),
(37, 2, 'separate'),
(37, 3, 'unavailable'),
(38, 1, 'separate'),
(38, 2, 'separate'),
(38, 3, 'separate'),
(39, 1, 'included'),
(39, 2, 'separate'),
(39, 3, 'separate'),
(40, 1, 'separate'),
(40, 2, 'separate'),
(40, 3, 'included'),
(41, 1, 'included'),
(41, 2, 'included'),
(41, 3, 'included'),
(42, 1, 'separate'),
(42, 2, 'separate'),
(42, 3, 'separate'),
(43, 1, 'separate'),
(43, 2, 'included'),
(43, 3, 'unavailable'),
(44, 1, 'separate'),
(44, 2, 'separate'),
(44, 3, 'separate'),
(45, 1, 'separate'),
(45, 2, 'included'),
(45, 3, 'unavailable'),
(46, 1, 'included'),
(46, 2, 'included'),
(46, 3, 'separate'),
(47, 1, 'separate'),
(47, 2, 'separate'),
(47, 3, 'separate'),
(48, 1, 'included'),
(48, 2, 'separate'),
(48, 3, 'separate'),
(49, 1, 'included'),
(49, 2, 'included'),
(49, 3, 'included'),
(50, 1, 'included'),
(50, 2, 'included'),
(50, 3, 'separate'),
(51, 1, 'included'),
(51, 2, 'included'),
(51, 3, 'separate'),
(52, 1, 'separate'),
(52, 2, 'separate'),
(52, 3, 'separate'),
(53, 1, 'included'),
(53, 2, 'included'),
(53, 3, 'included'),
(54, 1, 'included'),
(54, 2, 'separate'),
(54, 3, 'separate'),
(55, 1, 'separate'),
(55, 2, 'separate'),
(55, 3, 'separate'),
(57, 1, 'separate'),
(57, 2, 'separate'),
(57, 3, 'separate'),
(58, 1, 'separate'),
(58, 2, 'included'),
(58, 3, 'included'),
(59, 1, 'separate'),
(59, 2, 'separate'),
(59, 3, 'included'),
(60, 1, 'separate'),
(60, 2, 'separate'),
(60, 3, 'separate'),
(61, 1, 'included'),
(61, 2, 'included'),
(61, 3, 'included'),
(62, 1, 'separate'),
(62, 2, 'separate'),
(62, 3, 'included'),
(63, 1, 'included'),
(63, 2, 'included'),
(63, 3, 'separate'),
(64, 1, 'separate'),
(64, 2, 'separate'),
(64, 3, 'separate'),
(65, 1, 'included'),
(65, 2, 'included'),
(65, 3, 'included'),
(66, 1, 'included'),
(66, 2, 'included'),
(66, 3, 'included'),
(67, 1, 'separate'),
(67, 2, 'separate'),
(67, 3, 'separate'),
(68, 1, 'separate'),
(68, 2, 'separate'),
(68, 3, 'separate'),
(69, 1, 'separate'),
(69, 2, 'included'),
(69, 3, 'included'),
(70, 1, 'separate'),
(70, 2, 'separate'),
(70, 3, 'separate');

-- --------------------------------------------------------

--
-- Table structure for table `remember_tokens`
--

CREATE TABLE `remember_tokens` (
  `token_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `selector` char(24) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `remember_tokens`
--

INSERT INTO `remember_tokens` (`token_id`, `user_id`, `selector`, `token_hash`, `expires_at`, `created_at`) VALUES
(3, 19, '616497c6d54e2a09308c3c55', 'cbc6962cd41396c638c9b99aa6cd29a1773f78e506e1059b59e95e470b125eb3', '2026-12-02 23:21:10', '2026-11-02 23:21:10'),
(4, 20, 'c4284ec11a696e42bb6dcf39', '5215637036430b86b7eea8cef73cb9d1017618d52c2f4cc66baf5105ce3577af', '2026-12-02 23:25:26', '2026-11-02 23:25:26'),
(5, 22, 'bc168b9e169d8157f0521377', '4d4add455c7fee9a0e9776198d23559ed6246907f6c246b68c6d0c817d17db90', '2026-12-02 23:40:48', '2026-11-02 23:40:48'),
(6, 26, '49caa1a10c97d2b48fb3f82c', '4c7abebf02449112839967552abef6d775228931190f57875e91559c6819c6d9', '2026-12-03 04:09:54', '2026-11-03 04:09:54'),
(7, 46, '4161c54ce2f1657a032fd0b2', '9fca953a1af6d888d41f441540334c0d161350fd2c6b53f7c7dabda0d1a70c0c', '2026-12-03 06:24:24', '2026-11-03 06:24:24'),
(8, 52, '368961a80a16715f84d5b0b1', '38bcb952609fdb1398e101243ee5c7e7b91775c812a3e01e9014194a1ba169d6', '2026-12-03 06:38:24', '2026-11-03 06:38:24'),
(9, 53, '9d00aa3823a2dd6351d70e91', '00ee82ef900c6a73d34f7e26a8b51643a74a78f32a3549c0298d593a6b5fd1c9', '2026-12-03 06:38:46', '2026-11-03 06:38:46'),
(10, 9, '93de37e0759c32c04b059237', '812fc6dff8b356ccf18197c8041036ee7b892f9130bab1609ce8001da7dbbb11', '2026-12-03 16:14:46', '2026-11-03 16:14:46');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `role_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(2, 'admin'),
(1, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `tag_id` int(10) UNSIGNED NOT NULL,
  `tag_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`tag_id`, `tag_name`) VALUES
(5, '1234567'),
(1, 'church'),
(18, 'coffee shops'),
(19, 'gym'),
(12, 'hospital'),
(17, 'jeepney terminal'),
(11, 'mall'),
(2, 'paco market'),
(13, 'park'),
(4, 'playground'),
(3, 'school'),
(16, 'supermarket'),
(14, 'train station'),
(15, 'university');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `account_no` varchar(13) DEFAULT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(20) NOT NULL DEFAULT '',
  `facebook` varchar(255) NOT NULL DEFAULT '',
  `member_type` enum('unset','renter','owner') NOT NULL DEFAULT 'unset'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `account_no`, `full_name`, `email`, `password`, `role_id`, `email_verified`, `created_at`, `phone`, `facebook`, `member_type`) VALUES
(1, '202610-000001', 'clarence, i.', 'clarenceignacio67@gmail.com', '$2y$12$RfrlDA/aHGX/JUc4FPTu9OfJh2/ikw51LxO436/RdbleUmO6.xq0u', 2, 1, '2026-10-25 12:00:42', '09123456789', '', 'owner'),
(2, '202610-000002', 'Peter Linus R Ferrer', 'peterlinusferrer@gmail.com', '$2y$12$cIwyLYkKehelYgfp7.6koerqbpkqAWb2.bxjzbGKGhaO3iYK7dy7.', 2, 1, '2026-10-27 15:45:18', '09930875375', '', 'owner'),
(3, '202610-000003', 'Peter Ramizares', 'ferrerpeter440@gmail.com', '$2y$12$fJtRbvkE0opnINAiYX0bAuxv1FuJ.Bam5zpQKhDfvkO0TW9dCipU2', 1, 1, '2026-10-27 15:51:10', '', '', 'unset'),
(4, '202610-000004', 'clarence', 'clarenceignacio68@gmail.com', '$2y$12$f5rTsB6idaAqlZuysFklb.3VWrDQAVP.B9BYIkyF59/ID1.1qlvTu', 1, 1, '2026-10-27 15:53:29', '', '', 'unset'),
(5, '202610-000005', 'Linus Ferrer', 'linuspeter0122@gmail.com', '$2y$12$wIyOsoO9dYbWEEaTkByTU.NgkFz1xaJagHjpuZWWBqBXX6iSOPmiq', 1, 1, '2026-10-27 15:55:24', '', '', 'unset'),
(7, '202610-000007', 'monkeman630', 'manmonke630@gmail.com', '$2y$12$g1ZRJpnrkPA5liZ0JyksveIupt.Xy9V4fgHV9oikEHGVlek8vIN5u', 1, 1, '2026-10-27 17:06:15', '', '', 'unset'),
(9, '202610-000009', 'Gale Nuez', 'galeyantonette@gmail.com', '$2y$12$pW3S4rO2lTgFlPRLgcikUO1BYSpDV1C4C0RuksPfJMfA/yJzfyETO', 2, 1, '2026-10-28 04:37:55', '09216540706', '', 'renter'),
(10, '202610-000010', 'Peter Ferrer Ramizares', 'peterferrer963@gmail.com', '$2y$12$MQ1UTH2ke7fnkc3TsFtGUeXjJAdpoKSJRSx4ZXs66cP13Uh7XWRLO', 1, 1, '2026-10-28 07:07:49', '', '', 'unset'),
(13, '202610-000013', 'hottog', 'hottog191@gmail.com', '$2y$12$Hx9yWGRSuNhFSji3f80zduGBA7akTLdukpTKqK/pEsRb0skyM3ANC', 2, 1, '2026-10-28 14:48:31', '09123456789', '', 'owner'),
(14, '202610-000014', 'Hart Emutan', 'emutanhart@gmail.com', '$2y$12$qTUNYJri5X.MVBzGezY5f.aDilIFhCiDc8nZL77jDRQvrlYGKceo.', 2, 1, '2026-10-29 01:48:33', '', '', 'unset'),
(15, '202610-000015', 'MARY BLESS BERBOSIDAD', 'mbeberbosidad2025@plm.edu.ph', '$2y$12$zUCWlyp4xRALlXXMP0YJ9O2k8svWGPV60kYbRuGscDkTMuMLdt0Rq', 1, 1, '2026-10-29 13:44:31', '', '', 'unset'),
(16, '202611-000016', 'gale nuez', 'nuezantonette@gmail.com', '$2y$12$nMRfqKvB9QcyW0G6t5KvmOraGhzF7Oy5zTSkG46dndS8lOUXsVXvm', 1, 1, '2026-11-02 13:26:05', '', '', 'unset'),
(17, '202611-000017', 'MARY BLESS BERBOSIDAD', 'mbberbosidad@gmail.com', '$2y$12$prIBHyWpcJt01Bwzau3XWOI1Mk4ZsW2pPOMpMeRata7bZyPJesqyC', 1, 1, '2026-11-03 04:43:12', '09602868130', 'dacebook.com/berbosidadbless', 'renter'),
(18, '202611-000018', 'Michaela Merez', 'raeyoon284@gmail.com', '$2y$12$Jh/pGNdFLJrUhgc1bzR4DeYffsE25dWAYkMNOf8afFwYR5BBoCKGC', 1, 1, '2026-11-03 07:10:35', '0994 848 9046', '', 'renter'),
(19, '202611-000019', 'Loria, Kathrine Denise A.', 'kthrinedenise@gmail.com', '$2y$12$7HEfVj6zcP5Htro3j5f3GurMqSxrTGQ809gHPNgbw2cFkU4vjPLga', 1, 1, '2026-11-03 07:20:17', '09171074557', '', 'renter'),
(20, '202611-000020', 'Ghian Andrei J. Cruz', 'ghiancruz04@gmail.com', '$2y$12$ghx.Tj/A2omf/qY91ZtJteN0a5B3L4yYNfgRNOR6Hzg0AZw9QL0Pi', 1, 1, '2026-11-03 07:24:54', '09489003909', '', 'renter'),
(21, '202611-000021', 'Cabrera, Khimberly Rhein O.', 'ogsonarkhimberlyrhein@gmail.com', '$2y$12$na7hKgcYd8HzbAmDOaV7eOLaQu0rPiZug8RsL/8mlliZinOu7bvX2', 1, 1, '2026-11-03 07:35:49', '', '', 'unset'),
(22, '202611-000022', 'Reece Arron Aguanta', 'reecearroncaguanta@gmail.com', '$2y$12$oUtDcG2TzbE/kRjMpv7Wb.an4V1yDLiII45LsM/kwXY/pTM.H98qe', 1, 1, '2026-11-03 07:39:14', '09616524230', 'facebook.com/rc.agc', 'renter'),
(23, '202611-000023', 'Christine Espino', 'espino.christine95@gmail.com', '$2y$12$H86JL0Qy5tiDSPbq0cbE0Ot31ZLDTdRxbCzrQme0nP.7zVAfhkeum', 1, 1, '2026-11-03 07:41:32', '', '', 'unset'),
(24, '202611-000024', 'Bebiyaya Dela Peña', 'bebiyayadelapena@gmail.com', '$2y$12$cyHV2NBYDVah5p2l/71//ODN29z2rnfS0hRvTWZERXIjMX5SdhWva', 1, 1, '2026-11-03 07:47:40', '09945740596', '', 'renter'),
(25, '202611-000025', 'Angelo Ramos', 'angeloramos2324@gmail.com', '$2y$12$y8IR3FRm2zQciNmA9JDvyOIRok6ZoqS1GFnssO/jac7K5d6q10eju', 1, 1, '2026-11-03 08:33:08', '9156970391', '', 'renter'),
(26, '202611-000026', 'Francis Balce', 'Balcefrancis3@gmail.com', '$2y$12$Z.vzjilwMPR.mPwQdXoIfunJafH/n8O12xPXefK418FiMStgoB2Bq', 1, 1, '2026-11-03 12:07:01', '+639303991674', '', 'renter'),
(27, '202611-000027', 'Paul Peter', 'paulpeter@gmail.com', '$2y$12$S7kpEXJV3wu8Ni/GNsJ6m.RiieTh7VeIRwTF9advwrNaLCo/fzQ/e', 1, 0, '2026-11-03 12:09:10', '', '', 'unset'),
(28, '202611-000028', 'Paul Peter Garcia', 'uhawsalahat@gmail.com', '$2y$12$/zmEQY8FA6nSyPfFOJbdfO7j47VynXc5Lcw7PYTfLkuDpo5DmtUci', 1, 1, '2026-11-03 12:10:38', '09884563268', '', 'renter'),
(29, '202611-000029', 'Gloria Cuevas', 'nuezgloria33@gmail.com', '$2y$12$cQ2mhSO2BbEGNc9uWjezDeym8xvl1eEKGewrJH60VNmavNvOfaOFm', 1, 1, '2026-11-03 12:11:10', '', '', 'unset'),
(30, '202611-000030', 'Rei Villondo', 'reniellaaav@gmail.com', '$2y$12$xWNfe0zrE1hw9OYG8VHRF.L8YZZ.71EqquL6bm..5Xjxrhn5PY3Zm', 1, 1, '2026-11-03 12:15:02', '', '', 'unset'),
(31, '202611-000031', 'Thraia Gabriella', 'thraiaagab@gmail.com', '$2y$12$dzWQPXeNJsoPPqbM5r.BPecKN6Mh4pQFFem6cSNu7P7Gu4kZT2e52', 1, 1, '2026-11-03 12:17:24', '', '', 'unset'),
(32, '202611-000032', 'Angela Nuez', 'abicmp.ganuez@gmail.com', '$2y$12$L712sbBoPMLxjUlHko/0nOgNX6magev9AdixzigZBaM2AsJ8Jcc4y', 1, 1, '2026-11-03 12:18:49', '', '', 'unset'),
(33, '202611-000033', 'Rosita Marie Nuez', 'bambifortes24@gmail.com', '$2y$12$fa/ZluTsvZiWDlFSVBxzUO5NL6pkeOXeBsgIvYnLSGevPPoIooaSO', 1, 1, '2026-11-03 12:20:28', '09123456789', '', 'renter'),
(34, '202611-000034', 'Ellize Claire Gozar', 'ellizeclaire29@gmail.com', '$2y$12$6i9Q7Jxz6z2DXs8J9b86JuhA4sxQjFq5i2.aCfyjiQgE7CoAeQF1O', 1, 0, '2026-11-03 12:25:16', '', '', 'unset'),
(35, '202611-000035', 'Manuel Amiel Vilar', 'zerefullbuster0802@gmail.com', '$2y$12$RQ5VlyD2qhSEQX6u/SX/j./4d9sb2RTr/wq4x1ED2KZTYVZvFocf6', 1, 1, '2026-11-03 12:42:22', '', '', 'unset'),
(36, '202611-000036', 'Gene Lim', 'libunaosenpai@gmail.com', '$2y$12$pP/kjUuQ58MkagT2PdV6/eCYZfVOUAgDJHFQpFPV33WYnJZGOwirS', 1, 1, '2026-11-03 12:56:48', '09541233636', 'Facebook.com/genelim', 'renter'),
(37, '202611-000037', 'Precious Kyla', 'preciouskyla.orias@gmail.com', '$2y$12$cuJQIp6qQvQkRsmx3EcAz.Nq/EjuI5pcsBVPFCOc8x95yiHhMaQ/u', 1, 1, '2026-11-03 13:11:21', '', '', 'unset'),
(38, '202611-000038', 'Earl Tan', 'lanzero225@gmail.com', '$2y$12$W5e.kf3HuNSdgXZOOC21ruYrzDbZIN7LjCj5/46OB95rPWplIJ9am', 1, 1, '2026-11-03 13:17:13', '9764277964', '', 'renter'),
(39, '202611-000039', 'Stephanie Datu', 'stephanieirisd@gmail.com', '$2y$12$vF2XIjGWDyIFF7dH4aTovuTetUxipVY0WTRH1qrGjj8Ou5ounaVim', 1, 1, '2026-11-03 13:25:06', '09554378921', '', 'renter'),
(40, '202611-000040', 'Gene Andrei', 'nuezgeneandrei18@gmail.com', '$2y$12$TDcUykr2gKupX8K42ojGme/BaQxAqK5X9xN7NJg91Ybg3AVPVD5yO', 1, 1, '2026-11-03 13:37:37', '', '', 'unset'),
(41, '202611-000041', 'Maria Roberta', 'andreikim544@gmail.com', '$2y$12$KlVBQJEXi40eB1YCQy9zteYKOEMiVgTpw48RllyeNkIuoCeAaMbmG', 1, 1, '2026-11-03 13:38:48', '', '', 'unset'),
(42, '202611-000042', 'Lohen Marie Balatbat', 'razeykim@gmail.com', '$2y$12$E8D3R/y3C0cv.uKe0.BhuuYdcdF07hR8uQFla.5f2dmjqXaS/2a8u', 1, 1, '2026-11-03 13:39:59', '', '', 'unset'),
(43, '202611-000043', 'Lea Cuevas', 'leacuevas1710@gmail.com', '$2y$12$JFqVkHjdn4lVfSVIB/9tvOqUXM5lcXLZjGeGvEdf4f2SIwiisuo9i', 1, 1, '2026-11-03 13:42:07', '', '', 'unset'),
(44, '202611-000044', 'Kath Ferrer', 'kathrine.joyce88@gmail.com', '$2y$12$DHoRAjJft8xGOIcqElsOaeba1w0YLPMZVNZIfNYZTa/vsvKGrzUMi', 1, 1, '2026-11-03 14:04:43', '09175956840', 'kath joyce', 'renter'),
(45, '202611-000045', 'Sophia Kirsten Capua', 'sphkrstncp@gmail.com', '$2y$12$PmJ8.xQvDxXqdT4lunOhSu5SGL/.cJyGAab7KpBpG90a3lg3CG4ny', 1, 1, '2026-11-03 14:22:58', '', '', 'unset'),
(46, '202611-000046', 'Liam Dimabasa', 'dustybun0907@gmail.com', '$2y$12$y76aE1PAyIrJfTcNRZAbheJxhiygXM2tZwpAjV3e1JoCIqAE9UfMe', 1, 1, '2026-11-03 14:23:18', '09284150795', '', 'renter'),
(47, '202611-000047', 'sharie infante', 'legaspikim879@gmail.com', '$2y$12$qNT8CPbx2Z8hTfOYksZMOe/GigomRUEJIVs6za7MBFVJyiODoLAI.', 1, 1, '2026-11-03 14:26:55', '(0966) 419 1609', '', 'renter'),
(48, '202611-000048', 'Raven Ganda', 'rvngnd@gmail.com', '$2y$12$C6QKPnOCPNGPhuNAwWL7h.kH9y83GxniVxOFxJVTRDJk525.L.nbS', 1, 1, '2026-11-03 14:34:55', '0923373732772', '', 'owner'),
(51, '202611-000051', 'Raven SoCute', 'ravendelossantos14@gmail.com', '$2y$12$XmNVwySDUgfP3WqhdA/Sz.cSN90ZaBXQVWY/rLkuB39zAPBx4DtHK', 1, 1, '2026-11-03 14:37:41', '09938383883', '', 'renter'),
(52, '202611-000052', 'Burat Delos Santos', 'lunachsakuji@gmail.com', '$2y$12$qd984FDW5c.I4pvoU226e.7uIqNc1REOpEc0EpEwftm4vBfdB3liq', 1, 1, '2026-11-03 14:37:43', '(0915) 103 1844', '', 'renter'),
(53, '202611-000053', 'Reuben Ferrer', 'fcaleb0227@gmail.com', '$2y$12$p7X76kKVbmMgCiN52FWV2eTe2yj9Ntcj/PznvOKv68dCFP2EkkMcy', 1, 1, '2026-11-03 14:38:01', '09278044865', '', 'renter'),
(54, '202611-000054', 'Eferson Nathan Villanueva', 'unsdgyouthconnected.peter@gmail.com', '$2y$12$t2k8tkyL93H.N8TVJ0lMpuMMcfupvcz9oNSdaZjFPpc/6xiEgRy3a', 1, 1, '2026-11-03 14:38:36', '09930875375', '', 'owner'),
(55, '202611-000055', 'Francheska Banico', 'cheskabanico@gmail.con', '$2y$12$fZyNYPoKjJ5/A4baFFkR1uD4KVX9Ae6Sxv7Zu.ByMOZrt5EEy2HOm', 1, 0, '2026-11-03 14:39:13', '', '', 'unset'),
(56, '202611-000056', 'Jewel Macapangal', 'abicmp.kjmacapangall@gmail.com', '$2y$12$xUFJvu4tI6DSLaR4uGAKs.5uSlmY7IM90A8ZbcZSfo/ZSfUYsvFAa', 1, 1, '2026-11-03 14:39:39', '', '', 'unset'),
(57, '202611-000057', 'Cheska Banico', 'cheskabanico@gmail.com', '$2y$12$eOzH9NUk04tHa8ihrUETre3.f3bhIwSKTVvxR6FZH7CoBtIGqJHMi', 1, 1, '2026-11-03 14:40:13', '', '', 'unset'),
(58, '202611-000058', 'Reece Bella', 'm3m0reece@gmail.com', '$2y$12$83YKgBlqy4ezi.DOC9lei.R/xtPhUcLBmbBuPZ0Iiw7kNMaQRFgsW', 1, 1, '2026-11-03 14:41:37', '098383837272', '', 'owner'),
(59, '202611-000059', 'Jose F.', 'jeferrer1987@gmail.com', '$2y$12$kgIw6MjGoDBdLk/0zg8I8uCiFQSwPcoMiSxlzZfChstBW4gzl4RPO', 1, 1, '2026-11-03 15:11:54', '099999999999', '', 'owner'),
(60, '202611-000060', 'Deejay', 'unkillablegamer40@gmail.com', '$2y$12$93DbFv53ZgnK7CEghese/Ow9Cu5oy1npbkZJTT4fWK.eUGFy2/kdS', 1, 1, '2026-11-03 15:22:20', '01234567891', '', 'renter'),
(61, '202611-000061', 'Clarence TESTER', 'clarenceignacio7@gmail.com', '$2y$12$vfDjFi42sq8nFe.T/sAS1uT4lEvhfGRaO6UUGM.zdL8.5MW546tpa', 1, 1, '2026-11-03 15:31:04', '09123456789', '', 'owner'),
(62, '202611-000062', 'Frankie Lapenna', 'FrankieLapenna1234567898765423@gmail.com', '$2y$12$d9Ouvt9Kxufm37QvvtY2POghCnbIIOUQIYR8RN9GEA2UBtXYTlS2S', 1, 1, '2026-11-03 15:34:33', '09123456789', '', 'renter'),
(63, '202611-000063', 'Lexi Veloso', 'lexilouhveloso2006@gmail.com', '$2y$12$7yHHHwYanv7ajZjY3x.hBuBUoLN3Vh2Yya0.m6wPU2.zGCC5HlIKO', 1, 1, '2026-11-03 22:07:42', '9662017624', '', 'owner'),
(64, '202611-000064', 'Ezikiel Dawa', 'berbosidadmarybless@gmail.com', '$2y$12$rTrhHH7LD0AzXNEi16q0/ObnjCPANsW.3p5wcGVRsiRlcq8pUwYKe', 1, 1, '2026-11-04 03:36:49', '09123456789', '', 'renter');

-- --------------------------------------------------------

--
-- Table structure for table `utilities`
--

CREATE TABLE `utilities` (
  `utility_id` tinyint(3) UNSIGNED NOT NULL,
  `utility_code` varchar(30) NOT NULL,
  `utility_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `utilities`
--

INSERT INTO `utilities` (`utility_id`, `utility_code`, `utility_name`) VALUES
(1, 'electricity', 'Electricity'),
(2, 'water', 'Water'),
(3, 'internet', 'Internet');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_otp`
--
ALTER TABLE `admin_otp`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `amenities`
--
ALTER TABLE `amenities`
  ADD PRIMARY KEY (`amenity_id`),
  ADD UNIQUE KEY `uq_amenities_code` (`amenity_code`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_audit_created` (`created_at`),
  ADD KEY `idx_audit_action` (`action`,`created_at`),
  ADD KEY `idx_audit_category` (`category`,`created_at`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `idx_bookings_user` (`user_id`),
  ADD KEY `idx_bookings_property` (`property_id`,`check_in`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`),
  ADD UNIQUE KEY `uq_cities_name` (`city_name`);

--
-- Indexes for table `email_verifications`
--
ALTER TABLE `email_verifications`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_email_verifications_token` (`token_hash`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`user_id`,`property_id`),
  ADD KEY `idx_favorites_property` (`property_id`);

--
-- Indexes for table `login_mfa`
--
ALTER TABLE `login_mfa`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `login_mfa_log`
--
ALTER TABLE `login_mfa_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_mfa_user` (`user_id`,`created_at`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `idx_payments_booking` (`booking_id`),
  ADD KEY `idx_payments_method` (`method_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`method_id`),
  ADD UNIQUE KEY `uq_payment_methods_name` (`method_name`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`property_id`),
  ADD UNIQUE KEY `uq_properties_code` (`property_code`),
  ADD KEY `idx_properties_owner` (`owner_id`),
  ADD KEY `idx_properties_type` (`type_id`),
  ADD KEY `idx_properties_city` (`city_id`);

--
-- Indexes for table `property_amenities`
--
ALTER TABLE `property_amenities`
  ADD PRIMARY KEY (`property_id`,`amenity_id`),
  ADD KEY `idx_property_amenities_amenity` (`amenity_id`);

--
-- Indexes for table `property_blocked_dates`
--
ALTER TABLE `property_blocked_dates`
  ADD PRIMARY KEY (`block_id`),
  ADD KEY `idx_blocked_property` (`property_id`,`start_date`);

--
-- Indexes for table `property_images`
--
ALTER TABLE `property_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `idx_property_images_property` (`property_id`);

--
-- Indexes for table `property_payment_methods`
--
ALTER TABLE `property_payment_methods`
  ADD PRIMARY KEY (`property_id`,`method_id`),
  ADD KEY `idx_ppm_method` (`method_id`);

--
-- Indexes for table `property_tags`
--
ALTER TABLE `property_tags`
  ADD PRIMARY KEY (`property_id`,`tag_id`),
  ADD KEY `idx_property_tags_tag` (`tag_id`);

--
-- Indexes for table `property_types`
--
ALTER TABLE `property_types`
  ADD PRIMARY KEY (`type_id`),
  ADD UNIQUE KEY `uq_property_types_name` (`type_name`);

--
-- Indexes for table `property_utilities`
--
ALTER TABLE `property_utilities`
  ADD PRIMARY KEY (`property_id`,`utility_id`),
  ADD KEY `idx_property_utilities_utility` (`utility_id`);

--
-- Indexes for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD UNIQUE KEY `uq_remember_selector` (`selector`),
  ADD KEY `idx_remember_user` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `uq_roles_name` (`role_name`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tag_id`),
  ADD UNIQUE KEY `uq_tags_name` (`tag_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD UNIQUE KEY `uq_users_account_no` (`account_no`),
  ADD KEY `idx_users_role` (`role_id`);

--
-- Indexes for table `utilities`
--
ALTER TABLE `utilities`
  ADD PRIMARY KEY (`utility_id`),
  ADD UNIQUE KEY `uq_utilities_code` (`utility_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `amenities`
--
ALTER TABLE `amenities`
  MODIFY `amenity_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `login_mfa_log`
--
ALTER TABLE `login_mfa_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `method_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `property_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `property_blocked_dates`
--
ALTER TABLE `property_blocked_dates`
  MODIFY `block_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `property_images`
--
ALTER TABLE `property_images`
  MODIFY `image_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `property_types`
--
ALTER TABLE `property_types`
  MODIFY `type_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  MODIFY `token_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `tag_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `utilities`
--
ALTER TABLE `utilities`
  MODIFY `utility_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_bookings_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_bookings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `email_verifications`
--
ALTER TABLE `email_verifications`
  ADD CONSTRAINT `fk_email_verifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `fk_favorites_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payments_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_payments_method` FOREIGN KEY (`method_id`) REFERENCES `payment_methods` (`method_id`) ON UPDATE CASCADE;

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `fk_properties_city` FOREIGN KEY (`city_id`) REFERENCES `cities` (`city_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_properties_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_properties_type` FOREIGN KEY (`type_id`) REFERENCES `property_types` (`type_id`) ON UPDATE CASCADE;

--
-- Constraints for table `property_amenities`
--
ALTER TABLE `property_amenities`
  ADD CONSTRAINT `fk_pa_amenity` FOREIGN KEY (`amenity_id`) REFERENCES `amenities` (`amenity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pa_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `property_blocked_dates`
--
ALTER TABLE `property_blocked_dates`
  ADD CONSTRAINT `fk_blocked_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `property_images`
--
ALTER TABLE `property_images`
  ADD CONSTRAINT `fk_property_images_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `property_payment_methods`
--
ALTER TABLE `property_payment_methods`
  ADD CONSTRAINT `fk_ppm_method` FOREIGN KEY (`method_id`) REFERENCES `payment_methods` (`method_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_ppm_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `property_tags`
--
ALTER TABLE `property_tags`
  ADD CONSTRAINT `fk_pt_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pt_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `property_utilities`
--
ALTER TABLE `property_utilities`
  ADD CONSTRAINT `fk_pu_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pu_utility` FOREIGN KEY (`utility_id`) REFERENCES `utilities` (`utility_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
