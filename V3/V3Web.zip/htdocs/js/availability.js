/**
 * ------------------------------------------------------------------
 * Availability helpers shared by the property card and the booking
 * modal: how many slots a listing has and which dates are taken.
 * Dates are 'YYYY-MM-DD' strings. A taken range is { from, to } with
 * both ends inclusive; to === null means "open-ended" (monthly stay).
 * ------------------------------------------------------------------ */

const Availability = (() => {
  const todayStr = () => {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${d.getFullYear()}-${m}-${day}`;
  };

  function fmt(iso) {
    return new Date(iso + "T00:00:00").toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
  }

  function rangeLabel(r) {
    if (!r.to) return `From ${fmt(r.from)} onwards`;
    return r.from === r.to ? fmt(r.from) : `${fmt(r.from)} – ${fmt(r.to)}`;
  }

  /** Does a stay [checkIn, checkOut) hit a taken range? checkOut falsy = open-ended monthly stay. */
  function conflicts(taken, checkIn, checkOut) {
    if (!checkIn) return false;
    return (taken || []).some((r) => {
      const endsAfterStart = r.to === null || r.to >= checkIn;
      const startsBeforeEnd = !checkOut || r.from < checkOut;
      return endsAfterStart && startsBeforeEnd;
    });
  }

  /** The taken range that covers today, if the listing is full right now. */
  function fullNow(property) {
    const t = todayStr();
    return (property.taken || []).find((r) => r.from <= t && (r.to === null || r.to >= t)) || null;
  }

  /** Short status chip for cards: { text, full } or null when there's nothing worth saying. */
  function chip(property) {
    const slots = property.slots || 1;
    const now = fullNow(property);
    if (now) {
      return { full: true, text: now.to ? `${slots > 1 ? "Fully booked" : "Booked"} until ${fmt(now.to)}` : (slots > 1 ? "Fully booked" : "Booked") };
    }
    if (slots > 1) {
      const free = property.slotsFree == null ? slots : property.slotsFree;
      return { full: false, text: `${free} of ${slots} slots free` };
    }
    return null;
  }

  /** First date a new stay could start: today, or the day after the current taken range. null = open-ended. */
  function nextFree(property) {
    const now = fullNow(property);
    if (!now) return todayStr();
    if (!now.to) return null;
    const d = new Date(now.to + "T00:00:00");
    d.setDate(d.getDate() + 1);
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${d.getFullYear()}-${m}-${day}`;
  }

  return { todayStr, fmt, rangeLabel, conflicts, fullNow, chip, nextFree };
})();
