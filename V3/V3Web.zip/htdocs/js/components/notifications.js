(function () {
  "use strict";

  var POLL_MS = 60000;
  var MAX_ITEMS = 10;

  function openProperty(id) {
    if (typeof BookingModal === "undefined" || typeof PahuwaySpaceData === "undefined") return false;
    PahuwaySpaceData.getAllProperties()
      .then(function (list) {
        var found = list.filter(function (p) { return String(p.id) === String(id); })[0];
        if (found) BookingModal.open(found);
      })
      .catch(function () {});
    return true;
  }

  try {
    var wanted = new URLSearchParams(window.location.search).get("property");
    if (wanted && openProperty(wanted)) {
      var clean = window.location.pathname + window.location.hash;
      window.history.replaceState(null, "", clean);
    }
  } catch (e) { /* ignore */ }

  /* ---------- bell ---------- */

  var accountLink = document.querySelector('.header-actions a[href="dashboard.html"]');
  if (!accountLink) return;

  var userKey = null;
  var wrap, btn, dot, panel;
  var items = [];

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function loadSeen() {
    try {
      return JSON.parse(localStorage.getItem(userKey) || "[]");
    } catch (e) {
      return [];
    }
  }

  function saveSeen(list) {
    try {
      localStorage.setItem(userKey, JSON.stringify(list));
    } catch (e) { /* storage blocked: dot just returns next visit */ }
  }

  function build() {
    wrap = document.createElement("div");
    wrap.className = "notif";
    wrap.innerHTML =
      '<button type="button" class="notif__btn" aria-label="Notifications" aria-haspopup="true" aria-expanded="false">' +
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
          '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>' +
        '</svg>' +
        '<span class="notif__dot" hidden></span>' +
      '</button>' +
      '<div class="notif__panel" hidden role="region" aria-label="Notifications"></div>';

    accountLink.parentNode.insertBefore(wrap, accountLink);
    btn = wrap.querySelector(".notif__btn");
    dot = wrap.querySelector(".notif__dot");
    panel = wrap.querySelector(".notif__panel");

    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var open = panel.hidden;
      panel.hidden = !open;
      btn.setAttribute("aria-expanded", String(open));
      if (open) markAllSeen();
    });

    panel.addEventListener("click", function (e) {
      var link = e.target.closest("[data-property]");
      if (!link) return;
      if (openProperty(link.getAttribute("data-property"))) {
        e.preventDefault();
        close();
      }
    });

    document.addEventListener("click", function (e) {
      if (!wrap.contains(e.target)) close();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") close();
    });
  }

  function close() {
    if (!panel || panel.hidden) return;
    panel.hidden = true;
    btn.setAttribute("aria-expanded", "false");
    render(); // drop the "new" highlight once the panel is closed
  }

  function markAllSeen() {
    var seen = loadSeen();
    items.forEach(function (n) {
      if (seen.indexOf(n.key) === -1) seen.push(n.key);
    });
    saveSeen(seen);
    dot.hidden = true;
    // keep highlights visible while the panel is open; cleared on close
  }

  function render() {
    var seen = loadSeen();
    var unread = items.filter(function (n) { return seen.indexOf(n.key) === -1; }).length;
    dot.hidden = unread === 0;

    var html = '<p class="notif__title">Notifications</p>';
    if (!items.length) {
      html += '<p class="notif__empty">No notifications yet.</p>';
    } else {
      items.forEach(function (n) {
        var isNew = seen.indexOf(n.key) === -1;
        var text;
        if (n.kind === "proof") {
          text = '<strong>' + esc(n.guest) + '</strong> uploaded proof of payment for <strong>' + esc(n.title) + '</strong>' +
                 ' <span class="notif__status notif__status--request">to confirm</span>';
        } else if (n.kind === "paid") {
          text = 'Your payment for <strong>' + esc(n.title) + '</strong> was ' +
                 '<span class="notif__status notif__status--approved">confirmed</span>. You are booked!';
        } else if (n.kind === "request") {
          text = '<strong>' + esc(n.guest) + '</strong> requested <strong>' + esc(n.title) + '</strong>' +
                 ' <span class="notif__status notif__status--request">pending</span>';
        } else {
          text = 'Your request for <strong>' + esc(n.title) + '</strong> was ' +
                 '<span class="notif__status notif__status--' + n.label + '">' + n.label + '</span>.';
        }
        html +=
          '<a class="notif__item' + (isNew ? " notif__item--new" : "") + '"' +
            ' href="member-home.html?property=' + encodeURIComponent(n.propertyId) + '"' +
            ' data-property="' + esc(n.propertyId) + '">' +
            text +
            '<span class="notif__meta">' + esc(n.when) + '</span>' +
          '</a>';
      });
    }
    panel.innerHTML = html;
  }

  function getJson(url) {
    return fetch(url, { credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .catch(function () { return null; });
  }

  function refresh() {
    Promise.all([getJson("api/bookings.php"), getJson("api/owner-bookings.php")]).then(function (res) {
      var mine = res[0], incoming = res[1];
      var list = [];

      if (mine && mine.success) {
        mine.bookings.forEach(function (b) {
          if (b.booking_status !== "confirmed" && b.booking_status !== "cancelled") return;
          if (b.payment_state === "paid") {
            list.push({
              kind: "paid",
              key: "c:" + b.booking_id,
              propertyId: b.property_id,
              title: b.title,
              created: b.created_at || "",
              when: b.created_at ? "Requested " + b.created_at.slice(0, 10) : ""
            });
          }
          list.push({
            kind: "result",
            key: "r:" + b.booking_id + ":" + b.booking_status,
            propertyId: b.property_id,
            title: b.title,
            label: b.booking_status === "confirmed" ? "approved" : "denied",
            created: b.created_at || "",
            when: b.created_at ? "Requested " + b.created_at.slice(0, 10) : ""
          });
        });
      }

      if (incoming && incoming.success) {
        incoming.bookings.forEach(function (b) {
          if (b.payment_state === "proof_sent") {
            list.push({
              kind: "proof",
              key: "p:" + b.booking_id,
              propertyId: b.property_id,
              title: b.title,
              guest: b.guest_name,
              created: b.created_at || "",
              when: b.created_at ? "Requested " + b.created_at.slice(0, 10) : ""
            });
          }
          if (b.booking_status !== "pending") return;
          list.push({
            kind: "request",
            key: "o:" + b.booking_id,
            propertyId: b.property_id,
            title: b.title,
            guest: b.guest_name,
            created: b.created_at || "",
            when: b.created_at ? "Requested " + b.created_at.slice(0, 10) : ""
          });
        });
      }

      if (!mine && !incoming) return;

      list.sort(function (a, b) { return a.created < b.created ? 1 : a.created > b.created ? -1 : 0; });
      items = list.slice(0, MAX_ITEMS);
      
      if (panel.hidden) render();
    });
  }

  fetch("api/session.php", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(function (s) {
      if (!s || !s.loggedIn) return;
      userKey = "pahuway_seen_notifs_" + s.user.user_id;
      build();
      refresh();
      setInterval(refresh, POLL_MS);
      document.addEventListener("visibilitychange", function () {
        if (!document.hidden) refresh();
      });
    })
    .catch(function () {});
})();