<?php

session_start();
require_once "db.php";
require_once "property_helpers.php";
require_once "tag_helpers.php";
require_once "payment_helpers.php";

ensure_payment_schema($conn);

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$owner_id = (int) $_SESSION["user_id"];

$stmt = $conn->prepare(
    property_select_sql() . "
     WHERE p.owner_id = ?
     ORDER BY p.property_id DESC"
);

$stmt->bind_param("i", $owner_id);
$stmt->execute();

$result = $stmt->get_result();
$properties = [];

while ($row = $result->fetch_assoc()) {
    $row = cast_property_row($row);

    // same fields the dashboard has always received
    $properties[] = [
        "property_id" => $row["property_id"],
        "property_code" => $row["property_code"],
        "title" => $row["title"],
        "location" => $row["location"],
        "price" => $row["price"],
        "status" => $row["status"],
        "image" => $row["image"],
        "property_type" => $row["property_type"],
        "description" => $row["description"],
        "price_unit" => $row["price_unit"],
        "bedrooms" => $row["bedrooms"],
        "bathrooms" => $row["bathrooms"],
        "area" => $row["area"],
        "slots" => $row["slots"],
        "pets_allowed" => $row["pets_allowed"],
        "pet_conditions" => $row["pet_conditions"],
        "parking_nearby" => $row["parking_nearby"],
        "parking_fee" => $row["parking_fee"]
    ];
}

attach_property_extras($conn, $properties);
attach_property_tags($conn, $properties);
attach_payment_methods($conn, $properties);
attach_availability($conn, $properties, true);

echo json_encode([
    "success" => true,
    "properties" => $properties
]);

$stmt->close();
$conn->close();

?>