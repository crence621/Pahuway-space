<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$GLOBALS['pahuway_mail_error'] = '';

function sendPahuwayEmail(
    string $recipientEmail,
    string $recipientName,
    string $subject,
    string $htmlBody,
    ?string $textBody = null
): bool {
    $autoload = __DIR__ . '/../vendor/autoload.php';
    $real = __DIR__ . '/../vendor/composer/autoload_real.php';
    if (!is_file($autoload) || !is_file($real)) {
        $GLOBALS['pahuway_mail_error'] = 'vendor/ (PHPMailer) is missing or incomplete on the server.';
        error_log('Pahuway email error: ' . $GLOBALS['pahuway_mail_error']);
        return false;
    }
    require_once $autoload;

    $config = require __DIR__ . '/mail_config.php';

    $mail = new PHPMailer(true);

    try {
        $mail->Timeout = 15;
        $mail->isSMTP();
        $mail->Host = $config['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $config['username'];
        $mail->Password = $config['password'];
        $mail->SMTPSecure = $config['encryption'];
        $mail->Port = (int) $config['port'];

        $mail->CharSet = 'UTF-8';

        // From must match the authenticated SMTP account (or a domain you've
        // authenticated with SPF/DKIM), otherwise Gmail treats it as spoofing.
        $mail->setFrom($config['from_email'], $config['from_name']);
        $mail->addReplyTo($config['reply_to'] ?? $config['from_email'], $config['from_name']);

        // Don't advertise "PHPMailer" in the headers, and give the Message-ID
        // a real-looking domain instead of the server's internal hostname.
        $mail->XMailer = ' ';
        $fromDomain = substr(strrchr($config['from_email'], '@'), 1);
        if ($fromDomain) {
            $mail->Hostname = $fromDomain;
        }

        $mail->addAddress($recipientEmail, $recipientName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlBody;

        // A real plain-text version, not just the HTML with tags stripped.
        $mail->AltBody = $textBody ?? trim(html_entity_decode(strip_tags($htmlBody), ENT_QUOTES, 'UTF-8'));

        $mail->send();
        return true;
    } catch (Exception $e) {
        $GLOBALS['pahuway_mail_error'] = $mail->ErrorInfo;
        error_log('Pahuway email error: ' . $mail->ErrorInfo);
        return false;
    }
}
