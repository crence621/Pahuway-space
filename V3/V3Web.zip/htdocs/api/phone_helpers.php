<?php

/*
 * Mobile-number formatting. The number is kept as a contact detail on the account
 * (shown to owners/renters on bookings); it is no longer verified or used for codes.
 */

/**
 * Turns what the user typed into E.164 (+639171234567), or returns null if it
 * isn't a plausible mobile number.
 *
 * Philippine numbers may be typed as 0917 123 4567, 917 123 4567, 639171234567
 * or +63 917 123 4567. Numbers from other countries must start with + (or 00).
 */
function normalize_phone(string $raw): ?string
{
    $s = trim($raw);
    if ($s === "" || !preg_match('/^[0-9+()\-\s.]+$/', $s)) return null;

    $hasPlus = $s[0] === "+";
    $digits = preg_replace('/\D/', '', $s);
    if ($digits === "") return null;

    if (!$hasPlus && strpos($digits, "00") === 0) {          // 0063917... style
        $digits = substr($digits, 2);
        $hasPlus = true;
    }

    if ($hasPlus) {
        $e164 = "+" . $digits;
    } elseif (preg_match('/^09\d{9}$/', $digits)) {          // 09171234567
        $e164 = "+63" . substr($digits, 1);
    } elseif (preg_match('/^9\d{9}$/', $digits)) {           // 9171234567
        $e164 = "+63" . $digits;
    } elseif (preg_match('/^639\d{9}$/', $digits)) {         // 639171234567
        $e164 = "+" . $digits;
    } else {
        return null;
    }

    // Philippine mobile numbers are +63 9XX XXX XXXX exactly.
    if (strpos($e164, "+63") === 0) {
        return preg_match('/^\+639\d{9}$/', $e164) ? $e164 : null;
    }
    // Anything else: E.164 allows up to 15 digits; 8 is a sane minimum.
    return preg_match('/^\+[1-9]\d{7,14}$/', $e164) ? $e164 : null;
}
