<?php

/*
 * Availability: how many renters can book a listing at once ("slots") and which
 * dates are already taken.
 *
 * A listing has `slots` (default 1; a dorm or a house with several rooms can have
 * more). Every pending / confirmed booking uses one slot for its stay, and every
 * date range the owner blocks by hand uses ALL slots. A date is "taken" when no
 * slot is left on it.
 *
 * Internally every stay is a half-open range  [start, end)  of 'Y-m-d' strings:
 * the check-out day is free again, and end = null means an open-ended monthly stay.
 * Dates that go out through the API are inclusive ("from" .. "to", to = null when open).
 */

require_once __DIR__ . "/property_helpers.php";

const MAX_SLOTS = 99;
const MAX_BLOCKS = 50;

/* Adds properties.slots and the property_blocked_dates table the first time it is needed. */
function ensure_availability_schema(mysqli $conn): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    $col = $conn->query("SHOW COLUMNS FROM properties LIKE 'slots'");
    if ($col && $col->num_rows === 0) {
        $conn->query("ALTER TABLE properties ADD COLUMN slots smallint unsigned NOT NULL DEFAULT 1");
    }

    $tbl = $conn->query("SHOW TABLES LIKE 'property_blocked_dates'");
    if ($tbl && $tbl->num_rows === 0) {
        $conn->query(
            "CREATE TABLE IF NOT EXISTS property_blocked_dates (
                block_id    int unsigned NOT NULL AUTO_INCREMENT,
                property_id int unsigned NOT NULL,
                start_date  date NOT NULL,
                end_date    date NOT NULL,
                note        varchar(120) NOT NULL DEFAULT '',
                created_at  timestamp NOT NULL DEFAULT current_timestamp(),
                PRIMARY KEY (block_id),
                KEY idx_blocked_property (property_id, start_date),
                CONSTRAINT fk_blocked_property FOREIGN KEY (property_id) REFERENCES properties (property_id)
                    ON UPDATE CASCADE ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    }
}

/* ---------------------------------------------------------------- input */

/* 1..99, or null when it isn't a whole number in that range. A blank value means 1. */
function parse_slots($value): ?int
{
    if ($value === null || $value === "") return 1;
    if (!is_numeric($value) || (float) $value != (int) $value) return null;
    $n = (int) $value;
    return ($n >= 1 && $n <= MAX_SLOTS) ? $n : null;
}

function valid_ymd(string $d): bool
{
    $dt = DateTime::createFromFormat("Y-m-d", $d);
    return $dt && $dt->format("Y-m-d") === $d;
}

/*
 * The blocked-date ranges the owner typed in: JSON like
 * [{"from":"2026-12-01","to":"2026-12-05","note":"Family stay"}].
 * Past ranges are dropped. Throws InvalidArgumentException with a message for the form.
 */
function parse_blocked_dates($raw): array
{
    if (is_string($raw)) {
        $raw = trim($raw);
        if ($raw === "") return [];
        $raw = json_decode($raw, true);
    }
    if ($raw === null || $raw === []) return [];
    if (!is_array($raw)) throw new InvalidArgumentException("The unavailable dates could not be read.");
    if (count($raw) > MAX_BLOCKS) throw new InvalidArgumentException("You can mark up to " . MAX_BLOCKS . " unavailable date ranges.");

    $today = date("Y-m-d");
    $out = [];
    foreach ($raw as $b) {
        $from = is_array($b) ? (string) ($b["from"] ?? "") : "";
        $to = is_array($b) ? (string) ($b["to"] ?? "") : "";
        $note = is_array($b) ? trim((string) ($b["note"] ?? "")) : "";
        if (!valid_ymd($from) || !valid_ymd($to)) throw new InvalidArgumentException("Enter a valid start and end date for each unavailable range.");
        if ($to < $from) throw new InvalidArgumentException("An unavailable range ends before it starts.");
        if ($to < $today) continue;
        $out[] = ["from" => $from, "to" => $to, "note" => mb_substr($note, 0, 120)];
    }
    return $out;
}

/* Replace all of a property's blocked ranges. Call inside a transaction. */
function save_blocked_dates(mysqli $conn, int $property_id, array $blocks): void
{
    db_run($conn, "DELETE FROM property_blocked_dates WHERE property_id = ?", "i", [$property_id])->close();
    foreach ($blocks as $b) {
        db_run(
            $conn,
            "INSERT INTO property_blocked_dates (property_id, start_date, end_date, note) VALUES (?, ?, ?, ?)",
            "isss",
            [$property_id, $b["from"], $b["to"], $b["note"]]
        )->close();
    }
}

/* ---------------------------------------------------------------- loading */

/*
 * Active (pending / confirmed, not yet over) bookings and blocked ranges for these
 * properties: [property_id => [item, ...]]. Item: kind, id, start, end (exclusive,
 * null = open), status, guest, note. Guest names are only filled in for owners.
 */
function load_availability_items(mysqli $conn, array $ids, bool $with_guest = false): array
{
    $ids = array_values(array_unique(array_map("intval", $ids)));
    $out = array_fill_keys($ids, []);
    if (!$ids) return $out;

    $in = implode(",", $ids);
    $today = date("Y-m-d");
    $open = PH_NO_CHECKOUT;

    $res = $conn->query(
        "SELECT b.booking_id, b.property_id, b.check_in, b.check_out, b.booking_status, u.full_name
           FROM bookings b
           INNER JOIN users u ON u.user_id = b.user_id
          WHERE b.property_id IN ($in)
            AND b.booking_status IN ('pending', 'confirmed')
            AND (b.check_out = '$open' OR b.check_out > '$today')
          ORDER BY b.check_in ASC"
    );
    while ($res && ($r = $res->fetch_assoc())) {
        $out[(int) $r["property_id"]][] = [
            "kind" => "booking",
            "id" => (int) $r["booking_id"],
            "start" => $r["check_in"],
            "end" => $r["check_out"] === $open ? null : $r["check_out"],
            "status" => $r["booking_status"],
            "guest" => $with_guest ? $r["full_name"] : "",
            "note" => "",
        ];
    }

    $res = $conn->query(
        "SELECT block_id, property_id, start_date, end_date, note
           FROM property_blocked_dates
          WHERE property_id IN ($in) AND end_date >= '$today'
          ORDER BY start_date ASC"
    );
    while ($res && ($r = $res->fetch_assoc())) {
        $out[(int) $r["property_id"]][] = [
            "kind" => "block",
            "id" => (int) $r["block_id"],
            "start" => $r["start_date"],
            "end" => date("Y-m-d", strtotime($r["end_date"] . " +1 day")),
            "status" => "blocked",
            "guest" => "",
            "note" => $r["note"],
        ];
    }
    return $out;
}

/* ---------------------------------------------------------------- calculations */

function item_weight(array $it, int $slots): int
{
    return $it["kind"] === "block" ? $slots : 1;
}

/* Slots in use on one day. */
function load_at(array $items, int $slots, string $day, bool $bookings_only = false): int
{
    $n = 0;
    foreach ($items as $it) {
        if ($bookings_only && $it["kind"] === "block") continue;
        if ($it["start"] <= $day && ($it["end"] === null || $day < $it["end"])) $n += item_weight($it, $slots);
    }
    return $n;
}

/* Is there still a free slot on every day of [in, out)?  out = null means open-ended. */
function interval_available(array $items, int $slots, string $in, ?string $out): bool
{
    // the load only ever goes up on a start date, so those are the days to check
    $points = [$in];
    foreach ($items as $it) {
        if ($it["start"] > $in && ($out === null || $it["start"] < $out)) $points[] = $it["start"];
    }
    foreach (array_unique($points) as $p) {
        if (load_at($items, $slots, $p) + 1 > $slots) return false;
    }
    return true;
}

/* The most bookings that overlap on any single day from today on (blocks ignored). */
function peak_booking_load(array $items, string $today): int
{
    $points = [$today];
    foreach ($items as $it) {
        if ($it["kind"] === "booking" && $it["start"] > $today) $points[] = $it["start"];
    }
    $peak = 0;
    foreach (array_unique($points) as $p) $peak = max($peak, load_at($items, 1, $p, true));
    return $peak;
}

/* Merged date ranges (inclusive, to = null when open-ended) where no slot is left. */
function full_ranges(array $items, int $slots, string $today): array
{
    $bounds = [$today];
    foreach ($items as $it) {
        if ($it["start"] > $today) $bounds[] = $it["start"];
        if ($it["end"] !== null && $it["end"] > $today) $bounds[] = $it["end"];
    }
    $bounds = array_values(array_unique($bounds));
    sort($bounds);

    $ranges = [];
    $cur = null;
    foreach ($bounds as $i => $from) {
        $to = $bounds[$i + 1] ?? null; // segment [from, to); the last one runs on forever
        if (load_at($items, $slots, $from) >= $slots) {
            if ($cur !== null && $cur["end"] === $from) $cur["end"] = $to;
            else {
                if ($cur !== null) $ranges[] = $cur;
                $cur = ["start" => $from, "end" => $to];
            }
        } elseif ($cur !== null) {
            $ranges[] = $cur;
            $cur = null;
        }
    }
    if ($cur !== null) $ranges[] = $cur;

    return array_map(fn($r) => [
        "from" => $r["start"],
        "to" => $r["end"] === null ? null : date("Y-m-d", strtotime($r["end"] . " -1 day")),
    ], $ranges);
}

/*
 * Adds slots, slots_free (free today), taken[] (fully-booked ranges) to property rows.
 * With $owner = true it also adds schedule[] (every booking and blocked range, with guest
 * names) and blocked_dates[] (just the owner's own ranges) for the owner's pages.
 */
function attach_availability(mysqli $conn, array &$rows, bool $owner = false): void
{
    ensure_availability_schema($conn);
    $ids = array_map(fn($r) => (int) $r["property_id"], $rows);
    $all = load_availability_items($conn, $ids, $owner);
    $today = date("Y-m-d");

    foreach ($rows as $i => $row) {
        $pid = (int) $row["property_id"];
        $slots = max(1, (int) ($row["slots"] ?? 1));
        $items = $all[$pid] ?? [];

        $rows[$i]["slots"] = $slots;
        $rows[$i]["slots_free"] = max(0, $slots - load_at($items, $slots, $today));
        $rows[$i]["taken"] = full_ranges($items, $slots, $today);

        if ($owner) {
            $schedule = [];
            $blocked = [];
            foreach ($items as $it) {
                $to = $it["end"] === null ? null : date("Y-m-d", strtotime($it["end"] . " -1 day"));
                $schedule[] = [
                    "kind" => $it["kind"], "id" => $it["id"], "from" => $it["start"], "to" => $to,
                    "status" => $it["status"], "guest" => $it["guest"], "note" => $it["note"],
                ];
                if ($it["kind"] === "block") $blocked[] = ["from" => $it["start"], "to" => $to, "note" => $it["note"]];
            }
            usort($schedule, fn($a, $b) => strcmp($a["from"], $b["from"]));
            $rows[$i]["schedule"] = $schedule;
            $rows[$i]["blocked_dates"] = $blocked;
        }
    }
}

// Make sure the column and table exist for any endpoint that loads properties.
if (isset($GLOBALS["conn"]) && $GLOBALS["conn"] instanceof mysqli) {
    ensure_availability_schema($GLOBALS["conn"]);
}
