<?php

const PAYMENT_METHOD_CHOICES = ["GCash", "Maya", "MariBank", "Bank Transfer"];
const PROOF_DIR = "assets/uploads/payments/";

function ensure_payment_schema(mysqli $conn): void
{
    $res = $conn->query("SHOW COLUMNS FROM payments LIKE 'proof_image'");
    if ($res && $res->num_rows > 0) {
        return;
    }

    $conn->query(
        "CREATE TABLE IF NOT EXISTS property_payment_methods (
            property_id int unsigned NOT NULL,
            method_id   tinyint unsigned NOT NULL,
            PRIMARY KEY (property_id, method_id),
            KEY idx_ppm_method (method_id),
            CONSTRAINT fk_ppm_property FOREIGN KEY (property_id) REFERENCES properties (property_id)
                ON UPDATE CASCADE ON DELETE CASCADE,
            CONSTRAINT fk_ppm_method FOREIGN KEY (method_id) REFERENCES payment_methods (method_id)
                ON UPDATE CASCADE ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    foreach (PAYMENT_METHOD_CHOICES as $name) {
        $stmt = $conn->prepare("INSERT IGNORE INTO payment_methods (method_name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->close();
    }

    $conn->query("ALTER TABLE payments ADD COLUMN proof_image varchar(255) NOT NULL DEFAULT ''");
}

function clean_payment_methods($posted): array
{
    if (!is_array($posted)) return [];
    return array_values(array_intersect(PAYMENT_METHOD_CHOICES, $posted));
}

function save_payment_methods(mysqli $conn, int $property_id, array $names): void
{
    db_run($conn, "DELETE FROM property_payment_methods WHERE property_id = ?", "i", [$property_id])->close();

    foreach ($names as $name) {
        db_run(
            $conn,
            "INSERT IGNORE INTO property_payment_methods (property_id, method_id)
             SELECT ?, method_id FROM payment_methods WHERE method_name = ?",
            "is",
            [$property_id, $name]
        )->close();
    }
}

function attach_payment_methods(mysqli $conn, array &$rows): void
{
    $index = [];
    foreach ($rows as $i => $row) {
        $rows[$i]["payment_methods"] = [];
        $index[(int) $row["property_id"]] = $i;
    }
    if (!$index) return;

    $in = implode(",", array_keys($index));
    $res = $conn->query(
        "SELECT ppm.property_id, pm.method_name
           FROM property_payment_methods ppm
           INNER JOIN payment_methods pm ON pm.method_id = ppm.method_id
          WHERE ppm.property_id IN ($in)
          ORDER BY pm.method_id ASC"
    );
    while ($res && ($r = $res->fetch_assoc())) {
        $rows[$index[(int) $r["property_id"]]]["payment_methods"][] = $r["method_name"];
    }
}

const PAYMENT_SELECT_COLUMNS =
    "pay.payment_status AS pay_status, pay.proof_image AS pay_proof, pm_used.method_name AS pay_method";

const PAYMENT_JOINS =
    "LEFT JOIN payments pay
        ON pay.payment_id = (SELECT MAX(p2.payment_id) FROM payments p2 WHERE p2.booking_id = bookings.booking_id)
     LEFT JOIN payment_methods pm_used
        ON pm_used.method_id = pay.method_id";

function payment_fields(array $row): array
{
    $state = "none";
    if ($row["booking_status"] === "confirmed") {
        if (($row["pay_status"] ?? "") === "paid") {
            $state = "paid";
        } elseif (($row["pay_proof"] ?? "") !== "" && $row["pay_proof"] !== null) {
            $state = "proof_sent";
        } else {
            $state = "awaiting_proof";
        }
    }

    $method = $row["pay_method"] ?? "";
    if ($method === "Pending" || $method === null) $method = "";

    return [
        "payment_state" => $state,
        "payment_method" => $method,
        "proof_image" => $state === "awaiting_proof" || $state === "none" ? "" : (string) $row["pay_proof"]
    ];
}

function handle_proof_upload(string $field = "proof_file"): string
{
    if (!isset($_FILES[$field]) || $_FILES[$field]["error"] === UPLOAD_ERR_NO_FILE) {
        throw new UploadException("Please attach a screenshot of your payment.");
    }

    $file = $_FILES[$field];

    if ($file["error"] === UPLOAD_ERR_INI_SIZE || $file["error"] === UPLOAD_ERR_FORM_SIZE) {
        throw new UploadException("That image is too large. Please choose a smaller one.");
    }
    if ($file["error"] !== UPLOAD_ERR_OK || !is_uploaded_file($file["tmp_name"])) {
        throw new UploadException("The image could not be uploaded. Please try again.");
    }
    if ($file["size"] > UPLOAD_MAX_BYTES) {
        throw new UploadException("That image is too large. Please choose one under 5 MB.");
    }

    $info = @getimagesize($file["tmp_name"]);
    $types = [IMAGETYPE_JPEG => "jpg", IMAGETYPE_PNG => "png", IMAGETYPE_WEBP => "webp"];

    if (!$info || !isset($types[$info[2]])) {
        throw new UploadException("Please upload a JPG, PNG or WebP image.");
    }

    $dir = __DIR__ . "/../" . PROOF_DIR;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        throw new UploadException("The server could not save the image.");
    }

    $name = bin2hex(random_bytes(12)) . "." . $types[$info[2]];
    if (!move_uploaded_file($file["tmp_name"], $dir . $name)) {
        throw new UploadException("The server could not save the image.");
    }

    return PROOF_DIR . $name;
}

?>
