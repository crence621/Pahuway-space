<?php

session_start();

require_once __DIR__ . "/db.php";

// Record the sign-out (best effort; never blocks logging out)
if (!empty($_SESSION["user_id"])) {
    try {
        require_once __DIR__ . "/audit.php";
        audit_log($conn, "auth", "logout", "Signed out", ["actor_id" => (int) $_SESSION["user_id"]]);
    } catch (Throwable $e) { /* ignore */ }
}

remember_forget($conn);

$_SESSION = [];

session_destroy();

header("Content-Type: application/json");

echo json_encode([
    "success" => true,
    "message" => "Logged out successfully."
]);

?>