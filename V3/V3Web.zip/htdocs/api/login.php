<?php

ini_set("display_errors", "0");
header("Content-Type: application/json");

// Report any server-side failure as readable JSON instead of an empty 500
set_exception_handler(function ($e) {
    http_response_code(200);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
});
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err["type"], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (!headers_sent()) { http_response_code(200); header("Content-Type: application/json"); }
        echo json_encode([
            "success" => false,
            "message" => "Server error: " . $err["message"]
        ]);
    }
});

ob_start();
@session_start();

require_once "db.php";
require_once "audit.php";
require_once "mfa.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

if ($email === "" || $password === "") {
    echo json_encode([
        "success" => false,
        "message" => "Please enter your email and password."
    ]);
    exit;
}

/* Find user */
$stmt = $conn->prepare(
    "SELECT user_id, full_name, email, password, email_verified
     FROM users 
     WHERE email = ?"
);

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    audit_log($conn, "auth", "login_failed", "Failed login for " . $email . " (no such account)", ["result" => "failure"]);
    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

/* Verify password.
 * Also accepts legacy plain-text / md5 values (e.g. users inserted by hand
 * in phpMyAdmin) and upgrades them to a proper hash on first login. */
$stored = (string) $user["password"];
$ok = password_verify($password, $stored);

if (!$ok && !preg_match('/^\$(2[abxy]|argon2)/', $stored)) {
    if (hash_equals($stored, $password) || hash_equals(strtolower($stored), md5($password))) {
        $ok = true;
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $up = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
        $up->bind_param("si", $newHash, $user["user_id"]);
        $up->execute();
        $up->close();
    }
}

if (!$ok) {
    audit_log($conn, "auth", "login_failed", "Failed login for " . $email . " (wrong password)", ["actor_id" => (int) $user["user_id"], "result" => "failure"]);
    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

/* Block accounts whose email hasn't been verified yet. */
if ((int) $user["email_verified"] !== 1) {
    audit_log($conn, "auth", "login_failed", "Login blocked for " . $email . " (email not verified)", ["actor_id" => (int) $user["user_id"], "result" => "failure"]);

    echo json_encode([
        "success" => false,
        "code" => "unverified",
        "email" => $user["email"],
        "message" => "Please verify your email first. Enter the 6-digit code we sent to your inbox, or request a new one."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

/* Password is correct and the email is verified: now ask for the sign-in code.
 * The session is NOT created yet; mfa-send.php / mfa-verify.php finish the sign-in. */
@session_regenerate_id(true);
unset($_SESSION["user_id"], $_SESSION["full_name"], $_SESSION["email"]);
mfa_pending_start((int) $user["user_id"], ($_POST["remember"] ?? "") === "1");

audit_log($conn, "auth", "login_password_ok", "Password accepted, waiting for sign-in code", ["actor_id" => (int) $user["user_id"]]);

echo json_encode([
    "success" => true,
    "mfa_required" => true,
    "email_masked" => mask_email((string) $user["email"]),
    "message" => "Password accepted. We'll email you a sign-in code."
]);

$stmt->close();
$conn->close();
exit;

?>