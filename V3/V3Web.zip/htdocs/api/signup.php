<?php

require_once "db.php";
require_once "verification.php";
require_once "phone_helpers.php";
require_once "profile_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

$full_name = trim($_POST["full_name"] ?? "");
$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";
$phone_raw = trim($_POST["phone"] ?? "");

if ($full_name === "" || $email === "" || $password === "" || $phone_raw === "") {
    echo json_encode([
        "success" => false,
        "message" => "Please fill in all required fields."
    ]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid email address."
    ]);
    exit;
}

if (strlen($password) < 8) {
    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 8 characters."
    ]);
    exit;
}

/* Mobile number: required contact detail, stored as +639XXXXXXXXX (not verified) */
$phone = normalize_phone($phone_raw);
if ($phone === null) {
    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid mobile number, e.g. 0917 123 4567."
    ]);
    exit;
}

ensure_profile_columns($conn);

/* Check if email already exists */
$check = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "An account with this email already exists."
    ]);
    $check->close();
    $conn->close();
    exit;
}

$check->close();

/* Hash the password */
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

/* Insert new user */
$stmt = $conn->prepare(
    "INSERT INTO users (full_name, email, password, phone, email_verified) VALUES (?, ?, ?, ?, 0)"
);

$stmt->bind_param("ssss", $full_name, $email, $hashed_password, $phone);

if ($stmt->execute()) {
    $newId = (int) $conn->insert_id;

    require_once __DIR__ . "/account_helpers.php";
    ensure_account_no($conn); // gives the new account its YYYYMM-000000 number

    $sent = false;
    try {
        $sent = send_verification_email($conn, $newId, $email, $full_name);
    } catch (Throwable $e) {
        error_log("Pahuway verification email error: " . $e->getMessage());
    }

    if ($sent) {
        $msg = "Account created! We sent a 6-digit code to " . $email . ". Enter it below to activate your account.";
    } else {
        $msg = "Account created, but we couldn't send the email code. Use \"Resend code\" below to try again.";
    }

    echo json_encode([
        "success" => true,
        "email_sent" => $sent,
        "message" => $msg
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to create account."
    ]);
}

$stmt->close();
$conn->close();

?>