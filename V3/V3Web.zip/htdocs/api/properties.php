<?php

require_once "db.php";
require_once "property_helpers.php";
require_once "tag_helpers.php";
require_once "payment_helpers.php";

ensure_payment_schema($conn);

header("Content-Type: application/json");

$sql = property_select_sql(
        "users.full_name AS owner_name,",
        "INNER JOIN users ON p.owner_id = users.user_id"
    ) . "
    WHERE p.status != 'inactive'
    ORDER BY p.property_id ASC";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode([
        "success" => false,
        "message" => "Failed to retrieve properties."
    ]);
    $conn->close();
    exit;
}

$properties = [];

while ($row = $result->fetch_assoc()) {
    $properties[] = cast_property_row($row);
}

attach_property_extras($conn, $properties);
attach_property_tags($conn, $properties);
attach_payment_methods($conn, $properties);
attach_availability($conn, $properties);

echo json_encode([
    "success" => true,
    "properties" => $properties
]);

$conn->close();

?>