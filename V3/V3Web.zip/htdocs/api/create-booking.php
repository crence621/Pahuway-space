<?php

session_start();

require_once "db.php";
require_once "property_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "You must be logged in to make a booking."
    ]);
    exit;
}

$user_id = $_SESSION["user_id"];

$property_id = $_POST["property_id"] ?? "";
$check_in = trim($_POST["check_in"] ?? "");
$check_out = trim($_POST["check_out"] ?? "");
$guests = $_POST["guests"] ?? "";

if ($property_id === "" || $check_in === "" || $guests === "") {
    echo json_encode([
        "success" => false,
        "message" => "Please complete all booking fields."
    ]);
    exit;
}

if (!is_numeric($property_id) || !is_numeric($guests) || $guests < 1) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid booking information."
    ]);
    exit;
}

$property_id = (int) $property_id;
$guests = (int) $guests;

// Lock the property row until we're done so two renters can't take the last slot together.
$conn->begin_transaction();

$stmt = $conn->prepare(
    "SELECT price, price_unit, status, owner_id, slots
     FROM properties
     WHERE property_id = ?
     LIMIT 1
     FOR UPDATE"
);

$stmt->bind_param("i", $property_id);
$stmt->execute();
$result = $stmt->get_result();
$property = $result->fetch_assoc();
$stmt->close();

if (!$property) {
    echo json_encode([
        "success" => false,
        "message" => "Property not found."
    ]);
    exit;
}

if ((int) $property["owner_id"] === (int) $user_id) {
    echo json_encode([
        "success" => false,
        "message" => "You can't book your own property."
    ]);
    exit;
}

if ($property["status"] !== "available") {
    echo json_encode([
        "success" => false,
        "message" => "This property is not currently available."
    ]);
    exit;
}

$is_monthly = $property["price_unit"] === "monthly";

if (!$is_monthly && $check_out === "") {
    echo json_encode([
        "success" => false,
        "message" => "Please complete all booking fields."
    ]);
    exit;
}

$checkInDate = DateTime::createFromFormat("Y-m-d", $check_in);

if (!$checkInDate || $checkInDate->format("Y-m-d") !== $check_in) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid booking dates."
    ]);
    exit;
}

$price = (float) $property["price"];

if ($is_monthly) {

    // Monthly: billed per month. The move-out date is optional.
    $nights = 0;
    $total_amount = $price;

    if ($check_out === "") {
        $check_out = PH_NO_CHECKOUT; // open-ended: no NULLs in the database
        $new_out = null;             // runs until someone ends it
    } else {
        $moveOutDate = DateTime::createFromFormat("Y-m-d", $check_out);

        if (!$moveOutDate || $moveOutDate->format("Y-m-d") !== $check_out) {
            echo json_encode([
                "success" => false,
                "message" => "Invalid move-out date."
            ]);
            $conn->rollback();
            exit;
        }

        if ($moveOutDate <= $checkInDate) {
            echo json_encode([
                "success" => false,
                "message" => "Move-out must be after move-in."
            ]);
            $conn->rollback();
            exit;
        }

        $new_out = $check_out;
    }

} else {

    $checkOutDate = DateTime::createFromFormat("Y-m-d", $check_out);

    if (!$checkOutDate || $checkOutDate->format("Y-m-d") !== $check_out) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid booking dates."
        ]);
        exit;
    }

    if ($checkOutDate <= $checkInDate) {
        echo json_encode([
            "success" => false,
            "message" => "Check-out must be after check-in."
        ]);
        exit;
    }

    $nights = $checkInDate->diff($checkOutDate)->days;

    // Daily rentals: 1 month (30 nights) maximum
    if ($nights > 30) {
        echo json_encode([
            "success" => false,
            "message" => "Daily stays can be up to 30 nights (1 month) only."
        ]);
        exit;
    }
    $total_amount = $price * $nights;

    $new_out = $check_out;
}

// With several slots one renter must not be able to take more than one of them.
$dup = $conn->prepare(
    "SELECT 1 FROM bookings
     WHERE property_id = ? AND user_id = ?
       AND booking_status IN ('pending', 'confirmed')
       AND (check_out = ? OR check_out > ?)
     LIMIT 1"
);
$noCheckout = PH_NO_CHECKOUT;
$todayStr = date("Y-m-d");
$dup->bind_param("iiss", $property_id, $user_id, $noCheckout, $todayStr);
$dup->execute();
$dup->store_result();
$has_active = $dup->num_rows > 0;
$dup->close();

if ($has_active) {
    echo json_encode([
        "success" => false,
        "message" => "You already have a booking request for this property."
    ]);
    $conn->rollback();
    $conn->close();
    exit;
}

// Is a slot still free on every night of the stay?
$slots = max(1, (int) $property["slots"]);
$items = load_availability_items($conn, [$property_id])[$property_id] ?? [];
$blocks_only = array_values(array_filter($items, fn($it) => $it["kind"] === "block"));

if (!interval_available($blocks_only, $slots, $check_in, $new_out)) {
    echo json_encode([
        "success" => false,
        "message" => "The owner has marked some of those dates as unavailable. Please pick other dates."
    ]);
    $conn->rollback();
    $conn->close();
    exit;
}

if (!interval_available($items, $slots, $check_in, $new_out)) {
    echo json_encode([
        "success" => false,
        "message" => $slots > 1
            ? "All $slots slots are taken for those dates. Please pick other dates."
            : "This property is already booked for those dates."
    ]);
    $conn->rollback();
    $conn->close();
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO bookings (
        user_id,
        property_id,
        check_in,
        check_out,
        guests,
        total_amount,
        booking_status
    ) VALUES (?, ?, ?, ?, ?, ?, 'pending')"
);

$stmt->bind_param(
    "iissid",
    $user_id,
    $property_id,
    $check_in,
    $check_out,
    $guests,
    $total_amount
);

if ($stmt->execute()) {
    $conn->commit();
    echo json_encode([
        "success" => true,
        "message" => "Booking created successfully.",
        "booking_id" => $stmt->insert_id,
        "nights" => $nights,
        "total_amount" => round($total_amount, 2)
    ]);
} else {
    $conn->rollback();
    echo json_encode([
        "success" => false,
        "message" => "Failed to create booking."
    ]);
}

$stmt->close();
$conn->close();

?>