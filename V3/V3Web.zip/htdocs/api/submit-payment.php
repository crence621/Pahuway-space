<?php

session_start();
require_once "db.php";
require_once "property_helpers.php";
require_once "payment_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$booking_id = isset($_POST["booking_id"]) ? (int) $_POST["booking_id"] : 0;
$method = trim($_POST["method"] ?? "");

if ($booking_id <= 0 || $method === "") {
    echo json_encode(["success" => false, "message" => "Please choose a payment method."]);
    exit;
}

ensure_payment_schema($conn);

$uploaded = null;

try {
    $stmt = db_run(
        $conn,
        "SELECT bookings.property_id, bookings.total_amount
           FROM bookings
          WHERE bookings.booking_id = ?
            AND bookings.user_id = ?
            AND bookings.booking_status = 'confirmed'
          LIMIT 1",
        "ii",
        [$booking_id, $user_id]
    );
    $booking = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$booking) {
        echo json_encode(["success" => false, "message" => "This booking is not approved yet."]);
        exit;
    }

    $property_id = (int) $booking["property_id"];

    $stmt = db_run(
        $conn,
        "SELECT pm.method_id
           FROM property_payment_methods ppm
           INNER JOIN payment_methods pm ON pm.method_id = ppm.method_id
          WHERE ppm.property_id = ? AND pm.method_name = ?
          LIMIT 1",
        "is",
        [$property_id, $method]
    );
    $m = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$m) {
        echo json_encode(["success" => false, "message" => "The owner does not accept that payment method."]);
        exit;
    }
    $method_id = (int) $m["method_id"];

    $stmt = db_run(
        $conn,
        "SELECT payment_id, payment_status, proof_image
           FROM payments WHERE booking_id = ? ORDER BY payment_id DESC LIMIT 1",
        "i",
        [$booking_id]
    );
    $pay = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($pay && $pay["payment_status"] === "paid") {
        echo json_encode(["success" => false, "message" => "This booking is already paid."]);
        exit;
    }
    if ($pay && $pay["proof_image"] !== "") {
        echo json_encode(["success" => false, "message" => "Your proof of payment was already sent."]);
        exit;
    }

    $uploaded = handle_proof_upload();

    if ($pay) {
        db_run(
            $conn,
            "UPDATE payments SET method_id = ?, proof_image = ? WHERE payment_id = ?",
            "isi",
            [$method_id, $uploaded, (int) $pay["payment_id"]]
        )->close();
    } else {
        db_run(
            $conn,
            "INSERT INTO payments (booking_id, method_id, amount, payment_status, proof_image)
             VALUES (?, ?, ?, 'pending', ?)",
            "iids",
            [$booking_id, $method_id, (float) $booking["total_amount"], $uploaded]
        )->close();
    }

    echo json_encode(["success" => true, "message" => "Proof of payment sent. Waiting for the owner to confirm."]);

} catch (Throwable $e) {
    delete_uploaded_image_path($uploaded);
    error_log("[pahuway] submit-payment: " . $e->getMessage());
    echo json_encode([
        "success" => false,
        "message" => $e instanceof UploadException ? $e->getMessage() : "Could not send your payment. Please try again."
    ]);
}

function delete_uploaded_image_path(?string $path): void
{
    if (!$path || strpos($path, PROOF_DIR) !== 0 || strpos($path, "..") !== false) return;
    $full = __DIR__ . "/../" . $path;
    if (is_file($full)) @unlink($full);
}

$conn->close();

?>
