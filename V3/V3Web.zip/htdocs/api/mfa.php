<?php

/*
 * Sign-in (two-step) verification helpers.
 *
 * After the password is accepted, login.php does NOT sign the user in. It parks the
 * user in the session as "mfa_pending"; mfa-send.php then emails a 6-digit code to the
 * account's email address and mfa-verify.php completes the sign-in once the right code
 * is entered.
 *
 * Codes are never stored in plain text (the table keeps sha256 of user:method:code),
 * expire after 10 minutes and are locked after 5 wrong guesses.
 * Tables are created automatically on first use.
 */

require_once __DIR__ . "/mail.php";

const MFA_CODE_MINUTES = 10;
const MFA_MAX_ATTEMPTS = 5;
const MFA_PENDING_MINUTES = 15;   // how long the user has to finish signing in after the password step
const MFA_COOLDOWN_SECONDS = 60;  // before another code can be sent
const MFA_SENDS_PER_HOUR = 6;     // per account

function ensure_mfa_schema(mysqli $conn): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    try {
        $conn->query(
            "CREATE TABLE IF NOT EXISTS `login_mfa` (
              `user_id`    int unsigned NOT NULL,
              `method`     varchar(5) NOT NULL,
              `token_hash` char(64) NOT NULL,
              `expires_at` datetime NOT NULL,
              `attempts`   tinyint unsigned NOT NULL DEFAULT 0,
              `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
              PRIMARY KEY (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $conn->query(
            "CREATE TABLE IF NOT EXISTS `login_mfa_log` (
              `id`         bigint unsigned NOT NULL AUTO_INCREMENT,
              `user_id`    int unsigned NOT NULL,
              `method`     varchar(5) NOT NULL,
              `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
              PRIMARY KEY (`id`),
              KEY `idx_mfa_user` (`user_id`, `created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
        error_log("[pahuway] ensure_mfa_schema: " . $e->getMessage());
    }
}

/** j•••@gmail.com */
function mask_email(string $email): string
{
    $parts = explode("@", $email, 2);
    $local = $parts[0];
    $domain = $parts[1] ?? "";
    $dots = max(2, min(6, mb_strlen($local) - 1));
    return mb_substr($local, 0, 1) . str_repeat("•", $dots) . ($domain !== "" ? "@" . $domain : "");
}

function mfa_code_hash(int $userId, string $method, string $code): string
{
    return hash("sha256", "mfa:" . $userId . ":" . $method . ":" . $code);
}

/* ---------- "password accepted, code still needed" state kept in the session ---------- */

function mfa_pending_start(int $userId, bool $remember): void
{
    $_SESSION["mfa_pending"] = ["user_id" => $userId, "remember" => $remember, "started" => time()];
}

function mfa_pending_get(): ?array
{
    $p = $_SESSION["mfa_pending"] ?? null;
    if (!is_array($p) || empty($p["user_id"])) return null;
    if (time() - (int) ($p["started"] ?? 0) > MFA_PENDING_MINUTES * 60) {
        unset($_SESSION["mfa_pending"]);
        return null;
    }
    return $p;
}

function mfa_pending_clear(): void
{
    unset($_SESSION["mfa_pending"]);
}

/* ---------- sending ---------- */

/**
 * Creates a fresh code for this user (replacing any older one and resetting
 * the attempt counter) and emails it.
 *
 * Returns "sent", "too_soon", "limit" or "failed".
 */
function mfa_send(mysqli $conn, array $user): string
{
    ensure_mfa_schema($conn);

    $method = "email";
    $uid = (int) $user["user_id"];

    // Re-requested within the cooldown
    $cd = MFA_COOLDOWN_SECONDS;
    $q = $conn->prepare("SELECT 1 FROM login_mfa WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL {$cd} SECOND) LIMIT 1");
    $q->bind_param("i", $uid);
    $q->execute();
    $recent = $q->get_result()->num_rows > 0;
    $q->close();
    if ($recent) return "too_soon";

    // Hourly cap per account (stops code-cycling to get fresh guesses, and email flooding)
    $q = $conn->prepare("SELECT COUNT(*) AS c FROM login_mfa_log WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $q->bind_param("i", $uid);
    $q->execute();
    $count = (int) $q->get_result()->fetch_assoc()["c"];
    $q->close();
    if ($count >= MFA_SENDS_PER_HOUR) return "limit";

    $code = str_pad((string) random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $hash = mfa_code_hash($uid, $method, $code);
    $minutes = MFA_CODE_MINUTES;

    $stmt = $conn->prepare(
        "REPLACE INTO login_mfa (user_id, method, token_hash, expires_at, attempts)
         VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL {$minutes} MINUTE), 0)"
    );
    $stmt->bind_param("iss", $uid, $method, $hash);
    $stmt->execute();
    $stmt->close();

    $ok = false;
    try {
        $name = (string) $user["full_name"];
        $safeName = htmlspecialchars($name, ENT_QUOTES, "UTF-8");
        $html = "<div style=\"font-family:Arial,sans-serif;max-width:480px;margin:auto;color:#222;line-height:1.5\">"
            . "<p>Hi {$safeName},</p>"
            . "<p>Use this code to finish signing in to Pahuway Space:</p>"
            . "<p style=\"font-size:28px;font-weight:bold;letter-spacing:6px;margin:16px 0\">{$code}</p>"
            . "<p style=\"font-size:13px;color:#666\">This code expires in {$minutes} minutes. "
            . "If you didn't try to sign in, someone may know your password &mdash; please change it.</p>"
            . "<p style=\"font-size:13px;color:#666\">Pahuway Space</p></div>";
        $text = "Hi {$name},\n\nUse this code to finish signing in to Pahuway Space:\n\n{$code}\n\n"
            . "This code expires in {$minutes} minutes. If you didn't try to sign in, someone may know your password - please change it.\n\nPahuway Space";
        $ok = sendPahuwayEmail((string) $user["email"], $name, "Your Pahuway Space sign-in code", $html, $text);
    } catch (Throwable $e) {
        error_log("[pahuway] mfa_send: " . $e->getMessage());
        $ok = false;
    }

    if (!$ok) {
        // Nothing was delivered, so don't make the user wait out a cooldown for it.
        $del = $conn->prepare("DELETE FROM login_mfa WHERE user_id = ?");
        $del->bind_param("i", $uid);
        $del->execute();
        $del->close();
        return "failed";
    }

    $lg = $conn->prepare("INSERT INTO login_mfa_log (user_id, method) VALUES (?, ?)");
    $lg->bind_param("is", $uid, $method);
    $lg->execute();
    $lg->close();

    return "sent";
}

/**
 * Checks a submitted code. Returns "ok", "wrong", "expired", "locked" or "none".
 * Every guess is counted before it is compared so parallel requests can't skip the cap.
 */
function mfa_check_code(mysqli $conn, int $uid, string $submitted): string
{
    ensure_mfa_schema($conn);

    $stmt = $conn->prepare("SELECT method, token_hash, (expires_at < NOW()) AS expired FROM login_mfa WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) return "none";
    if ((int) $row["expired"] === 1) return "expired";

    $max = MFA_MAX_ATTEMPTS;
    $inc = $conn->prepare("UPDATE login_mfa SET attempts = attempts + 1 WHERE user_id = ? AND attempts < {$max}");
    $inc->bind_param("i", $uid);
    $inc->execute();
    $counted = $inc->affected_rows === 1;
    $inc->close();
    if (!$counted) return "locked";

    return hash_equals($row["token_hash"], mfa_code_hash($uid, $row["method"], $submitted)) ? "ok" : "wrong";
}
