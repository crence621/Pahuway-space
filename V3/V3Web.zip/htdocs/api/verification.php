<?php

/*
 * Email-verification helpers shared by signup.php, resend-verification.php
 * and verify-code.php.
 *
 * Uses a 6-digit code (no link in the email). The code is never stored in
 * plain text: the table keeps sha256(user_id:code) in the token_hash column.
 */

require_once __DIR__ . "/mail.php";

const VERIFY_CODE_MINUTES = 15;

/** Hash stored in email_verifications.token_hash for a given user + code. */
function verification_code_hash(int $userId, string $code): string
{
    return hash("sha256", $userId . ":" . $code);
}

/**
 * Creates a fresh 6-digit code for the user (replacing any older one, which
 * also resets the attempt counter) and emails it.
 * Returns true if the email was handed to the SMTP server.
 */
function send_verification_email(mysqli $conn, int $userId, string $email, string $name): bool
{
    $code = str_pad((string) random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $hash = verification_code_hash($userId, $code);
    $minutes = VERIFY_CODE_MINUTES;

    $stmt = $conn->prepare(
        "REPLACE INTO email_verifications (user_id, token_hash, expires_at, attempts)
         VALUES (?, ?, DATE_ADD(NOW(), INTERVAL {$minutes} MINUTE), 0)"
    );
    $stmt->bind_param("is", $userId, $hash);
    $stmt->execute();
    $stmt->close();

    $safeName = htmlspecialchars($name, ENT_QUOTES, "UTF-8");

    $html = "<div style=\"font-family:Arial,sans-serif;max-width:480px;margin:auto;color:#222;line-height:1.5\">"
        . "<p>Hi {$safeName},</p>"
        . "<p>Thanks for signing up for Pahuway Space. "
        . "Enter this code on the sign-up page to confirm your email address:</p>"
        . "<p style=\"font-size:28px;font-weight:bold;letter-spacing:6px;margin:16px 0\">{$code}</p>"
        . "<p style=\"font-size:13px;color:#666\">This code expires in {$minutes} minutes. "
        . "If you didn't create an account, you can ignore this email.</p>"
        . "<p style=\"font-size:13px;color:#666\">Pahuway Space</p></div>";

    $text = "Hi {$name},\n\n"
        . "Thanks for signing up for Pahuway Space. "
        . "Enter this code on the sign-up page to confirm your email address:\n\n"
        . "{$code}\n\n"
        . "This code expires in {$minutes} minutes. If you didn't create an account, you can ignore this email.\n\n"
        . "Pahuway Space";

    return sendPahuwayEmail($email, $name, "Your Pahuway Space verification code", $html, $text);
}
