<?php
/*
 * Account ID number, format YYYYMM-000000
 *   YYYYMM  = year and month the account was created
 *   000000  = the account's running number, zero-padded to 6 digits
 * e.g. an account created in November 2026 with number 57 is 202611-000057.
 *
 * Stored in users.account_no (unique). The column is added automatically the
 * first time this runs, and any account without a number (including every
 * account that existed before this feature) is numbered from its own
 * created_at date, so no manual SQL is needed.
 */

function ensure_account_no(mysqli $conn): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    try {
        $res = $conn->query("SHOW COLUMNS FROM users LIKE 'account_no'");
        if ($res && $res->num_rows === 0) {
            $conn->query("ALTER TABLE users ADD COLUMN account_no varchar(13) NULL DEFAULT NULL AFTER user_id");
        }
        // Number any account that does not have one yet (new sign-ups and old accounts)
        $conn->query(
            "UPDATE users
             SET account_no = CONCAT(DATE_FORMAT(created_at, '%Y%m'), '-', LPAD(user_id, 6, '0'))
             WHERE account_no IS NULL OR account_no = ''"
        );
        $idx = $conn->query("SHOW INDEX FROM users WHERE Key_name = 'uq_users_account_no'");
        if ($idx && $idx->num_rows === 0) {
            $conn->query("ALTER TABLE users ADD UNIQUE KEY uq_users_account_no (account_no)");
        }
    } catch (Throwable $e) {
        error_log("[pahuway] ensure_account_no: " . $e->getMessage());
    }
}
