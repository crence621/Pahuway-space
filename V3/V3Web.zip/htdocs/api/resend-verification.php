<?php

ini_set("display_errors", "0");
header("Content-Type: application/json");

require_once "db.php";
require_once "verification.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

$email = trim($_POST["email"] ?? "");

// Same answer whether or not the account exists, so this can't be used to probe emails.
$generic = [
    "success" => true,
    "message" => "If that account exists and isn't verified yet, a new verification code is on its way."
];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["success" => false, "message" => "Please enter a valid email address."]);
    exit;
}

$stmt = $conn->prepare("SELECT user_id, full_name, email_verified FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user || (int) $user["email_verified"] === 1) {
    echo json_encode($generic);
    exit;
}

$uid = (int) $user["user_id"];

// Rate limit: one email per 60 seconds per account.
$rl = $conn->prepare("SELECT 1 FROM email_verifications WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND) LIMIT 1");
$rl->bind_param("i", $uid);
$rl->execute();
$tooSoon = $rl->get_result()->num_rows > 0;
$rl->close();

if ($tooSoon) {
    echo json_encode(["success" => false, "message" => "Please wait a minute before requesting another code."]);
    exit;
}

if (!send_verification_email($conn, $uid, $email, $user["full_name"])) {
    echo json_encode(["success" => false, "message" => "We couldn't send the email code right now. Please try again later."]);
    exit;
}

echo json_encode($generic);
