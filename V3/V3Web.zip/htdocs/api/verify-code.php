<?php

ini_set("display_errors", "0");
header("Content-Type: application/json");

require_once "db.php";
require_once "verification.php";

const MAX_CODE_ATTEMPTS = 5;

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

$email = trim($_POST["email"] ?? "");
$emailCode = trim($_POST["code"] ?? "");

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["success" => false, "message" => "Enter the verification code we sent you."]);
    exit;
}

$stmt = $conn->prepare("SELECT user_id, email_verified FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    echo json_encode(["success" => false, "message" => "That code is incorrect or has expired. Check the code or request a new one."]);
    exit;
}

$uid = (int) $user["user_id"];

if ((int) $user["email_verified"] === 1) {
    echo json_encode(["success" => true, "message" => "Your email is already verified. You can log in."]);
    exit;
}

if (!preg_match('/^\d{6}$/', $emailCode)) {
    echo json_encode(["success" => false, "message" => "Enter the 6-digit code from your email."]);
    exit;
}

/* Every guess is counted before it is compared, so parallel requests can't skip the attempt cap. */
$stmt = $conn->prepare(
    "SELECT token_hash, (expires_at < NOW()) AS expired
     FROM email_verifications WHERE user_id = ? LIMIT 1"
);
$stmt->bind_param("i", $uid);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    echo json_encode(["success" => false, "message" => "The email code is incorrect or has expired."]);
    exit;
}
if ((int) $row["expired"] === 1) {
    echo json_encode(["success" => false, "message" => "The email code has expired. Request a new one."]);
    exit;
}

$max = MAX_CODE_ATTEMPTS;
$inc = $conn->prepare("UPDATE email_verifications SET attempts = attempts + 1 WHERE user_id = ? AND attempts < {$max}");
$inc->bind_param("i", $uid);
$inc->execute();
$counted = $inc->affected_rows === 1;
$inc->close();

if (!$counted) {
    echo json_encode(["success" => false, "message" => "Too many incorrect email code attempts. Request a new code."]);
    exit;
}

if (!hash_equals($row["token_hash"], verification_code_hash($uid, $emailCode))) {
    echo json_encode(["success" => false, "message" => "The email code is incorrect or has expired."]);
    exit;
}

$up = $conn->prepare("UPDATE users SET email_verified = 1 WHERE user_id = ?");
$up->bind_param("i", $uid);
$up->execute();
$up->close();

$del = $conn->prepare("DELETE FROM email_verifications WHERE user_id = ?");
$del->bind_param("i", $uid);
$del->execute();
$del->close();

echo json_encode(["success" => true, "message" => "Email verified! You can now log in."]);
