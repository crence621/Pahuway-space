<?php
/*
 * Audit log + admin one-time-code storage.
 *
 * audit_log() never throws and never blocks the request it is called from:
 * if logging fails, the real action still goes through.
 * The log is append-only (the admin panel can read it but has no edit/delete).
 *
 * The tables are created automatically on first use; admin_security_migration.sql
 * has the same statements if you prefer to run them by hand in phpMyAdmin.
 */

function ensure_security_tables(mysqli $conn): void
{
    if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION["sec_tables_v1"])) return;
    try {
        $conn->query(
            "CREATE TABLE IF NOT EXISTS `audit_log` (
              `log_id`      bigint unsigned NOT NULL AUTO_INCREMENT,
              `created_at`  timestamp NOT NULL DEFAULT current_timestamp(),
              `actor_id`    int unsigned DEFAULT NULL,
              `actor_name`  varchar(150) NOT NULL DEFAULT 'Guest',
              `category`    enum('auth','security','admin') NOT NULL,
              `action`      varchar(40) NOT NULL,
              `target_type` varchar(30) DEFAULT NULL,
              `target_id`   int unsigned DEFAULT NULL,
              `summary`     varchar(255) NOT NULL,
              `ip`          varchar(45) NOT NULL DEFAULT '',
              `result`      enum('success','failure') NOT NULL DEFAULT 'success',
              PRIMARY KEY (`log_id`),
              KEY `idx_audit_created` (`created_at`),
              KEY `idx_audit_action` (`action`, `created_at`),
              KEY `idx_audit_category` (`category`, `created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $conn->query(
            "CREATE TABLE IF NOT EXISTS `admin_otp` (
              `user_id`    int unsigned NOT NULL,
              `salt`       char(32) NOT NULL,
              `code_hash`  char(64) NOT NULL,
              `expires_at` datetime NOT NULL,
              `attempts`   tinyint unsigned NOT NULL DEFAULT 0,
              `sent_at`    timestamp NOT NULL DEFAULT current_timestamp(),
              PRIMARY KEY (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        if (session_status() === PHP_SESSION_ACTIVE) $_SESSION["sec_tables_v1"] = 1;
    } catch (Throwable $e) {
        error_log("[pahuway] could not create security tables: " . $e->getMessage());
    }
}

/* Strip control characters (log injection) and cap the length. */
function audit_clean(string $s, int $max = 255): string
{
    $s = preg_replace('/[\x00-\x1F\x7F]+/u', " ", $s) ?? "";
    $s = trim($s);
    return function_exists("mb_substr") ? mb_substr($s, 0, $max) : substr($s, 0, $max);
}

/*
 * $category : auth | security | admin
 * $action   : short machine name, e.g. login_failed, status_change, delete
 * $o        : actor_id, actor_name, target_type, target_id, result (success|failure)
 */
function audit_log(mysqli $conn, string $category, string $action, string $summary, array $o = []): void
{
    try {
        ensure_security_tables($conn);

        $actorId = isset($o["actor_id"]) ? (int) $o["actor_id"] : null;
        $name = isset($o["actor_name"]) ? (string) $o["actor_name"] : "";
        if ($name === "" && $actorId) {
            $s = $conn->prepare("SELECT full_name FROM users WHERE user_id = ? LIMIT 1");
            if ($s) {
                $s->bind_param("i", $actorId);
                $s->execute();
                $r = $s->get_result()->fetch_row();
                $name = $r ? (string) $r[0] : "";
                $s->close();
            }
        }
        if ($name === "") $name = "Guest";

        $targetType = isset($o["target_type"]) ? audit_clean((string) $o["target_type"], 30) : null;
        $targetId = isset($o["target_id"]) ? (int) $o["target_id"] : null;
        $result = (($o["result"] ?? "success") === "failure") ? "failure" : "success";
        $ip = substr((string) ($_SERVER["REMOTE_ADDR"] ?? ""), 0, 45);
        $name = audit_clean($name, 150);
        $action = audit_clean($action, 40);
        $summary = audit_clean($summary, 255);

        $stmt = $conn->prepare(
            "INSERT INTO audit_log (actor_id, actor_name, category, action, target_type, target_id, summary, ip, result)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        if (!$stmt) return;
        $stmt->bind_param("issssisss", $actorId, $name, $category, $action, $targetType, $targetId, $summary, $ip, $result);
        $stmt->execute();
        $stmt->close();
    } catch (Throwable $e) {
        error_log("[pahuway] audit_log failed: " . $e->getMessage());
    }
}
