<?php

session_start();
require_once "db.php";
require_once "profile_helpers.php";
require_once "phone_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$phone = trim($_POST["phone"] ?? "");
$facebook = trim($_POST["facebook"] ?? "");
$member_type = $_POST["member_type"] ?? "";

ensure_profile_columns($conn);

if ($phone === "") {
    echo json_encode(["success" => false, "message" => "Please enter your mobile number."]);
    exit;
}

$normalized = normalize_phone($phone);
if ($normalized === null) {
    echo json_encode(["success" => false, "message" => "Please enter a valid mobile number, e.g. 0917 123 4567."]);
    exit;
}
$phone = $normalized;

if (strlen($facebook) > 255) {
    echo json_encode(["success" => false, "message" => "Facebook link is too long."]);
    exit;
}

if (!in_array($member_type, ["renter", "owner"], true)) {
    echo json_encode(["success" => false, "message" => "Please choose renter or owner."]);
    exit;
}

$stmt = $conn->prepare("UPDATE users SET phone = ?, facebook = ?, member_type = ? WHERE user_id = ?");
$stmt->bind_param("sssi", $phone, $facebook, $member_type, $user_id);

if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Could not save: " . $stmt->error]);
    exit;
}

$stmt->close();
$conn->close();

echo json_encode(["success" => true, "message" => "Account setup complete."]);

?>
