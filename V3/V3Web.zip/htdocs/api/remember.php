<?php
/*
 * "Remember me" for sign-in.
 *
 * When the box is ticked at login, a random token is stored (hashed) in the
 * remember_tokens table and sent to the browser in a 30-day cookie. If the
 * normal PHP session has expired or the browser was closed, db.php calls
 * remember_auto_login() and the user is signed back in from that cookie.
 * Without the box ticked nothing is stored and the session ends when the
 * browser closes, as before.
 *
 * The admin panel's own password unlock is NOT bypassed by this: a restored
 * session still has to unlock the admin panel with the admin's password.
 */

const REMEMBER_COOKIE = "pahuway_remember";
const REMEMBER_DAYS = 30;

function remember_ensure_table(mysqli $conn): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $conn->query(
        "CREATE TABLE IF NOT EXISTS `remember_tokens` (
            `token_id`   int unsigned NOT NULL AUTO_INCREMENT,
            `user_id`    int unsigned NOT NULL,
            `selector`   char(24) NOT NULL,
            `token_hash` char(64) NOT NULL,
            `expires_at` datetime NOT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`token_id`),
            UNIQUE KEY `uq_remember_selector` (`selector`),
            KEY `idx_remember_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function remember_cookie_set(string $value, int $expires): void
{
    if (headers_sent()) return;
    $https = (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off")
        || (($_SERVER["HTTP_X_FORWARDED_PROTO"] ?? "") === "https");
    setcookie(REMEMBER_COOKIE, $value, [
        "expires"  => $expires,
        "path"     => "/",
        "secure"   => $https,
        "httponly" => true,
        "samesite" => "Lax",
    ]);
}

/** Create a remember token for this user and send the cookie. */
function remember_issue(mysqli $conn, int $userId): void
{
    try {
        remember_ensure_table($conn);

        $selector  = bin2hex(random_bytes(12));
        $validator = bin2hex(random_bytes(32));
        $hash      = hash("sha256", $validator);
        $days      = REMEMBER_DAYS;

        $stmt = $conn->prepare(
            "INSERT INTO remember_tokens (user_id, selector, token_hash, expires_at)
             VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL {$days} DAY))"
        );
        $stmt->bind_param("iss", $userId, $selector, $hash);
        $stmt->execute();
        $stmt->close();

        // tidy up expired tokens
        $conn->query("DELETE FROM remember_tokens WHERE expires_at < NOW()");

        remember_cookie_set($selector . ":" . $validator, time() + $days * 86400);
    } catch (Throwable $e) {
        error_log("[pahuway] remember_issue: " . $e->getMessage());
    }
}

/** Remove this browser's token (if any) and clear the cookie. */
function remember_forget(mysqli $conn): void
{
    try {
        $cookie = $_COOKIE[REMEMBER_COOKIE] ?? "";
        if ($cookie !== "" && strpos($cookie, ":") !== false) {
            [$selector] = explode(":", $cookie, 2);
            remember_ensure_table($conn);
            $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE selector = ?");
            $stmt->bind_param("s", $selector);
            $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $e) {
        error_log("[pahuway] remember_forget: " . $e->getMessage());
    }
    remember_cookie_set("", time() - 3600);
    unset($_COOKIE[REMEMBER_COOKIE]);
}

/** If there is no logged-in session but a valid remember cookie, log the user in. */
function remember_auto_login(mysqli $conn): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) return;
    if (!empty($_SESSION["user_id"])) return;

    $cookie = $_COOKIE[REMEMBER_COOKIE] ?? "";
    if ($cookie === "" || strpos($cookie, ":") === false) return;

    try {
        [$selector, $validator] = explode(":", $cookie, 2);
        if (!preg_match('/^[a-f0-9]{24}$/', $selector) || !preg_match('/^[a-f0-9]{64}$/', $validator)) {
            remember_cookie_set("", time() - 3600);
            return;
        }

        remember_ensure_table($conn);

        $stmt = $conn->prepare(
            "SELECT remember_tokens.token_hash, users.user_id, users.full_name, users.email, users.email_verified
             FROM remember_tokens
             INNER JOIN users ON users.user_id = remember_tokens.user_id
             WHERE remember_tokens.selector = ? AND remember_tokens.expires_at > NOW()
             LIMIT 1"
        );
        $stmt->bind_param("s", $selector);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row || !hash_equals($row["token_hash"], hash("sha256", $validator)) || (int) $row["email_verified"] !== 1) {
            remember_cookie_set("", time() - 3600);
            return;
        }

        @session_regenerate_id(true);
        $_SESSION["user_id"]   = (int) $row["user_id"];
        $_SESSION["full_name"] = $row["full_name"];
        $_SESSION["email"]     = $row["email"];
    } catch (Throwable $e) {
        error_log("[pahuway] remember_auto_login: " . $e->getMessage());
    }
}
