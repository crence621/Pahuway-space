<?php

/*
 * Step 3 of signing in: check the 6-digit code and, if it is right, create the session.
 * POST code=123456
 */

ini_set("display_errors", "0");
header("Content-Type: application/json");
@session_start();

require_once "db.php";
require_once "audit.php";
require_once "mfa.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

$pending = mfa_pending_get();
if (!$pending) {
    echo json_encode([
        "success" => false,
        "code" => "mfa_expired",
        "message" => "Your sign-in session expired. Please enter your email and password again."
    ]);
    exit;
}

$code = trim($_POST["code"] ?? "");
if (!preg_match('/^\d{6}$/', $code)) {
    echo json_encode(["success" => false, "message" => "Enter the 6-digit code."]);
    exit;
}

$uid = (int) $pending["user_id"];
$result = mfa_check_code($conn, $uid, $code);

if ($result !== "ok") {
    audit_log($conn, "auth", "login_failed", "Wrong sign-in code (" . $result . ")", ["actor_id" => $uid, "result" => "failure"]);

    $messages = [
        "none" => "No code has been sent yet. Choose how you want to receive one.",
        "expired" => "That code has expired. Request a new one.",
        "locked" => "Too many incorrect attempts. Request a new code.",
        "wrong" => "That code is incorrect. Check it and try again.",
    ];
    echo json_encode([
        "success" => false,
        "code" => $result,
        "message" => $messages[$result] ?? $messages["wrong"]
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT user_id, full_name, email FROM users WHERE user_id = ? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    mfa_pending_clear();
    echo json_encode(["success" => false, "code" => "mfa_expired", "message" => "Please sign in again."]);
    exit;
}

$del = $conn->prepare("DELETE FROM login_mfa WHERE user_id = ?");
$del->bind_param("i", $uid);
$del->execute();
$del->close();

$remember = !empty($pending["remember"]);
mfa_pending_clear();

/* Create session */
@session_regenerate_id(true);
$_SESSION["user_id"] = (int) $user["user_id"];
$_SESSION["full_name"] = $user["full_name"];
$_SESSION["email"] = $user["email"];

if ($remember) {
    remember_issue($conn, (int) $user["user_id"]);
} else {
    remember_forget($conn);
}

audit_log($conn, "auth", "login_success", "Signed in (two-step verified)", ["actor_id" => (int) $user["user_id"]]);

echo json_encode([
    "success" => true,
    "message" => "Login successful.",
    "user" => [
        "user_id" => (int) $user["user_id"],
        "full_name" => $user["full_name"],
        "email" => $user["email"]
    ]
]);

$conn->close();
