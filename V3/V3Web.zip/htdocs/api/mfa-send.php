<?php

/*
 * Step 2 of signing in: email the sign-in code.
 * POST (no fields)   (only works right after a correct password, see login.php)
 */

ini_set("display_errors", "0");
header("Content-Type: application/json");
@session_start();

require_once "db.php";
require_once "mfa.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

$pending = mfa_pending_get();
if (!$pending) {
    echo json_encode([
        "success" => false,
        "code" => "mfa_expired",
        "message" => "Your sign-in session expired. Please enter your email and password again."
    ]);
    exit;
}

$uid = (int) $pending["user_id"];
$stmt = $conn->prepare("SELECT user_id, full_name, email FROM users WHERE user_id = ? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    mfa_pending_clear();
    echo json_encode(["success" => false, "code" => "mfa_expired", "message" => "Please sign in again."]);
    exit;
}

$result = mfa_send($conn, $user);

switch ($result) {
    case "sent":
        $masked = mask_email((string) $user["email"]);
        echo json_encode([
            "success" => true,
            "method" => "email",
            "destination" => $masked,
            "minutes" => MFA_CODE_MINUTES,
            "message" => "We emailed a 6-digit code to " . $masked . "."
        ]);
        break;
    case "too_soon":
        echo json_encode(["success" => false, "code" => "too_soon", "message" => "A code was just sent. Please wait a minute before requesting another."]);
        break;
    case "limit":
        echo json_encode(["success" => false, "message" => "Too many codes were requested for this account. Please try again in an hour."]);
        break;
    default:
        echo json_encode(["success" => false, "message" => "We couldn't send the email code right now. Please try again shortly."]);
}

$conn->close();
