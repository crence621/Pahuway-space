/*
 * Live admin dashboard.
 * Polls api/stats.php every few seconds (works on any shared host, no
 * websockets needed). Polling pauses while the tab is hidden, while the
 * "Data tables" view is open, or when the admin presses Pause, and it backs
 * off automatically if the server errors.
 */
(() => {
  const API = "api/stats.php";
  const REPORT_API = "api/report.php";
  const BASE_MS = 5000;
  const MAX_MS = 30000;
  const $ = (id) => document.getElementById(id);
  const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { maximumFractionDigits: 2 });
  const num = (n) => Number(n || 0).toLocaleString("en-PH");

  let timer = null;
  let delay = BASE_MS;
  let paused = false;
  let locked = false;
  let inFlight = false;
  let lastOk = null;      // Date of last successful refresh
  let lastKpis = null;    // previous KPI values, to flash on change
  let seenFeed = null;    // Set of "type:ref" already shown
  let latest = null;      // last payload, for re-rendering relative times
  let pd = null;          // period picker (period.js)
  let periodKey = "";     // which period the shown numbers belong to

  /* ---------- status pill ---------- */
  function setLive(state, text) {
    const el = $("dash-live");
    el.dataset.state = state;
    $("dash-live-text").textContent = text;
  }

  function ago(ts) {
    const s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
    if (s < 10) return "just now";
    if (s < 60) return s + "s ago";
    if (s < 3600) return Math.floor(s / 60) + "m ago";
    if (s < 86400) return Math.floor(s / 3600) + "h ago";
    if (s < 7 * 86400) return Math.floor(s / 86400) + "d ago";
    return new Date(ts * 1000).toLocaleDateString("en-PH", { day: "numeric", month: "short", year: "numeric" });
  }

  function tickUpdated() {
    if (!lastOk) return;
    const secs = Math.floor((Date.now() - lastOk.getTime()) / 1000);
    $("dash-updated").textContent = "Last updated " + (secs < 2 ? "just now" : secs + "s ago");
    document.querySelectorAll("#dash-feed [data-ts], #dash-audit [data-ts]").forEach((el) => { el.textContent = ago(Number(el.dataset.ts)); });
  }

  /* ---------- KPI cards ---------- */
  function setKpi(key, text, raw) {
    const card = document.querySelector('[data-kpi="' + key + '"]');
    if (!card) return;
    card.querySelector("strong").textContent = text;
    if (lastKpis && lastKpis[key] !== undefined && lastKpis[key] !== raw) {
      card.classList.remove("is-flash");
      void card.offsetWidth; // restart the transition
      card.classList.add("is-flash");
      setTimeout(() => card.classList.remove("is-flash"), 900);
    }
  }

  function setSub(name, text) {
    const el = document.querySelector('[data-sub="' + name + '"]');
    if (el) el.textContent = text;
  }

  function heading(key, text) {
    const card = document.querySelector('[data-kpi="' + key + '"] h3');
    if (card) card.textContent = text;
  }

  function renderKpis(k, period) {
    const all = period === "all";
    heading("users_total", all ? "Users" : "New users");
    heading("properties_total", all ? "Properties" : "New properties");
    heading("bookings_total", all ? "Bookings" : "Bookings made");
    heading("revenue_paid", all ? "Revenue (paid)" : "Revenue paid");
    setKpi("users_total", num(k.users), k.users);
    setKpi("properties_total", num(k.properties), k.properties);
    setKpi("bookings_total", num(k.bookings), k.bookings);
    setKpi("revenue_paid", peso(k.revenue_paid), k.revenue_paid);

    setSub("users", num(k.users_verified) + " verified" + (all ? "" : " · " + num(k.users_all) + " in total"));
    setSub("properties", num(k.properties_pending) + " awaiting verification" + (all ? "" : " · " + num(k.properties_all) + " in total"));
    setSub("bookings", all ? "" : num(k.bookings_all) + " in total");
    setSub("revenue", peso(k.revenue_pending) + " pending" + (all ? "" : " · " + peso(k.revenue_all) + " all-time"));
    lastKpis = Object.assign({}, { users_total: k.users, properties_total: k.properties, bookings_total: k.bookings, revenue_paid: k.revenue_paid }, lastSec);
  }

  /* ---------- security & audit ---------- */
  let lastSec = {};
  function renderSecurity(sec, period) {
    const c = sec.counts;
    const suffix = period === "all" ? " (all time)" : "";
    [["failed_logins_24h", "Failed logins"], ["failed_unlocks_24h", "Panel unlock failures"], ["admin_actions_24h", "Admin actions"]].forEach(([key, text]) => heading(key, text + suffix));
    // the server now sends period-based counts under plain names; map them onto the existing cards
    const cc = { failed_logins_24h: c.failed_logins, failed_unlocks_24h: c.failed_unlocks, admin_actions_24h: c.admin_actions, admin_accounts: c.admin_accounts, unverified_accounts: c.unverified_accounts };
    ["failed_logins_24h", "failed_unlocks_24h", "admin_actions_24h", "admin_accounts", "unverified_accounts"].forEach((key) => {
      const card = document.querySelector('[data-kpi="' + key + '"]');
      if (!card) return;
      card.querySelector("strong").textContent = num(cc[key]);
      card.classList.toggle("is-alert", (key === "failed_logins_24h" || key === "failed_unlocks_24h") && cc[key] >= 5);
      if (lastKpis && lastKpis[key] !== undefined && lastKpis[key] !== cc[key]) {
        card.classList.remove("is-flash");
        void card.offsetWidth;
        card.classList.add("is-flash");
        setTimeout(() => card.classList.remove("is-flash"), 900);
      }
    });
    setSub("logins", num(c.logins) + " successful sign-in" + (c.logins === 1 ? "" : "s"));
    setSub("unlock", sec.last_unlock ? "Last unlock " + ago(sec.last_unlock) : "No unlocks recorded yet");
    setSub("mfa", "Email code: " + (sec.mfa ? "on" : "OFF"));
    lastSec = Object.assign({}, cc);

    const feed = $("dash-audit");
    $("dash-audit-note").textContent = sec.recent_total > sec.recent.length ? "showing latest " + sec.recent.length + " of " + num(sec.recent_total) : sec.recent_total ? num(sec.recent_total) + " in this period" : "";
    if (!sec.recent.length) {
      const li = document.createElement("li");
      li.className = "adm-empty";
      li.textContent = period === "all" ? "No audit events yet. Sign-ins and admin actions will appear here." : "No audit events in this period.";
      feed.replaceChildren(li);
      return;
    }
    feed.replaceChildren(...sec.recent.map((e) => {
      const li = document.createElement("li");
      if (e.result === "failure") li.classList.add("is-fail");
      const tag = document.createElement("span");
      tag.className = "dash-tag";
      tag.dataset.t = e.category;
      tag.textContent = e.category;
      const label = document.createElement("span");
      label.className = "dash-feed__label";
      label.textContent = e.summary + " · " + e.actor_name; // textContent: names and emails in logs are never parsed as HTML
      label.title = e.summary + " · " + e.actor_name + (e.ip ? " · " + e.ip : "");
      const time = document.createElement("span");
      time.className = "dash-feed__time";
      time.dataset.ts = e.ts;
      time.textContent = ago(e.ts);
      li.append(tag, label, time);
      return li;
    }));
  }

  /* ---------- status bars ---------- */
  function renderBars(id, data) {
    const box = $(id);
    const entries = Object.entries(data);
    const max = Math.max(1, ...entries.map(([, v]) => v));
    if (box.children.length !== entries.length) {
      box.replaceChildren(...entries.map(([k]) => {
        const row = document.createElement("div");
        row.className = "dash-bar";
        const label = document.createElement("span");
        label.textContent = k.charAt(0).toUpperCase() + k.slice(1);
        const track = document.createElement("div");
        track.className = "dash-bar__track";
        const fill = document.createElement("div");
        fill.className = "dash-bar__fill";
        fill.dataset.k = k;
        track.append(fill);
        const val = document.createElement("b");
        row.append(label, track, val);
        return row;
      }));
    }
    entries.forEach(([k, v], i) => {
      const row = box.children[i];
      row.querySelector(".dash-bar__fill").style.width = (v / max) * 100 + "%";
      row.querySelector("b").textContent = num(v);
    });
  }

  /* ---------- 14-day chart (inline SVG) ---------- */
  const NS = "http://www.w3.org/2000/svg";
  function svg(tag, attrs, text) {
    const el = document.createElementNS(NS, tag);
    Object.entries(attrs || {}).forEach(([k, v]) => el.setAttribute(k, v));
    if (text !== undefined) el.textContent = text;
    return el;
  }

  const CHART_TITLE = { hour: "By hour", day: "By day", month: "By month" };

  function renderChart(series, period) {
    const W = 640, H = 220, L = 30, R = 10, T = 10, B = 24;
    const a = series.bookings, b = series.users;
    const max = Math.max(3, ...a.map((d) => d.count), ...b.map((d) => d.count));
    const x = (i) => L + (i * (W - L - R)) / Math.max(1, a.length - 1);
    const y = (v) => T + (H - T - B) * (1 - v / max);
    const what = CHART_TITLE[series.unit] || "Over time";
    $("dash-chart-title").textContent = what + (period.period === "all" ? " (since the start)" : " · " + period.label);

    const root = svg("svg", { viewBox: "0 0 " + W + " " + H, role: "img", "aria-label": "Bookings and new users " + what.toLowerCase() + ", " + period.label });

    const step = max <= 6 ? 1 : Math.ceil(max / 4);
    for (let v = 0; v <= max; v += step) {
      root.append(svg("line", { x1: L, x2: W - R, y1: y(v), y2: y(v) }));
      root.append(svg("text", { x: L - 6, y: y(v) + 3, "text-anchor": "end" }, v));
    }
    const every = Math.ceil(a.length / 12); // keep the x labels readable for 24 hours / 36 months
    a.forEach((d, i) => {
      if (i % every === 0) {
        root.append(svg("text", { x: x(i), y: H - 6, "text-anchor": "middle" }, d.label));
      }
    });

    [[a, "#d4a917"], [b, "#33c9c0"]].forEach(([data, color]) => {
      const pts = data.map((d, i) => x(i) + "," + y(d.count)).join(" ");
      root.append(svg("polyline", { points: pts, fill: "none", stroke: color, "stroke-width": 2.5, "stroke-linejoin": "round", "stroke-linecap": "round" }));
      data.forEach((d, i) => {
        const dot = svg("circle", { cx: x(i), cy: y(d.count), r: data.length > 20 ? 2.5 : 3.5, fill: color });
        dot.append(svg("title", {}, d.label + ": " + d.count));
        root.append(dot);
      });
    });

    $("dash-chart").replaceChildren(root);
  }

  /* ---------- activity feed ---------- */
  function renderFeed(items, total, period) {
    const feed = $("dash-feed");
    $("dash-feed-note").textContent = total > items.length ? "showing latest " + items.length + " of " + num(total) : total ? num(total) + " in this period" : "";
    if (!items.length) {
      const li = document.createElement("li");
      li.className = "adm-empty";
      li.textContent = period === "all" ? "No activity yet." : "No activity in this period.";
      feed.replaceChildren(li);
      return;
    }
    const firstLoad = seenFeed === null;
    const nextSeen = new Set();
    const lis = items.map((it) => {
      const key = it.type + ":" + it.ref;
      nextSeen.add(key);
      const li = document.createElement("li");
      if (!firstLoad && !seenFeed.has(key)) li.className = "is-new";

      const tag = document.createElement("span");
      tag.className = "dash-tag";
      tag.dataset.t = it.type;
      tag.textContent = it.type;

      const label = document.createElement("span");
      label.className = "dash-feed__label";
      label.textContent = it.label; // textContent: user-supplied names/titles are never parsed as HTML

      const time = document.createElement("span");
      time.className = "dash-feed__time";
      time.dataset.ts = it.ts;
      time.textContent = ago(it.ts);

      li.append(tag, label, time);
      return li;
    });
    feed.replaceChildren(...lis);
    seenFeed = nextSeen;
  }

  function render(d) {
    latest = d;
    const key = d.period.period + "|" + d.period.from;
    if (key !== periodKey) { // switched period: don't flash every card or mark rows as "new"
      periodKey = key;
      lastKpis = null;
      seenFeed = null;
    }
    pd.setInfo(d.period);
    renderSecurity(d.security, d.period.period);
    renderKpis(d.kpis, d.period.period);
    renderBars("dash-bars-bookings", d.breakdowns.bookings);
    renderBars("dash-bars-properties", d.breakdowns.properties);
    renderBars("dash-bars-payments", d.breakdowns.payments);
    renderChart(d.series, d.period);
    renderFeed(d.activity, d.activity_total, d.period.period);
  }

  /* ---------- period + download ---------- */
  let redo = false;
  const qs = () => new URLSearchParams(pd.params()).toString();

  const dlSel = document.createElement("select");
  dlSel.setAttribute("aria-label", "What to download");
  [["full", "Full report"], ["summary", "Summary only"], ["activity", "Recent activity"], ["audit", "Audit events"]].forEach(([v, l]) => dlSel.append(new Option(l, v)));
  const dlBtn = Object.assign(document.createElement("button"), { type: "button", className: "adm-btn adm-btn--primary", textContent: "Download CSV" });
  const dlMsg = Object.assign(document.createElement("span"), { className: "pd-msg" });
  dlMsg.setAttribute("role", "status");
  let dlTimer = null;
  function say(text, bad) {
    dlMsg.textContent = text;
    dlMsg.dataset.bad = bad ? "1" : "";
    clearTimeout(dlTimer);
    dlTimer = setTimeout(() => { dlMsg.textContent = ""; }, 5000);
  }

  async function download() {
    dlBtn.disabled = true;
    try {
      const res = await fetch(REPORT_API + "?" + qs() + "&part=" + encodeURIComponent(dlSel.value), { cache: "no-store" });
      if (!res.ok || !/csv/i.test(res.headers.get("Content-Type") || "")) {
        let msg = "Download failed.";
        try { const j = await res.json(); if (res.status === 423) { locked = true; document.dispatchEvent(new CustomEvent("adm:locked")); } msg = j.message || msg; } catch (e) { /* not JSON */ }
        throw new Error(msg);
      }
      const name = ((res.headers.get("Content-Disposition") || "").match(/filename="?([^";]+)"?/) || [])[1] || "pahuway-report.csv";
      const blob = await res.blob();
      const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: name });
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      say("Downloaded " + name);
    } catch (e) { say(e.message, true); }
    finally { dlBtn.disabled = false; }
  }
  dlBtn.addEventListener("click", download);

  pd = AdmPeriod.create({ key: "dash", onChange: () => { clearTimeout(timer); if (inFlight) redo = true; else refresh(); } });
  const dl = document.createElement("span");
  dl.className = "pd-dl";
  dl.append(dlMsg, dlSel, dlBtn);
  $("dash-period").append(pd.el, dl);

  /* ---------- polling ---------- */
  function dashVisible() { return !$("adm-dash").hidden; }
  function shouldRun() { return !locked && !paused && !document.hidden && dashVisible(); }

  function schedule(ms) {
    clearTimeout(timer);
    timer = null;
    if (shouldRun()) timer = setTimeout(refresh, ms);
  }

  async function refresh() {
    if (inFlight) return;
    inFlight = true;
    try {
      const asked = qs();
      const res = await fetch(API + "?" + asked, { cache: "no-store" });
      let data;
      try { data = await res.json(); } catch { throw new Error("Server returned an unexpected response."); }
      if (res.status === 423) { locked = true; document.dispatchEvent(new CustomEvent("adm:locked")); return; }
      if (res.status === 401) { location.href = "../login.html"; return; }
      if (!data.success) throw new Error(data.message || "Request failed.");

      if (asked !== qs()) { redo = true; return; } // the admin changed the period while this was loading
      render(data);
      lastOk = new Date();
      delay = BASE_MS;
      setLive("live", "Live");
      tickUpdated();
    } catch (e) {
      console.error("Dashboard refresh failed:", e);
      delay = Math.min(MAX_MS, delay * 2);
      setLive("error", "Connection problem, retrying in " + Math.round(delay / 1000) + "s");
    } finally {
      inFlight = false;
      if (redo) { redo = false; refresh(); } else schedule(delay);
    }
  }

  function syncState() {
    if (paused) { setLive("paused", "Paused"); clearTimeout(timer); return; }
    if (!shouldRun()) { clearTimeout(timer); return; }
    setLive(lastOk ? "live" : "connecting", lastOk ? "Live" : "Connecting…");
    refresh(); // refresh immediately on resume / returning to the tab
  }

  /* ---------- wiring ---------- */
  const PANES = { dash: "adm-dash", properties: "pane-properties", users: "pane-users", bookings: "pane-bookings", payments: "pane-payments", audit: "pane-audit", data: "adm-data" };

  function showView(name) {
    if (!PANES[name]) name = "dash";
    Object.entries(PANES).forEach(([k, id]) => { const el = $(id); if (el) el.hidden = k !== name; });
    document.querySelectorAll(".adm-view-btn").forEach((b) => b.classList.toggle("is-active", b.dataset.view === name));
    try { history.replaceState(null, "", "#" + name); } catch (e) { /* ignore */ }
    document.dispatchEvent(new CustomEvent("adm:view", { detail: name }));
    syncState();
  }

  document.querySelectorAll(".adm-view-btn").forEach((b) => b.addEventListener("click", () => showView(b.dataset.view)));
  document.querySelectorAll("[data-goto]").forEach((b) => b.addEventListener("click", () => showView(b.dataset.goto)));

  $("dash-pause").addEventListener("click", () => {
    paused = !paused;
    $("dash-pause").textContent = paused ? "Resume" : "Pause";
    syncState();
  });

  /* ---------- print ---------- */
  // Runs for the button and for Ctrl/Cmd+P alike, so the header is always filled in.
  window.addEventListener("beforeprint", () => {
    const who = $("adm-who") ? $("adm-who").textContent : "";
    const when = lastOk ? lastOk.toLocaleString("en-PH") : "no data loaded yet";
    const per = latest && latest.period ? (latest.period.period === "all" ? "All time" : { day: "Day", week: "Week", year: "Year" }[latest.period.period] + ": " + latest.period.label) : "";
    $("dash-print-meta").textContent = (per ? "Period: " + per + " · " : "") + "Data as of " + when + (who ? " · Printed by " + who : "");
  });
  $("dash-print").addEventListener("click", () => window.print());

  document.addEventListener("visibilitychange", syncState);
  setInterval(tickUpdated, 1000);

  // Start only once admin.js has confirmed this is an admin.
  document.addEventListener("adm:ready", () => showView(location.hash.slice(1) || "dash"), { once: true });
})();
