/*
 * Admin panel light / dark mode.
 * Light is the default. The choice is saved in this browser (localStorage)
 * and applied before the page paints, so there is no flash on reload.
 */
(function () {
  var KEY = "pahuway-admin-theme";
  var root = document.documentElement;

  function saved() {
    try {
      var v = localStorage.getItem(KEY);
      return v === "dark" || v === "light" ? v : "light";
    } catch (e) {
      return "light";
    }
  }

  function apply(theme) {
    root.setAttribute("data-theme", theme);
    var btn = document.getElementById("adm-theme-toggle");
    if (btn) {
      var toDark = theme === "light";
      btn.setAttribute("aria-pressed", String(theme === "dark"));
      btn.setAttribute("aria-label", toDark ? "Switch to dark mode" : "Switch to light mode");
      var label = btn.querySelector(".adm-theme__label");
      if (label) label.textContent = toDark ? "Dark mode" : "Light mode";
    }
  }

  // Set right away (this script is loaded in <head>)
  apply(saved());

  document.addEventListener("DOMContentLoaded", function () {
    apply(saved());
    var btn = document.getElementById("adm-theme-toggle");
    if (!btn) return;
    btn.addEventListener("click", function () {
      var next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      try { localStorage.setItem(KEY, next); } catch (e) { /* private mode: still switches for this visit */ }
      apply(next);
    });
  });

  // Keep several open admin tabs in step
  window.addEventListener("storage", function (e) {
    if (e.key === KEY) apply(saved());
  });
})();
