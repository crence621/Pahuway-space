/*
 * Admin management sections: Properties, Users, Bookings, Payments.
 * Data is read from api/manage.php already joined (names, titles, ...), shown in
 * sortable / filterable tables, refreshed live every few seconds, with inline
 * actions plus Print and CSV export of whatever the current filter shows.
 * All text goes in through textContent / text nodes, never innerHTML.
 */
(() => {
  const API = "api/manage.php";
  const POLL_MS = 5000;
  const $ = (id) => document.getElementById(id);

  /* ---------- tiny DOM helper ---------- */
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v === false || v == null) continue;
      if (k === "class") el.className = v;
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, "");
      else el.setAttribute(k, v);
    }
    kids.flat().forEach((c) => { if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c))); });
    return el;
  }

  /* ---------- formatting ---------- */
  const money = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const dt = (s) => (s ? String(s).slice(0, 16).replace("T", " ") : "");
  const day = (s) => (s ? String(s).slice(0, 10) : "");
  const yesno = (v) => (Number(v) ? "Yes" : "No");
  const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : "");
  const badge = (v, label) => h("span", { class: "mg-badge", "data-v": v }, label ?? cap(String(v)));

  /* ---------- section definitions ---------- */
  const STATUS = {
    properties: ["available", "rented", "inactive"],
    bookings: ["pending", "confirmed", "cancelled"],
    payments: ["pending", "paid", "failed", "refunded"],
  };

  const ENT = {
    properties: {
      title: "Properties", blurb: "Every listing, its owner and its verification status.",
      chip: "status", search: "Search title, code, owner, city…",
      extra: { key: "verified", options: [["", "All listings"], ["1", "Verified"], ["0", "Awaiting verification"]] },
      columns: [
        { key: "code", label: "Code" },
        { key: "title", label: "Title", sort: "title" },
        { key: "type", label: "Type" },
        { key: "city", label: "City" },
        { key: "owner", label: "Owner", sort: "owner" },
        { key: "price", label: "Price", sort: "price", text: (r) => money(r.price) + " / " + r.price_unit },
        { key: "status", label: "Status", sort: "status", select: true },
        { key: "verified", label: "Verified", text: (r) => yesno(r.verified), cell: (r) => badge(Number(r.verified) ? "yes" : "no", yesno(r.verified)) },
        { key: "slots", label: "Slots", text: (r) => (Number(r.slots) > 1 ? r.slots + " slots · " : "1 slot · ") + Number(r.taken_now) + " taken now" },
        { key: "bookings", label: "Bookings" },
        { key: "created_at", label: "Listed", sort: "created_at", text: (r) => dt(r.created_at) },
      ],
    },
    users: {
      title: "Users", blurb: "Registered accounts, roles and email verification.",
      chip: "role", search: "Search name, email or account ID…",
      extra: { key: "verified", options: [["", "All accounts"], ["1", "Email verified"], ["0", "Not verified"]] },
      columns: [
        { key: "account_no", label: "Account ID", sort: "account_no" },
        { key: "full_name", label: "Name", sort: "full_name" },
        { key: "email", label: "Email", sort: "email" },
        { key: "role", label: "Role", sort: "role", cell: (r) => badge(r.role) },
        { key: "verified", label: "Email verified", text: (r) => yesno(r.verified), cell: (r) => badge(Number(r.verified) ? "yes" : "no", yesno(r.verified)) },
        { key: "properties", label: "Listings" },
        { key: "bookings", label: "Bookings" },
        { key: "created_at", label: "Joined", sort: "created_at", text: (r) => dt(r.created_at) },
      ],
    },
    bookings: {
      title: "Bookings", blurb: "Rental records: who booked what, and where each booking stands.",
      chip: "status", search: "Search property, tenant, owner…",
      columns: [
        { key: "id", label: "#", sort: "id" },
        { key: "property", label: "Property", text: (r) => r.property + " (" + r.code + ")" },
        { key: "tenant", label: "Tenant", sort: "tenant", text: (r) => r.tenant + " <" + r.tenant_email + ">", cell: (r) => h("span", null, r.tenant, h("small", { class: "mg-sub" }, r.tenant_email)) },
        { key: "owner", label: "Owner" },
        { key: "check_in", label: "Check-in", sort: "check_in", text: (r) => day(r.check_in) },
        { key: "check_out", label: "Check-out", text: (r) => (/^\d{4}-/.test(r.check_out) ? r.check_out : "Open-ended") },
        { key: "guests", label: "Guests" },
        { key: "total_amount", label: "Total", sort: "total_amount", text: (r) => money(r.total_amount) },
        { key: "status", label: "Status", sort: "status", select: true },
        { key: "payment", label: "Payment", text: (r) => (r.payment ? cap(r.payment) : "None yet"), cell: (r) => (r.payment ? badge(r.payment) : h("span", { class: "adm-null" }, "None yet")) },
        { key: "created_at", label: "Booked", sort: "created_at", text: (r) => dt(r.created_at) },
      ],
    },
    audit: {
      title: "Audit log", readonly: true,
      blurb: "Read-only record of sign-ins, admin-panel security events and every change made by an admin. Pick a day, week or year to see (and export) just that time.",
      chip: "category", search: "Search details, person, action, IP…", period: true,
      extra: { key: "result", options: [["", "All results"], ["success", "Succeeded"], ["failure", "Failed"]] },
      columns: [
        { key: "created_at", label: "When", sort: "created_at", text: (r) => (r.created_at ? String(r.created_at).slice(0, 19) : "") },
        { key: "actor_name", label: "Who", sort: "actor_name" },
        { key: "category", label: "Type", cell: (r) => badge(r.category) },
        { key: "action", label: "Action", sort: "action", text: (r) => String(r.action).replace(/_/g, " ") },
        { key: "summary", label: "Details", wide: true },
        { key: "ip", label: "IP address", empty: "Not recorded" },
        { key: "result", label: "Result", text: (r) => cap(r.result), cell: (r) => badge(r.result === "success" ? "yes" : "no", cap(r.result)) },
      ],
    },
    payments: {
      title: "Payments", blurb: "Payment records linked to bookings.",
      chip: "status", search: "Search property, tenant, method, booking #…",
      columns: [
        { key: "id", label: "#", sort: "id" },
        { key: "booking_id", label: "Booking", text: (r) => "#" + r.booking_id },
        { key: "property", label: "Property" },
        { key: "tenant", label: "Tenant", sort: "tenant" },
        { key: "method", label: "Method" },
        { key: "amount", label: "Amount", sort: "amount", text: (r) => money(r.amount) },
        { key: "status", label: "Status", sort: "status", select: true },
        { key: "paid_at", label: "Paid at", empty: "Not yet paid" },
        { key: "created_at", label: "Created", sort: "created_at", text: (r) => dt(r.created_at) },
      ],
    },
  };

  const S = {}; // per-section state
  Object.keys(ENT).forEach((n) => {
    S[n] = { q: "", chip: "", extra: "", sort: "", dir: "desc", page: 1, rows: [], total: 0, facets: {}, sig: "", sel: new Set(), selKey: null, prev: new Map(), loaded: false, lastOk: null, busy: 0, el: {} };
  });
  let me = null;
  let active = null; // name of the visible section, or null
  let locked = false; // panel was locked (idle timeout / Lock button)
  let timer = null;

  // Empty values read as a formal phrase instead of a blank or "null"
  const EMPTY = "Not provided";
  const isBlank = (v) => v == null || v === "";
  const emptyText = (col) => col.empty || EMPTY;
  const text = (col, r) => {
    const v = col.text ? col.text(r) : r[col.key];
    return isBlank(v) ? emptyText(col) : String(v);
  };
  const isEmptyCell = (col, r) => !col.cell && !col.select && col.key !== "status" && isBlank(col.text ? col.text(r) : r[col.key]);

  /* ---------- network ---------- */
  async function parse(res) {
    let data;
    try { data = await res.json(); } catch { throw new Error("Server returned an unexpected response."); }
    if (res.status === 423) { locked = true; document.dispatchEvent(new CustomEvent("adm:locked")); throw new Error("Panel is locked."); }
    if (res.status === 401) { location.href = "../login.html"; throw new Error("Please log in again."); }
    if (!data.success) throw new Error(data.message || "Request failed.");
    return data;
  }
  const get = async (params) => parse(await fetch(API + "?" + new URLSearchParams(params), { cache: "no-store" }));
  const post = async (entity, op, id, extra = {}) => {
    const fd = new FormData();
    fd.append("entity", entity); fd.append("op", op); fd.append("id", id);
    Object.entries(extra).forEach(([k, v]) => {
      if (k === "fields") Object.entries(v).forEach(([fk, fv]) => fd.append("fields[" + fk + "]", fv));
      else if (Array.isArray(v)) v.forEach((item) => fd.append(k + "[]", item));
      else fd.append(k, v);
    });
    return parse(await fetch(API, { method: "POST", body: fd }));
  };

  function query(name, extra) {
    const s = S[name];
    const p = { entity: name, page: s.page, q: s.q, sort: s.sort, dir: s.dir };
    if (s.chip) p[s.facetKey || ENT[name].chip] = s.chip;
    if (ENT[name].extra && s.extra !== "") p[ENT[name].extra.key] = s.extra;
    if (s.pd) Object.assign(p, s.pd.params()); // time period (audit log)
    return Object.assign(p, extra || {});
  }

  /* ---------- toast ---------- */
  let toastTimer = null;
  function toast(msg, bad) {
    const t = $("mg-toast");
    t.textContent = msg;
    t.dataset.bad = bad ? "1" : "";
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 3500);
  }

  /* ---------- dialog ---------- */
  function openForm({ title, message, fields = [], submit = "Save", danger = false, onSubmit }) {
    const dlg = $("mg-dialog"), form = $("mg-form"), err = $("mg-error"), btn = $("mg-submit");
    $("mg-title").textContent = title;
    const msg = $("mg-msg");
    msg.textContent = message || "";
    msg.style.whiteSpace = "pre-line";
    msg.hidden = !message;
    err.hidden = true;
    btn.textContent = submit;
    btn.className = "adm-btn " + (danger ? "adm-btn--danger" : "adm-btn--primary");

    $("mg-fields").replaceChildren(...fields.map((f) => {
      let input;
      if (f.options) {
        input = h("select", { name: f.name }, f.options.map(([v, l]) => h("option", { value: v }, l)));
      } else {
        input = h("input", { name: f.name, type: f.type || "text", required: !!f.required, autocomplete: f.autocomplete || "off", inputmode: f.inputmode, step: f.step, min: f.min });
      }
      input.value = f.value ?? "";
      return h("label", { class: "adm-field" }, h("span", null, f.label, f.hint ? h("small", null, " " + f.hint) : null), input);
    }));

    form.onsubmit = async (e) => {
      e.preventDefault();
      const values = {};
      fields.forEach((f) => { values[f.name] = form.elements[f.name].value; });
      btn.disabled = true;
      err.hidden = true;
      try { await onSubmit(values); dlg.close(); }
      catch (ex) { err.textContent = ex.message; err.hidden = false; }
      finally { btn.disabled = false; }
    };
    $("mg-cancel").onclick = () => dlg.close();
    dlg.showModal();
    const first = form.querySelector("input,select");
    if (first) first.focus();
  }

  const pwField = { name: "current_password", label: "Confirm with your password", type: "password", required: true, autocomplete: "current-password" };

  /* ---------- row actions ---------- */
  function rowName(name, r) {
    return { users: r.full_name, properties: r.title, bookings: "booking #" + r.id, payments: "payment #" + r.id }[name];
  }

  function applyRow(name, row) {
    const s = S[name];
    const i = s.rows.findIndex((r) => String(r.id) === String(row.id));
    if (i >= 0) s.rows[i] = row;
    s.sig = ""; // force next render
    renderBody(name);
    refresh(name, false); // pick up counts / facets
  }

  async function quick(name, op, r, value, okMsg) {
    S[name].busy++;
    try {
      const d = await post(name, op, r.id, { value });
      applyRow(name, d.row);
      toast(okMsg || "Saved.");
    } catch (e) {
      toast(e.message, true);
      renderBody(name); // puts a select back to its real value
    } finally { S[name].busy--; }
  }

  function actionsFor(name, r) {
    const b = [];
    const btn = (label, fn, cls) => h("button", { type: "button", class: "adm-btn adm-btn--sm " + (cls || ""), onclick: fn }, label);
    const isMe = name === "users" && Number(r.id) === Number(me);

    if (name === "properties") {
      b.push(btn(Number(r.verified) ? "Unverify" : "Verify", () => quick(name, "set_verified", r, Number(r.verified) ? "0" : "1", Number(r.verified) ? "Listing unverified." : "Listing verified.")));
      b.push(btn("Schedule", () => showSchedule(r)));
      b.push(btn("Edit", () => editProperty(r)));
    }
    if (name === "users") {
      b.push(btn(Number(r.verified) ? "Unverify" : "Verify", () => quick(name, "set_verified", r, Number(r.verified) ? "0" : "1", "Email status updated.")));
      b.push(btn("Edit", () => editUser(r)));
      if (!isMe) b.push(btn(r.role === "admin" ? "Make user" : "Make admin", () => changeRole(r)));
    }
    if (!isMe) b.push(btn("Delete", () => remove(name, r), "adm-btn--danger"));
    return h("div", { class: "adm-row-actions" }, b);
  }

  function editProperty(r) {
    openForm({
      title: "Edit property", submit: "Save changes",
      fields: [
        { name: "title", label: "Title", value: r.title, required: true },
        { name: "street_address", label: "Street address", value: r.street_address, required: true },
        { name: "price", label: "Price", value: r.price, type: "number", step: "0.01", min: "0", required: true },
        { name: "price_unit", label: "Price per", value: r.price_unit, options: [["monthly", "Month"], ["daily", "Day"]] },
        { name: "bedrooms", label: "Bedrooms", value: r.bedrooms, type: "number", min: "0" },
        { name: "bathrooms", label: "Bathrooms", value: r.bathrooms, type: "number", min: "0" },
        { name: "slots", label: "Available slots", hint: "(renters who can book at the same time)", value: r.slots, type: "number", min: "1" },
      ],
      onSubmit: async (v) => { const d = await post("properties", "edit", r.id, { fields: v }); applyRow("properties", d.row); toast("Property updated."); },
    });
  }

  const rangeText = (from, to) => (to ? (from === to ? day(from) : day(from) + " → " + day(to)) : "From " + day(from) + " onwards");

  async function showSchedule(r) {
    let d;
    try { d = await post("properties", "schedule", r.id); } catch (e) { toast(e.message, true); return; }
    const lines = d.schedule.length
      ? d.schedule.map((s) => "• " + rangeText(s.from, s.to) + "  —  " + (s.kind === "block" ? "Blocked by owner" + (s.note ? " (" + s.note + ")" : "") : cap(s.status) + " booking" + (s.guest ? " · " + s.guest : "")))
      : ["No taken dates."];
    openForm({
      title: r.title + ": taken schedules",
      message: (d.slots > 1 ? d.slots + " slots · " + d.slots_free + " free today\n\n" : "Single slot\n\n") + lines.join("\n"),
      submit: "Close",
      onSubmit: async () => {},
    });
  }

  function editUser(r) {
    openForm({
      title: "Edit user", submit: "Save changes",
      fields: [
        { name: "full_name", label: "Full name", value: r.full_name, required: true },
        { name: "email", label: "Email", value: r.email, type: "email", required: true },
        { name: "new_password", label: "New password", hint: "(leave blank to keep the current one)", type: "password", autocomplete: "new-password" },
        pwField,
      ],
      onSubmit: async (v) => {
        const { current_password, new_password, ...fields } = v;
        const d = await post("users", "edit", r.id, { fields, new_password, current_password });
        applyRow("users", d.row); toast("User updated.");
      },
    });
  }

  function changeRole(r) {
    const to = r.role === "admin" ? "user" : "admin";
    openForm({
      title: "Make " + r.full_name + " " + (to === "admin" ? "an admin" : "a regular user") + "?",
      message: to === "admin" ? "Admins can see and change everything in this panel." : "They will lose access to this panel.",
      fields: [pwField], submit: "Change role", danger: to === "user",
      onSubmit: async (v) => { const d = await post("users", "set_role", r.id, { value: to, current_password: v.current_password }); applyRow("users", d.row); toast("Role changed."); },
    });
  }

  function remove(name, r) {
    openForm({
      title: "Delete " + rowName(name, r) + "?",
      message: "This can't be undone." + (name === "properties" ? " Its photos, amenities and favourites are removed too." : ""),
      fields: [pwField], submit: "Delete", danger: true,
      onSubmit: async (v) => { await post(name, "delete", r.id, { current_password: v.current_password }); toast("Deleted."); S[name].sig = ""; await refresh(name, false); },
    });
  }

/* ---------- multi-select + bulk actions (not for the read-only audit log) ---------- */
  const BULK_MAX = 1000;
  const selectable = (name) => !ENT[name].readonly;

  function updateBulkBar(name) {
    const s = S[name], el = s.el;
    if (!el.bulk) return;
    const n = s.sel.size;
    el.bulk.hidden = n === 0;
    el.bulkCount.textContent = n + " selected";
    const pageIds = s.rows.map((r) => String(r.id));
    const pageAll = pageIds.length > 0 && pageIds.every((id) => s.sel.has(id));
    // offer "select all N" when more records match the filter than are selected
    el.bulkAll.hidden = !(s.total > n && s.total > pageIds.length);
    el.bulkAll.textContent = "Select all " + Math.min(s.total, BULK_MAX).toLocaleString() + " matching" + (s.total > BULK_MAX ? " (max " + BULK_MAX.toLocaleString() + ")" : "");
    if (el.checkAll) {
      el.checkAll.checked = pageAll;
      el.checkAll.indeterminate = !pageAll && pageIds.some((id) => s.sel.has(id));
    }
  }

  function setSelected(name, id, on) {
    const s = S[name];
    if (on) s.sel.add(String(id)); else s.sel.delete(String(id));
    updateBulkBar(name);
  }

  function togglePage(name, on) {
    const s = S[name];
    s.rows.forEach((r) => { if (on) s.sel.add(String(r.id)); else s.sel.delete(String(r.id)); });
    s.el.table.querySelectorAll("tbody .mg-check").forEach((c) => { c.checked = on; c.closest("tr").classList.toggle("is-selected", on); });
    updateBulkBar(name);
  }

  async function selectAllMatching(name) {
    const s = S[name];
    s.el.bulkAll.disabled = true;
    try {
      const d = await fetchAll(name);
      d.rows.slice(0, BULK_MAX).forEach((r) => s.sel.add(String(r.id)));
      if (d.total > BULK_MAX) toast("Selected the first " + BULK_MAX.toLocaleString() + " of " + d.total.toLocaleString() + " records.");
      s.el.table.querySelectorAll("tbody tr[data-id]").forEach((tr) => {
        const on = s.sel.has(tr.dataset.id);
        tr.classList.toggle("is-selected", on);
        const c = tr.querySelector(".mg-check"); if (c) c.checked = on;
      });
      updateBulkBar(name);
    } catch (e) { toast(e.message, true); }
    finally { s.el.bulkAll.disabled = false; }
  }

  function clearSelection(name) {
    const s = S[name];
    s.sel.clear();
    s.sig = "";
    renderBody(name);
  }

  const plural = (name, n) => n + " " + (name === "properties" ? (n === 1 ? "property" : "properties") : name.slice(0, -1) + (n === 1 ? "" : "s"));
  const keepOpt = ["", "— No change —"];

  function bulkEdit(name) {
    const s = S[name], ids = [...s.sel];
    if (!ids.length) return;
    const statusOpts = [keepOpt].concat((STATUS[name] || []).map((v) => [v, cap(v)]));
    const fields = [];
    if (STATUS[name]) fields.push({ name: "status", label: "Status", options: statusOpts });
    if (name === "properties") fields.push({ name: "verified", label: "Verification", options: [keepOpt, ["1", "Verified"], ["0", "Awaiting verification"]] });
    if (name === "users") {
      fields.push({ name: "verified", label: "Email verification", options: [keepOpt, ["1", "Email verified"], ["0", "Not verified"]] });
      fields.push({ name: "role", label: "Role", options: [keepOpt, ["user", "Regular user"], ["admin", "Admin"]] });
      fields.push({ ...pwField, required: false, label: "Your password", hint: "(only needed when changing roles)" });
    }
    openForm({
      title: "Edit " + plural(name, ids.length),
      message: "Only the fields you change are applied to every selected record.",
      fields, submit: "Apply to " + ids.length,
      onSubmit: async (v) => {
        const { current_password, ...rest } = v;
        const f = Object.fromEntries(Object.entries(rest).filter(([, x]) => x !== ""));
        if (!Object.keys(f).length) throw new Error("Choose at least one change.");
        if (f.role && !current_password) throw new Error("Enter your password to change roles.");
        const d = await post(name, "bulk_edit", "", { ids, fields: f, current_password: current_password || "" });
        toast(d.message);
        s.sel.clear(); s.sig = ""; await refresh(name, false);
      },
    });
  }

  function bulkDelete(name) {
    const s = S[name], ids = [...s.sel];
    if (!ids.length) return;
    openForm({
      title: "Delete " + plural(name, ids.length) + "?",
      message: "This can't be undone." + (name === "properties" ? " Their photos, amenities and favourites are removed too." : "") + (name === "users" ? " Your own account is always skipped." : "") + " Records that other data still depends on are skipped.",
      fields: [pwField], submit: "Delete " + ids.length, danger: true,
      onSubmit: async (v) => {
        const d = await post(name, "bulk_delete", "", { ids, current_password: v.current_password });
        toast(d.message, d.skipped > 0);
        s.sel.clear(); s.sig = ""; await refresh(name, false);
      },
    });
  }

  /* ---------- rendering ---------- */
  function statusSelect(name, r) {
    const sel = h("select", { class: "mg-status", "data-v": r.status, "aria-label": "Status" }, STATUS[name].map((v) => h("option", { value: v }, cap(v))));
    sel.value = r.status;
    sel.addEventListener("change", () => { sel.disabled = true; quick(name, "set_status", r, sel.value, "Status set to " + sel.value + ".").finally(() => { sel.disabled = false; }); });
    return sel;
  }

  function renderBody(name) {
    const s = S[name], E = ENT[name], el = s.el;
    el.checkAll = null;
    if (selectable(name)) {
      el.checkAll = h("input", { type: "checkbox", class: "mg-check", "aria-label": "Select all rows on this page", onchange: (e) => togglePage(name, e.target.checked) });
    }
    const thead = h("thead", null, h("tr", null,
      selectable(name) ? h("th", { class: "mg-check-cell" }, el.checkAll) : null,
      E.columns.map((c) => {
        const th = h("th", c.sort ? { class: "is-sortable", tabindex: "0", "aria-sort": s.sort === c.sort ? (s.dir === "asc" ? "ascending" : "descending") : "none" } : null,
          c.label, c.sort && s.sort === c.sort ? h("span", { class: "mg-arrow" }, s.dir === "asc" ? " ▲" : " ▼") : null);
        if (c.sort) {
          const go = () => { s.dir = s.sort === c.sort && s.dir === "desc" ? "asc" : "desc"; s.sort = c.sort; s.page = 1; s.sig = ""; refresh(name, false); };
          th.addEventListener("click", go);
          th.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
        }
        return th;
      }),
      E.readonly ? null : h("th", null, "Actions")));

    const tbody = h("tbody");
    s.rows.forEach((r) => {
      const json = JSON.stringify(r);
      const was = s.prev.get(String(r.id));
      const cls = s.flash && s.loaded ? (was === undefined ? "is-new" : was !== json ? "is-changed" : "") : "";
      const picked = s.sel.has(String(r.id));
      const rowCls = [cls, picked ? "is-selected" : ""].filter(Boolean).join(" ");
      tbody.append(h("tr", { class: rowCls || null, "data-id": String(r.id) },
        selectable(name) ? h("td", { class: "mg-check-cell", "data-label": "Select" }, h("input", {
          type: "checkbox", class: "mg-check", "aria-label": "Select " + rowName(name, r), checked: picked,
          onchange: (e) => { e.target.closest("tr").classList.toggle("is-selected", e.target.checked); setSelected(name, r.id, e.target.checked); },
        })) : null,
        E.columns.map((c) => {
          let content;
          if (c.select) content = statusSelect(name, r);
          else if (c.cell) content = c.cell(r);
          else if (c.key === "status") content = badge(r.status);
          else content = text(c, r);
          const td = h("td", { "data-label": c.label });
          if (c.key === "status" || c.cell || c.select) { td.append(content); }
          else { td.textContent = content; td.title = content; td.className = [c.wide ? "mg-wide" : "", isEmptyCell(c, r) ? "adm-null" : ""].join(" ").trim(); }
          return td;
        }),
        E.readonly ? null : h("td", { class: "mg-actions-cell" }, actionsFor(name, r))));
    });
    if (!s.rows.length) tbody.append(h("tr", null, h("td", { colSpan: E.columns.length + (E.readonly ? 0 : 2), class: "adm-empty" }, s.q || s.chip || s.extra || (s.pd && s.pd.period !== "all") ? "Nothing matches these filters." : "No records yet.")));

    el.table.replaceChildren(thead, tbody);
    s.prev = new Map(s.rows.map((r) => [String(r.id), JSON.stringify(r)]));
    s.flash = false;

    const pages = Math.max(1, Math.ceil(s.total / s.pageSize));
    el.count.textContent = s.total + " record" + (s.total === 1 ? "" : "s");
    el.page.textContent = "Page " + s.page + " of " + pages;
    el.prev.disabled = s.page <= 1;
    el.next.disabled = s.page >= pages;
    updateBulkBar(name);
  }

  function renderChips(name) {
    const s = S[name], el = s.el;
    const entries = Object.entries(s.facets);
    const sum = entries.reduce((a, [, n]) => a + n, 0);
    const mk = (value, label, n) => h("button", { type: "button", class: "mg-chip" + (s.chip === value ? " is-active" : ""), onclick: () => { s.chip = value; s.page = 1; s.sig = ""; refresh(name, false); } }, label, h("small", null, n));
    el.chips.replaceChildren(mk("", "All", sum), ...entries.map(([k, n]) => mk(k, cap(k), n)));
  }

  function setLive(name, state, msg) {
    const pill = S[name].el.live;
    pill.dataset.state = state;
    pill.querySelector("span").textContent = msg;
  }

  function tickAgo() {
    if (!active) return;
    const s = S[active];
    if (s.lastOk && s.el.live.dataset.state === "live") {
      const secs = Math.floor((Date.now() - s.lastOk) / 1000);
      s.el.updated.textContent = "Updated " + (secs < 2 ? "just now" : secs + "s ago");
    }
  }

  /* ---------- load / poll ---------- */
  async function refresh(name, isPoll) {
    const s = S[name];
    const seq = (s.seq = (s.seq || 0) + 1);
    try {
      const d = await get(query(name));
      if (seq !== s.seq) return; // a newer request (e.g. another period) is already on its way
      s.facetKey = d.facet_key;
      // a different search / filter / period means a different list: drop the old selection
      const selKey = JSON.stringify([s.q, s.chip, s.extra, s.pd ? s.pd.params() : null]);
      if (s.selKey !== null && s.selKey !== selKey) s.sel.clear();
      s.selKey = selKey;
      if (d.period && s.pd) { s.periodInfo = d.period; s.pd.setInfo(d.period); }
      me = d.me;
      s.pageSize = d.page_size;
      const sig = JSON.stringify([d.rows, d.total, d.facets, s.page]);
      s.lastOk = Date.now();
      setLive(name, "live", "Live");
      if (sig === s.sig) return;
      s.sig = sig;
      s.rows = d.rows; s.total = d.total; s.facets = d.facets;
      // page ran off the end (e.g. rows deleted elsewhere): step back
      const pages = Math.max(1, Math.ceil(s.total / s.pageSize));
      if (s.page > pages) { s.page = pages; s.sig = ""; return refresh(name, isPoll); }
      s.flash = isPoll;
      renderChips(name);
      renderBody(name);
      s.loaded = true;
    } catch (e) {
      if (locked) return;
      console.error(e);
      setLive(name, "error", "Connection problem");
      if (!isPoll) toast(e.message, true);
    }
  }

  function userIsBusy() {
    if ($("mg-dialog").open) return true;
    const a = document.activeElement;
    if (a && a.tagName === "SELECT") return true;
    return S[active].busy > 0;
  }

  function schedule() {
    clearTimeout(timer);
    if (!active || locked || document.hidden) return;
    timer = setTimeout(async () => {
      if (active && !userIsBusy()) await refresh(active, true);
      schedule();
    }, POLL_MS);
  }

  /* ---------- print + CSV ---------- */
  async function fetchAll(name) {
    const d = await get(query(name, { all: 1, page: 1 }));
    return d;
  }

  function filterSummary(name) {
    const s = S[name], E = ENT[name], parts = [];
    if (s.chip) parts.push(cap(E.chip) + ": " + cap(s.chip));
    if (E.extra && s.extra !== "") parts.push((E.extra.options.find(([v]) => v === s.extra) || [])[1]);
    if (s.q) parts.push("Search: “" + s.q + "”");
    if (s.periodInfo && s.periodInfo.period !== "all") parts.unshift({ day: "Day", week: "Week", year: "Year" }[s.periodInfo.period] + ": " + s.periodInfo.label);
    return parts.length ? parts.join(" · ") : "No filters (all records)";
  }

  async function printSection(name) {
    const E = ENT[name];
    try {
      const d = await fetchAll(name);
      const who = $("adm-who") ? $("adm-who").textContent : "";
      const area = $("adm-print-area");
      area.replaceChildren(
        h("h2", null, "Pahuway Space: " + E.title + " Report"),
        h("p", { class: "mg-print-meta" }, filterSummary(name) + " · " + d.total + " record" + (d.total === 1 ? "" : "s")),
        h("p", { class: "mg-print-meta" }, "Generated " + new Date().toLocaleString("en-PH") + (who ? " · " + who : "")),
        d.capped ? h("p", { class: "mg-print-meta" }, "Only the first 5,000 records are included.") : null,
        h("table", { class: "mg-print-table" },
          h("thead", null, h("tr", null, E.columns.map((c) => h("th", null, c.label)))),
          h("tbody", null, d.rows.map((r) => h("tr", null, E.columns.map((c) => h("td", null, text(c, r))))))));
      document.body.classList.add("is-printing-table");
      window.print();
    } catch (e) { toast(e.message, true); }
  }
  window.addEventListener("afterprint", () => {
    document.body.classList.remove("is-printing-table");
    $("adm-print-area").replaceChildren();
  });

  async function exportCsv(name) {
    const E = ENT[name];
    try {
      const d = await fetchAll(name);
      const esc = (v) => {
        let t = String(v ?? "");
        if (/^[=+\-@\t\r]/.test(t)) t = "'" + t; // stop spreadsheet formula injection
        return /[",\n\r]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
      };
      const lines = [E.columns.map((c) => esc(c.label)).join(",")].concat(d.rows.map((r) => E.columns.map((c) => esc(text(c, r))).join(",")));
      const blob = new Blob(["\ufeff" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
      const a = h("a", { href: URL.createObjectURL(blob), download: name + (S[name].periodInfo && S[name].periodInfo.period !== "all" ? "-" + S[name].periodInfo.period + "-" + (S[name].periodInfo.period === "year" ? S[name].periodInfo.from.slice(0, 4) : S[name].periodInfo.from) : "-" + new Date().toISOString().slice(0, 10)) + ".csv" });
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      toast("Exported " + d.total + " record" + (d.total === 1 ? "" : "s") + ".");
    } catch (e) { toast(e.message, true); }
  }

  /* ---------- build each section's DOM ---------- */
  function build(name) {
    const E = ENT[name], s = S[name], pane = $("pane-" + name);
    if (!pane) return;
    const el = s.el;
    el.live = h("span", { class: "dash-live", "data-state": "connecting" }, h("i"), h("span", null, "Connecting…"));
    el.updated = h("span", { class: "dash-updated" });
    el.chips = h("div", { class: "mg-chips", role: "group", "aria-label": "Filter by " + E.chip });
    el.table = h("table", { class: "adm-table mg-table" });
    el.count = h("span", { class: "adm-count" });
    el.page = h("span");
    el.prev = h("button", { type: "button", class: "adm-btn", onclick: () => { s.page--; s.sig = ""; refresh(name, false); } }, "← Prev");
    el.next = h("button", { type: "button", class: "adm-btn", onclick: () => { s.page++; s.sig = ""; refresh(name, false); } }, "Next →");

    let timerSearch;
    const search = h("input", { type: "search", placeholder: E.search, "aria-label": "Search " + E.title, autocomplete: "off" });
    search.addEventListener("input", () => { clearTimeout(timerSearch); timerSearch = setTimeout(() => { s.q = search.value.trim(); s.page = 1; s.sig = ""; refresh(name, false); }, 250); });

    const tools = [search];
    if (E.extra) {
      const sel = h("select", { class: "mg-extra", "aria-label": "Filter" }, E.extra.options.map(([v, l]) => h("option", { value: v }, l)));
      sel.addEventListener("change", () => { s.extra = sel.value; s.page = 1; s.sig = ""; refresh(name, false); });
      tools.push(sel);
    }
    tools.push(el.count,
      h("button", { type: "button", class: "adm-btn", onclick: () => exportCsv(name) }, "Export CSV"),
      h("button", { type: "button", class: "adm-btn adm-btn--primary", onclick: () => printSection(name) }, "Print"));

    if (selectable(name)) {
      el.bulkCount = h("strong", { class: "mg-bulk__count" });
      el.bulkAll = h("button", { type: "button", class: "adm-btn adm-btn--sm", onclick: () => selectAllMatching(name) });
      el.bulk = h("div", { class: "mg-bulk", role: "region", "aria-label": "Bulk actions", hidden: true },
        el.bulkCount, el.bulkAll,
        h("span", { class: "mg-bulk__spacer" }),
        h("button", { type: "button", class: "adm-btn adm-btn--sm", onclick: () => clearSelection(name) }, "Clear"),
        h("button", { type: "button", class: "adm-btn adm-btn--sm adm-btn--primary", onclick: () => bulkEdit(name) }, "Edit selected"),
        h("button", { type: "button", class: "adm-btn adm-btn--sm adm-btn--danger", onclick: () => bulkDelete(name) }, "Delete selected"));
    }

    let periodBar = null;
    if (E.period) {
      s.pd = AdmPeriod.create({ key: name, onChange: () => { s.page = 1; s.sig = ""; refresh(name, false); } });
      periodBar = h("div", { class: "mg-pd" }, s.pd.el);
    }

    pane.replaceChildren(...[
      h("div", { class: "mg-head" }, h("div", null, h("h2", null, E.title), h("p", { class: "adm-muted" }, E.blurb)), h("div", { class: "dash-status mg-live" }, el.live, el.updated)),
      periodBar,
      el.chips,
      h("div", { class: "adm-toolbar" }, tools),
      el.bulk,
      h("div", { class: "adm-table-wrap" }, el.table),
      h("div", { class: "adm-pager" }, el.prev, el.page, el.next)].filter(Boolean));
    s.pageSize = 20;
  }

  Object.keys(ENT).forEach(build);

  /* ---------- view switching ---------- */
  document.addEventListener("adm:view", (e) => {
    const name = e.detail;
    active = ENT[name] ? name : null;
    clearTimeout(timer);
    if (!active) return;
    const s = S[active];
    s.sig = "";
    refresh(active, false).then(schedule);
  });
  document.addEventListener("visibilitychange", () => { if (active && !document.hidden) { refresh(active, true); } schedule(); });
  setInterval(tickAgo, 1000);
})();
