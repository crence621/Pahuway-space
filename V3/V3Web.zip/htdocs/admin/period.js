/*
 * Period picker shared by the dashboard and the audit log.
 *
 *   const pd = AdmPeriod.create({ key: "dash", onChange: () => reload() });
 *   container.append(pd.el);
 *   pd.params()      -> { period: "week", date: "2026-10-20" }   (date is left out for "the current one")
 *   pd.setInfo(info) -> pass the server's `period` object so the label / today stay in step with the database clock
 *
 * Day / Week / Year / All buttons, ◀ ▶ to step back and forth, a date (or year) box to jump
 * anywhere, and a "Today / This week / This year" shortcut. The last choice is remembered for
 * the browser tab only (sessionStorage; if that is blocked it just starts on "All").
 */
(() => {
  const PERIODS = [["day", "Day"], ["week", "Week"], ["year", "Year"], ["all", "All"]];
  const CURRENT = { day: "Today", week: "This week", year: "This year" };
  const pad = (n) => String(n).padStart(2, "0");
  const fmt = (d) => d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate());
  const parse = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(Date.UTC(y, m - 1, d)); };
  const add = (d, days) => new Date(d.getTime() + days * 86400000);
  const clientToday = () => { const n = new Date(); return n.getFullYear() + "-" + pad(n.getMonth() + 1) + "-" + pad(n.getDate()); };

  /* first and last day (inclusive) of the day / week (Mon-Sun) / year around dateStr */
  function bounds(period, dateStr) {
    const d = parse(dateStr);
    if (period === "week") { const mon = add(d, -((d.getUTCDay() + 6) % 7)); return [mon, add(mon, 6)]; }
    if (period === "year") { const y = d.getUTCFullYear(); return [new Date(Date.UTC(y, 0, 1)), new Date(Date.UTC(y, 11, 31))]; }
    return [d, d];
  }

  function el(tag, props, ...kids) {
    const n = document.createElement(tag);
    Object.entries(props || {}).forEach(([k, v]) => {
      if (v == null || v === false) return;
      if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else if (k === "class") n.className = v;
      else n.setAttribute(k, v === true ? "" : v);
    });
    kids.flat().forEach((c) => { if (c != null) n.append(c.nodeType ? c : document.createTextNode(String(c))); });
    return n;
  }

  function create({ key, onChange }) {
    const store = "adm-period-" + key;
    const st = { period: "all", date: null, today: clientToday(), label: "" };
    try {
      const saved = JSON.parse(sessionStorage.getItem(store) || "null");
      if (saved && PERIODS.some(([p]) => p === saved.period)) {
        st.period = saved.period;
        st.date = /^\d{4}-\d{2}-\d{2}$/.test(saved.date || "") ? saved.date : null;
      }
    } catch (e) { /* storage blocked: start on "All" */ }

    const baseDate = () => st.date || st.today;
    const isCurrent = () => { const [a, b] = bounds(st.period, baseDate()); const t = parse(st.today); return a <= t && t <= b; };

    const btns = PERIODS.map(([p, label]) => el("button", { type: "button", class: "pd-seg", "data-p": p, onclick: () => pick(p) }, label));
    const prev = el("button", { type: "button", class: "adm-btn adm-btn--sm pd-step", "aria-label": "Previous", title: "Previous", onclick: () => step(-1) }, "‹");
    const next = el("button", { type: "button", class: "adm-btn adm-btn--sm pd-step", "aria-label": "Next", title: "Next", onclick: () => step(1) }, "›");
    const dateIn = el("input", { type: "date", class: "pd-input", "aria-label": "Pick a date", min: "2000-01-01" });
    const yearIn = el("input", { type: "number", class: "pd-input pd-input--year", "aria-label": "Pick a year", min: "2000", max: "2100", step: "1" });
    const now = el("button", { type: "button", class: "adm-btn adm-btn--sm pd-now", onclick: () => { st.date = null; commit(); } });
    const label = el("span", { class: "pd-label", "aria-live": "polite" });
    const nav = el("span", { class: "pd-nav" }, prev, dateIn, yearIn, next, now);
    const root = el("div", { class: "pd-bar", role: "group", "aria-label": "Time period" }, el("span", { class: "pd-seggroup" }, btns), nav, label);

    function normalise() {
      if (st.period === "all") { st.date = null; return; }
      if (st.date && st.date > st.today) st.date = st.today;
      if (st.date && isCurrent()) st.date = null;
    }

    function paint() {
      btns.forEach((b) => { const on = b.dataset.p === st.period; b.classList.toggle("is-active", on); b.setAttribute("aria-pressed", on ? "true" : "false"); });
      const all = st.period === "all";
      nav.hidden = all;
      dateIn.hidden = st.period === "year";
      yearIn.hidden = st.period !== "year";
      dateIn.max = st.today;
      dateIn.title = st.period === "week" ? "Pick any day: the whole week (Mon–Sun) is shown" : "Pick a day";
      dateIn.value = baseDate();
      yearIn.max = String(parse(st.today).getUTCFullYear());
      yearIn.value = String(parse(baseDate()).getUTCFullYear());
      if (!all) {
        const cur = isCurrent();
        next.disabled = bounds(st.period, baseDate())[1] >= parse(st.today);
        now.hidden = cur;
        now.textContent = CURRENT[st.period];
        label.textContent = (cur ? CURRENT[st.period] + (st.label ? " · " : "") : "") + st.label;
      } else {
        label.textContent = "Showing everything";
      }
    }

    function commit() {
      normalise();
      try { sessionStorage.setItem(store, JSON.stringify({ period: st.period, date: st.date })); } catch (e) { /* ignore */ }
      st.label = "";
      paint();
      onChange();
    }

    function pick(p) { if (p === st.period) return; st.period = p; commit(); }

    function step(dir) {
      const d = parse(baseDate());
      if (st.period === "day") st.date = fmt(add(d, dir));
      else if (st.period === "week") st.date = fmt(add(d, 7 * dir));
      else st.date = fmt(new Date(Date.UTC(d.getUTCFullYear() + dir, 0, 1)));
      commit();
    }

    dateIn.addEventListener("change", () => { if (dateIn.value) { st.date = dateIn.value; commit(); } else paint(); });
    yearIn.addEventListener("change", () => {
      const y = parseInt(yearIn.value, 10);
      if (y >= 2000 && y <= 2100) { st.date = y + "-01-01"; commit(); } else paint();
    });

    normalise();
    paint();

    return {
      el: root,
      params() {
        const p = { period: st.period };
        if (st.date) p.date = st.date;
        return p;
      },
      /* the server's own description of the range it used */
      setInfo(info) {
        if (!info) return;
        st.today = info.today || st.today;
        st.label = info.label || "";
        paint();
      },
      get period() { return st.period; },
      get date() { return st.date; },
    };
  }

  window.AdmPeriod = { create };
})();
