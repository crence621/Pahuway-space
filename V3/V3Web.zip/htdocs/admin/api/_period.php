<?php
/*
 * Shared "time period" logic for the admin dashboard, the audit log and the
 * report download.
 *
 *   ?period=day|week|year|all      (default: all)
 *   &date=YYYY-MM-DD               any date inside the day / week / year wanted
 *                                  (default: today on the database clock)
 *
 * day  = that calendar day
 * week = Monday..Sunday containing the date
 * year = Jan 1..Dec 31 of the date's year
 * all  = no limit
 *
 * All boundaries are built here from validated numbers, never from raw input,
 * so they are safe to place into SQL. The range is half-open: from <= t < to.
 */

function period_one(mysqli $conn, string $sql, $default = 0)
{
    $res = $conn->query($sql);
    if (!$res) return $default;
    $row = $res->fetch_row();
    return $row && $row[0] !== null ? $row[0] : $default;
}

function period_rows(mysqli $conn, string $sql): array
{
    $res = $conn->query($sql);
    if (!$res) return [];
    return $res->fetch_all(MYSQLI_ASSOC);
}

function period_range(mysqli $conn, ?string $period = null, ?string $date = null): array
{
    $period = $period ?? (string) ($_GET["period"] ?? "all");
    if (!in_array($period, ["day", "week", "year", "all"], true)) $period = "all";

    // Anchor on the database's own "today" so ranges match DATE(created_at).
    $today = (string) period_one($conn, "SELECT CURDATE()", date("Y-m-d"));
    $date = $date ?? (string) ($_GET["date"] ?? "");
    $d = DateTimeImmutable::createFromFormat("!Y-m-d", $date);
    $errs = DateTimeImmutable::getLastErrors();
    if (!$d || ($errs && ($errs["warning_count"] || $errs["error_count"])) || $d->format("Y-m-d") !== $date) {
        $d = new DateTimeImmutable($today);
    }
    $year = (int) $d->format("Y");
    if ($year < 2000 || $year > 2100) $d = new DateTimeImmutable($today);

    $out = ["period" => $period, "today" => $today, "from" => null, "to" => null, "from_date" => null, "to_date" => null, "date" => $d->format("Y-m-d"), "label" => "All time"];

    if ($period === "day") {
        $from = $d;
        $to = $d->modify("+1 day");
        $out["label"] = $from->format("D, j M Y");
    } elseif ($period === "week") {
        $from = $d->modify("-" . ((int) $d->format("N") - 1) . " days"); // Monday
        $to = $from->modify("+7 days");
        $last = $to->modify("-1 day");
        $out["label"] = $from->format("j M") . " – " . $last->format("j M Y");
    } elseif ($period === "year") {
        $from = new DateTimeImmutable($d->format("Y") . "-01-01");
        $to = $from->modify("+1 year");
        $out["label"] = $from->format("Y");
    } else {
        return $out;
    }
    $out["from"] = $from->format("Y-m-d 00:00:00");
    $out["to"] = $to->format("Y-m-d 00:00:00");
    $out["from_date"] = $from->format("Y-m-d");
    $out["to_date"] = $to->modify("-1 day")->format("Y-m-d");
    return $out;
}

/* " AND col >= '..' AND col < '..'" (empty for "all"). $col is a fixed column name from our code. */
function period_and(array $r, string $col): string
{
    if ($r["from"] === null) return "";
    return " AND $col >= '{$r["from"]}' AND $col < '{$r["to"]}'";
}

/* "WHERE ..." / "" variant */
function period_where(array $r, string $col): string
{
    if ($r["from"] === null) return "";
    return "WHERE $col >= '{$r["from"]}' AND $col < '{$r["to"]}'";
}

/* Short, user-facing phrase: "today"-style wording is left to the UI; this is for reports. */
function period_title(array $r): string
{
    return ["day" => "Day", "week" => "Week", "year" => "Year", "all" => "All time"][$r["period"]] . ": " . $r["label"];
}

/* ------------------------------------------------------------ time series */

/*
 * Counts per bucket for the chart. Bucket size follows the period:
 *   day -> 24 hours, week -> 7 days, year -> 12 months, all -> months (last 36 at most).
 * Returns ["unit" => hour|day|month, "buckets" => [["key","label"], ...]] and fills counts per table.
 */
function period_buckets(mysqli $conn, array $r): array
{
    if ($r["period"] === "day") {
        $b = [];
        for ($h = 0; $h < 24; $h++) $b[] = [sprintf("%02d", $h), sprintf("%02d", $h)];
        return ["unit" => "hour", "fmt" => "%H", "from" => $r["from"], "to" => $r["to"], "buckets" => $b];
    }
    if ($r["period"] === "week") {
        $b = [];
        $d = new DateTimeImmutable($r["from_date"]);
        for ($i = 0; $i < 7; $i++) {
            $x = $d->modify("+$i day");
            $b[] = [$x->format("Y-m-d"), $x->format("D j")];
        }
        return ["unit" => "day", "fmt" => "%Y-%m-%d", "from" => $r["from"], "to" => $r["to"], "buckets" => $b];
    }
    if ($r["period"] === "year") {
        $b = [];
        $d = new DateTimeImmutable($r["from_date"]);
        for ($i = 0; $i < 12; $i++) {
            $x = $d->modify("+$i month");
            $b[] = [$x->format("Y-m"), $x->format("M")];
        }
        return ["unit" => "month", "fmt" => "%Y-%m", "from" => $r["from"], "to" => $r["to"], "buckets" => $b];
    }
    // all time: monthly, from the first record (at most 36 months back) to this month
    $end = new DateTimeImmutable(substr($r["today"], 0, 7) . "-01");
    $first = period_one($conn, "SELECT LEAST(
        COALESCE((SELECT MIN(created_at) FROM users), NOW()),
        COALESCE((SELECT MIN(created_at) FROM bookings), NOW()))", null);
    $start = $first ? new DateTimeImmutable(substr((string) $first, 0, 7) . "-01") : $end->modify("-11 months");
    $min = $end->modify("-35 months");
    if ($start < $min) $start = $min;
    $b = [];
    for ($x = $start; $x <= $end; $x = $x->modify("+1 month")) $b[] = [$x->format("Y-m"), $x->format("M y")];
    if (count($b) < 2) array_unshift($b, [$end->modify("-1 month")->format("Y-m"), $end->modify("-1 month")->format("M y")]);
    return ["unit" => "month", "fmt" => "%Y-%m", "from" => $start->format("Y-m-d 00:00:00"), "to" => $end->modify("+1 month")->format("Y-m-d 00:00:00"), "buckets" => $b];
}

function period_series(mysqli $conn, array $spec, string $table): array
{
    $rows = period_rows(
        $conn,
        "SELECT DATE_FORMAT(created_at, '{$spec["fmt"]}') AS k, COUNT(*) AS n
         FROM `$table`
         WHERE created_at >= '{$spec["from"]}' AND created_at < '{$spec["to"]}'
         GROUP BY k"
    );
    $map = [];
    foreach ($rows as $x) $map[$x["k"]] = (int) $x["n"];
    $out = [];
    foreach ($spec["buckets"] as [$key, $label]) $out[] = ["key" => $key, "label" => $label, "count" => $map[$key] ?? 0];
    return $out;
}

/* ------------------------------------------------------------ dashboard data */

function dash_kpis(mysqli $conn, array $r): array
{
    $c = fn(string $t) => (int) period_one($conn, "SELECT COUNT(*) FROM $t");
    // A payment counts on the day it was paid (falls back to when it was created).
    $payDate = "COALESCE(STR_TO_DATE(paid_at, '%Y-%m-%d %H:%i:%s'), created_at)";
    return [
        "users"              => (int) period_one($conn, "SELECT COUNT(*) FROM users WHERE 1=1" . period_and($r, "created_at")),
        "users_verified"     => (int) period_one($conn, "SELECT COUNT(*) FROM users WHERE email_verified = 1" . period_and($r, "created_at")),
        "users_all"          => $c("users"),
        "properties"         => (int) period_one($conn, "SELECT COUNT(*) FROM properties WHERE 1=1" . period_and($r, "created_at")),
        "properties_pending" => (int) period_one($conn, "SELECT COUNT(*) FROM properties WHERE verified = 0" . period_and($r, "created_at")),
        "properties_all"     => $c("properties"),
        "bookings"           => (int) period_one($conn, "SELECT COUNT(*) FROM bookings WHERE 1=1" . period_and($r, "created_at")),
        "bookings_all"       => $c("bookings"),
        "revenue_paid"       => (float) period_one($conn, "SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status = 'paid'" . period_and($r, $payDate), 0),
        "revenue_pending"    => (float) period_one($conn, "SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status = 'pending'" . period_and($r, "created_at"), 0),
        "revenue_all"        => (float) period_one($conn, "SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status = 'paid'", 0),
    ];
}

function dash_activity_sql(array $r): string
{
    $f = fn(string $col) => period_where($r, $col);
    return "SELECT 'user' AS type, user_id AS ref, full_name AS label, created_at AS t FROM users " . $f("created_at") . "
        UNION ALL
        SELECT 'property', property_id, title, created_at FROM properties " . $f("created_at") . "
        UNION ALL
        SELECT 'booking', booking_id, CONCAT('Booking #', booking_id, ' (', booking_status, ')'), created_at FROM bookings " . $f("created_at") . "
        UNION ALL
        SELECT 'payment', payment_id, CONCAT('PHP ', amount, ' (', payment_status, ')'), created_at FROM payments " . $f("created_at");
}

function dash_activity(mysqli $conn, array $r, int $limit): array
{
    $rows = period_rows($conn, "SELECT type, ref, label, UNIX_TIMESTAMP(t) AS ts, t AS at FROM (" . dash_activity_sql($r) . ") x ORDER BY t DESC, ref DESC LIMIT " . (int) $limit);
    foreach ($rows as &$a) {
        $a["ref"] = (int) $a["ref"];
        $a["ts"] = (int) $a["ts"];
    }
    unset($a);
    return $rows;
}

function dash_activity_total(mysqli $conn, array $r): int
{
    return (int) period_one($conn, "SELECT COUNT(*) FROM (" . dash_activity_sql($r) . ") x");
}

function dash_security(mysqli $conn, array $r): array
{
    $n = fn(string $where) => (int) period_one($conn, "SELECT COUNT(*) FROM audit_log WHERE $where" . period_and($r, "created_at"));
    return [
        "failed_logins"      => $n("action = 'login_failed'"),
        "logins"             => $n("action = 'login_success'"),
        "failed_unlocks"     => $n("action IN ('unlock_failed','otp_failed')"),
        "admin_actions"      => $n("category = 'admin'"),
        // snapshots of "right now": they don't depend on the period
        "admin_accounts"     => (int) period_one($conn, "SELECT COUNT(*) FROM users u INNER JOIN roles r ON r.role_id = u.role_id WHERE r.role_name = 'admin'"),
        "unverified_accounts" => (int) period_one($conn, "SELECT COUNT(*) FROM users WHERE email_verified = 0"),
    ];
}

function dash_audit(mysqli $conn, array $r, int $limit): array
{
    $rows = period_rows(
        $conn,
        "SELECT log_id AS id, category, action, actor_name, summary, result, ip, UNIX_TIMESTAMP(created_at) AS ts, created_at AS at
         FROM audit_log " . period_where($r, "created_at") . " ORDER BY log_id DESC LIMIT " . (int) $limit
    );
    foreach ($rows as &$e) {
        $e["id"] = (int) $e["id"];
        $e["ts"] = (int) $e["ts"];
    }
    unset($e);
    return $rows;
}

function dash_audit_total(mysqli $conn, array $r): int
{
    return (int) period_one($conn, "SELECT COUNT(*) FROM audit_log " . period_where($r, "created_at"));
}
