<?php
/*
 * Management API for the admin panel.
 *
 *   GET  ?entity=users|properties|bookings|payments
 *        &page=1 &q=search &sort=col &dir=asc|desc &<filter>=value
 *        &all=1            -> every matching row (for Print / CSV), capped
 *        &period=day|week|year|all &date=YYYY-MM-DD   (audit log only)
 *   POST entity=.. id=.. op=set_status|set_verified|set_role|edit|delete
 *   POST entity=.. ids[]=.. op=bulk_edit|bulk_delete   (many records at once)
 *
 * Rows come back already joined (owner names, property titles...) so the
 * admin never sees raw foreign-key ids. Table/column names come only from
 * the fixed config below; all values are bound. Role changes, user edits
 * and deletes ask for the acting admin's password again.
 */
require_once __DIR__ . "/_bootstrap.php";
require_once __DIR__ . "/_period.php";
require_once __DIR__ . "/../../api/availability_helpers.php"; // slots + taken schedules

const PAGE_SIZE = 20;
const ALL_CAP   = 5000;

/* ------------------------------------------------------------------ config */
$ENTITIES = [
    "users" => [
        "pk"     => "user_id",
        "from"   => "users u INNER JOIN roles r ON r.role_id = u.role_id",
        "select" => "u.user_id AS id, u.account_no, u.full_name, u.email, r.role_name AS role, u.email_verified AS verified,
                     u.created_at,
                     (SELECT COUNT(*) FROM properties p WHERE p.owner_id = u.user_id) AS properties,
                     (SELECT COUNT(*) FROM bookings b WHERE b.user_id = u.user_id) AS bookings",
        "search" => ["u.full_name", "u.email", "u.account_no"],
        "filters" => ["role" => ["expr" => "r.role_name", "values" => ["user", "admin"]],
                      "verified" => ["expr" => "u.email_verified", "values" => ["0", "1"]]],
        "facet"  => ["key" => "role", "expr" => "r.role_name"],
        "sort"   => ["id" => "u.user_id", "account_no" => "u.account_no", "full_name" => "u.full_name", "email" => "u.email", "role" => "r.role_name", "created_at" => "u.created_at"],
        "order"  => "u.user_id DESC",
    ],
    "properties" => [
        "pk"     => "property_id",
        "from"   => "properties p
                     INNER JOIN users o ON o.user_id = p.owner_id
                     INNER JOIN property_types pt ON pt.type_id = p.type_id
                     INNER JOIN cities c ON c.city_id = p.city_id",
        "select" => "p.property_id AS id, p.property_code AS code, p.title, pt.type_name AS type, c.city_name AS city,
                     o.full_name AS owner, p.street_address, p.price, p.price_unit, p.bedrooms, p.bathrooms, p.slots, p.status, p.verified,
                     p.created_at,
                     (SELECT COUNT(*) FROM bookings b WHERE b.property_id = p.property_id) AS bookings,
                     (SELECT COUNT(*) FROM bookings tb WHERE tb.property_id = p.property_id
                         AND tb.booking_status IN ('pending', 'confirmed')
                         AND tb.check_in <= CURDATE()
                         AND (tb.check_out = 'Not checked out' OR tb.check_out > CURDATE())) AS taken_now",
        "search" => ["p.title", "p.property_code", "o.full_name", "c.city_name", "pt.type_name"],
        "filters" => ["status" => ["expr" => "p.status", "values" => ["available", "rented", "inactive"]],
                      "verified" => ["expr" => "p.verified", "values" => ["0", "1"]]],
        "facet"  => ["key" => "status", "expr" => "p.status"],
        "sort"   => ["id" => "p.property_id", "title" => "p.title", "price" => "p.price", "status" => "p.status", "created_at" => "p.created_at", "owner" => "o.full_name"],
        "order"  => "p.property_id DESC",
    ],
    "bookings" => [
        "pk"     => "booking_id",
        "from"   => "bookings b
                     INNER JOIN properties p ON p.property_id = b.property_id
                     INNER JOIN users t ON t.user_id = b.user_id
                     INNER JOIN users o ON o.user_id = p.owner_id",
        "select" => "b.booking_id AS id, p.title AS property, p.property_code AS code, t.full_name AS tenant, t.email AS tenant_email,
                     o.full_name AS owner, b.check_in, b.check_out, b.guests, b.total_amount, b.booking_status AS status,
                     b.created_at,
                     (SELECT x.payment_status FROM payments x WHERE x.booking_id = b.booking_id ORDER BY x.payment_id DESC LIMIT 1) AS payment",
        "search" => ["p.title", "p.property_code", "t.full_name", "t.email", "o.full_name"],
        "filters" => ["status" => ["expr" => "b.booking_status", "values" => ["pending", "confirmed", "cancelled"]]],
        "facet"  => ["key" => "status", "expr" => "b.booking_status"],
        "sort"   => ["id" => "b.booking_id", "check_in" => "b.check_in", "total_amount" => "b.total_amount", "status" => "b.booking_status", "created_at" => "b.created_at", "tenant" => "t.full_name"],
        "order"  => "b.booking_id DESC",
    ],
    "audit" => [
        "pk"     => "log_id",
        "from"   => "audit_log a",
        "select" => "a.log_id AS id, a.created_at, a.actor_name, a.category, a.action, a.target_type, a.target_id, a.summary, a.ip, a.result",
        "search" => ["a.summary", "a.actor_name", "a.action", "a.ip"],
        "filters" => ["category" => ["expr" => "a.category", "values" => ["auth", "security", "admin"]],
                      "result" => ["expr" => "a.result", "values" => ["success", "failure"]]],
        "facet"  => ["key" => "category", "expr" => "a.category"],
        "sort"   => ["id" => "a.log_id", "created_at" => "a.created_at", "actor_name" => "a.actor_name", "action" => "a.action"],
        "order"  => "a.log_id DESC",
        "period" => "a.created_at",
    ],
    "payments" => [
        "pk"     => "payment_id",
        "from"   => "payments y
                     INNER JOIN bookings b ON b.booking_id = y.booking_id
                     INNER JOIN properties p ON p.property_id = b.property_id
                     INNER JOIN users t ON t.user_id = b.user_id
                     INNER JOIN payment_methods m ON m.method_id = y.method_id",
        "select" => "y.payment_id AS id, y.booking_id, p.title AS property, t.full_name AS tenant, m.method_name AS method,
                     y.amount, y.payment_status AS status, y.paid_at, y.created_at",
        "search" => ["p.title", "t.full_name", "m.method_name", "CAST(y.booking_id AS CHAR)"],
        "filters" => ["status" => ["expr" => "y.payment_status", "values" => ["pending", "paid", "failed", "refunded"]]],
        "facet"  => ["key" => "status", "expr" => "y.payment_status"],
        "sort"   => ["id" => "y.payment_id", "amount" => "y.amount", "status" => "y.payment_status", "created_at" => "y.created_at", "tenant" => "t.full_name"],
        "order"  => "y.payment_id DESC",
    ],
];

/* ------------------------------------------------------------------ helpers */
function fail(string $msg, int $code = 400): void
{
    json_out(["success" => false, "message" => $msg], $code);
}

function bind_all(mysqli_stmt $stmt, array $values): void
{
    if ($values) $stmt->bind_param(str_repeat("s", count($values)), ...$values);
}

function run(mysqli $conn, string $sql, array $params = []): mysqli_stmt
{
    $stmt = $conn->prepare($sql);
    if (!$stmt) fail("Database error: " . $conn->error);
    bind_all($stmt, $params);
    if (!$stmt->execute()) {
        $code = $stmt->errno;
        $msg = $stmt->error;
        $stmt->close();
        if ($code === 1451) fail("This record is still referenced by other data (bookings, properties or payments), so it can't be deleted.");
        if ($code === 1062) fail("That value is already in use.");
        fail("Database error: " . $msg);
    }
    return $stmt;
}

function confirm_password(mysqli $conn, int $admin_id): void
{
    $pw = $_POST["current_password"] ?? "";
    $stmt = run($conn, "SELECT password FROM users WHERE user_id = ? LIMIT 1", [$admin_id]);
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($pw === "" || !$row || !password_verify($pw, $row["password"])) {
        fail("Incorrect password.", 403);
    }
}

function load_row(mysqli $conn, array $cfg, int $id): ?array
{
    $stmt = run($conn, "SELECT {$cfg["select"]} FROM {$cfg["from"]} WHERE {$cfg["idexpr"]} = ? LIMIT 1", [$id]);
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

/* ------------------------------------------------------------------ list */
$entity = $_REQUEST["entity"] ?? "";
if (!isset($ENTITIES[$entity])) fail("Unknown section.");
$cfg = $ENTITIES[$entity];
// the select aliases the primary key as "id"; this is its real column
$cfg["idexpr"] = trim(explode(" AS id", $cfg["select"])[0]);

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $where = [];
    $params = [];

    $q = trim($_GET["q"] ?? "");
    if ($q !== "") {
        $like = "%" . addcslashes($q, "%_\\") . "%";
        $ors = [];
        foreach ($cfg["search"] as $expr) { $ors[] = "$expr LIKE ?"; $params[] = $like; }
        $where[] = "(" . implode(" OR ", $ors) . ")";
    }
    foreach ($cfg["filters"] as $name => $f) {
        $v = (string) ($_GET[$name] ?? "");
        if ($v !== "" && in_array($v, $f["values"], true)) {
            $where[] = "{$f["expr"]} = ?";
            $params[] = $v;
        }
    }
    // optional time window (audit log); bounds come pre-validated from _period.php
    $pr = null;
    if (!empty($cfg["period"])) {
        $pr = period_range($conn);
        if ($pr["from"] !== null) {
            $where[] = "{$cfg["period"]} >= ? AND {$cfg["period"]} < ?";
            $params[] = $pr["from"];
            $params[] = $pr["to"];
        }
    }
    $whereSql = $where ? "WHERE " . implode(" AND ", $where) : "";

    $order = $cfg["order"];
    $sort = $_GET["sort"] ?? "";
    if ($sort !== "" && isset($cfg["sort"][$sort])) {
        $dir = (($_GET["dir"] ?? "") === "asc") ? "ASC" : "DESC";
        $order = $cfg["sort"][$sort] . " $dir, " . $cfg["order"];
    }

    $stmt = run($conn, "SELECT COUNT(*) FROM {$cfg["from"]} $whereSql", $params);
    $total = (int) $stmt->get_result()->fetch_row()[0];
    $stmt->close();

    $all = !empty($_GET["all"]);
    $page = max(1, (int) ($_GET["page"] ?? 1));
    $limit = $all ? ALL_CAP : PAGE_SIZE;
    $offset = $all ? 0 : ($page - 1) * PAGE_SIZE;

    $stmt = run($conn, "SELECT {$cfg["select"]} FROM {$cfg["from"]} $whereSql ORDER BY $order LIMIT $limit OFFSET $offset", $params);
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // status/role counts for the filter chips (deliberately ignores the current filters)
    $facets = [];
    // (the time window still applies, so chip numbers add up to the log)
    $facetWhere = $pr ? period_where($pr, $cfg["period"]) : "";
    $res = $conn->query("SELECT {$cfg["facet"]["expr"]} AS k, COUNT(*) AS n FROM {$cfg["from"]} $facetWhere GROUP BY {$cfg["facet"]["expr"]}");
    while ($res && ($r = $res->fetch_assoc())) $facets[$r["k"]] = (int) $r["n"];

    json_out([
        "success"   => true,
        "rows"      => $rows,
        "total"     => $total,
        "page"      => $page,
        "page_size" => PAGE_SIZE,
        "capped"    => $all && $total > ALL_CAP,
        "facet_key" => $cfg["facet"]["key"],
        "facets"    => $facets,
        "me"        => $admin_id,
        "period"    => $pr ? ["period" => $pr["period"], "date" => $pr["date"], "label" => $pr["label"], "from" => $pr["from_date"], "to" => $pr["to_date"], "today" => $pr["today"]] : null,
        "server_time" => time(),
    ]);
}

/* ------------------------------------------------------------------ actions */
if ($_SERVER["REQUEST_METHOD"] !== "POST") fail("Invalid request.", 405);
if ($entity === "audit") fail("The audit log is read-only.", 403);

function label_of(string $entity, array $r): string
{
    switch ($entity) {
        case "users":      return "user " . $r["full_name"] . " (#" . $r["id"] . ")";
        case "properties": return "property " . $r["title"] . " (#" . $r["id"] . ")";
        case "bookings":   return "booking #" . $r["id"] . " (" . $r["property"] . ")";
        default:           return "payment #" . $r["id"] . " (booking #" . $r["booking_id"] . ")";
    }
}
function admin_log(mysqli $conn, int $admin_id, string $entity, array $row, string $action, string $summary): void
{
    audit_log($conn, "admin", $action, $summary, ["actor_id" => $admin_id, "target_type" => ["users" => "user", "properties" => "property", "bookings" => "booking", "payments" => "payment"][$entity] ?? $entity, "target_id" => (int) $row["id"]]);
}

$op = $_POST["op"] ?? "";

/* ------------------------------------------------------------------ bulk actions */
const BULK_MAX = 1000;

/* Like run(), but returns false instead of ending the request, so one bad row doesn't stop the rest. */
function run_soft(mysqli $conn, string $sql, array $params = []): bool
{
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    bind_all($stmt, $params);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

if ($op === "bulk_edit" || $op === "bulk_delete") {
    $ids = $_POST["ids"] ?? [];
    if (!is_array($ids)) $ids = [];
    $ids = array_values(array_unique(array_filter(array_map("intval", $ids), fn($i) => $i > 0)));
    if (!$ids) fail("Select at least one record.");
    if (count($ids) > BULK_MAX) fail("Select " . BULK_MAX . " records or fewer at a time.");
    $noun = ["users" => "user", "properties" => "propert", "bookings" => "booking", "payments" => "payment"][$entity];
    $plural = fn(int $n) => $n . " " . ($entity === "properties" ? ($n === 1 ? "property" : "properties") : $noun . ($n === 1 ? "" : "s"));
    $done = 0;
    $skipped = 0;
    $why = [];

    if ($op === "bulk_delete") {
        confirm_password($conn, $admin_id);
        if ($entity === "properties") require_once __DIR__ . "/../../api/property_helpers.php";
        foreach ($ids as $rid) {
            $r = load_row($conn, $cfg, $rid);
            if (!$r) { $skipped++; $why["no longer exists"] = true; continue; }
            if ($entity === "users" && $rid === $admin_id) { $skipped++; $why["your own account can't be deleted"] = true; continue; }
            $ok = false;
            if ($entity === "properties") {
                $stmt = run($conn, "SELECT image_path FROM property_images WHERE property_id = ?", [$rid]);
                $paths = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), "image_path");
                $stmt->close();
                $ok = run_soft($conn, "DELETE FROM properties WHERE property_id = ? LIMIT 1", [$rid]);
                if ($ok) foreach ($paths as $pth) delete_uploaded_image($pth);
            } else {
                $pk = ["users" => ["users", "user_id"], "bookings" => ["bookings", "booking_id"], "payments" => ["payments", "payment_id"]][$entity];
                $ok = run_soft($conn, "DELETE FROM `{$pk[0]}` WHERE `{$pk[1]}` = ? LIMIT 1", [$rid]);
            }
            if ($ok) {
                $done++;
                admin_log($conn, $admin_id, $entity, $r, "delete", "Deleted " . label_of($entity, $r) . " (bulk delete)");
            } else {
                $skipped++;
                $why["still referenced by other data"] = true;
            }
        }
        if ($done === 0) fail("Nothing was deleted: " . implode("; ", array_keys($why)) . ".");
        $msg = "Deleted " . $plural($done) . "." . ($skipped ? " Skipped $skipped (" . implode("; ", array_keys($why)) . ")." : "");
        json_out(["success" => true, "message" => $msg, "done" => $done, "skipped" => $skipped]);
    }

    /* bulk_edit: status / verified / role on every selected record */
    $f = $_POST["fields"] ?? [];
    if (!is_array($f)) $f = [];
    $status = (string) ($f["status"] ?? "");
    $verified = (string) ($f["verified"] ?? "");
    $role = (string) ($f["role"] ?? "");

    if ($status !== "") {
        if (!isset($cfg["filters"]["status"]) || !in_array($status, $cfg["filters"]["status"]["values"], true)) fail("Invalid status.");
    }
    if ($verified !== "") {
        if (!in_array($entity, ["properties", "users"], true) || !in_array($verified, ["0", "1"], true)) fail("Invalid verification value.");
    }
    if ($role !== "") {
        if ($entity !== "users" || !in_array($role, ["user", "admin"], true)) fail("Invalid role.");
        confirm_password($conn, $admin_id);
    }
    if ($status === "" && $verified === "" && $role === "") fail("Choose at least one change to apply.");

    $statusMap = [
        "properties" => ["properties", "status", "property_id"],
        "bookings"   => ["bookings", "booking_status", "booking_id"],
        "payments"   => ["payments", "payment_status", "payment_id"],
    ];

    foreach ($ids as $rid) {
        $r = load_row($conn, $cfg, $rid);
        if (!$r) { $skipped++; $why["no longer exists"] = true; continue; }
        $changes = [];
        $ok = true;

        if ($status !== "" && isset($statusMap[$entity]) && (string) $r["status"] !== $status) {
            [$tb, $col, $pk] = $statusMap[$entity];
            if ($entity === "payments") {
                $paidAt = $status === "paid" ? date("Y-m-d H:i:s") : "Not paid";
                $ok = run_soft($conn, "UPDATE payments SET payment_status = ?, paid_at = ? WHERE payment_id = ? LIMIT 1", [$status, $paidAt, $rid]);
            } else {
                $ok = run_soft($conn, "UPDATE `$tb` SET `$col` = ? WHERE `$pk` = ? LIMIT 1", [$status, $rid]);
            }
            if ($ok && $entity === "bookings" && $status === "confirmed") {
                // same as single edit: a confirmed booking gets a pending payment record
                $stmt = run($conn, "SELECT 1 FROM payments WHERE booking_id = ? LIMIT 1", [$rid]);
                $has = $stmt->get_result()->num_rows > 0;
                $stmt->close();
                if (!$has) {
                    run_soft($conn, "INSERT INTO payments (booking_id, method_id, amount, payment_status)
                                     VALUES (?, (SELECT method_id FROM payment_methods WHERE method_name = 'Pending'), ?, 'pending')",
                             [$rid, (string) $r["total_amount"]]);
                }
            }
            if ($ok) $changes[] = "status " . $r["status"] . " → " . $status;
        }

        if ($ok && $verified !== "" && (string) $r["verified"] !== $verified) {
            if ($entity === "properties") $ok = run_soft($conn, "UPDATE properties SET verified = ? WHERE property_id = ? LIMIT 1", [$verified, $rid]);
            else $ok = run_soft($conn, "UPDATE users SET email_verified = ? WHERE user_id = ? LIMIT 1", [$verified, $rid]);
            if ($ok) $changes[] = $verified === "1" ? "verified" : "unverified";
        }

        if ($ok && $role !== "" && (string) $r["role"] !== $role) {
            if ($rid === $admin_id && $role !== "admin") {
                $skipped++;
                $why["you can't remove your own admin access"] = true;
                continue;
            }
            $ok = run_soft($conn, "UPDATE users SET role_id = (SELECT role_id FROM roles WHERE role_name = ?) WHERE user_id = ? LIMIT 1", [$role, $rid]);
            if ($ok) $changes[] = "role " . $r["role"] . " → " . $role;
        }

        if (!$ok) { $skipped++; $why["database error"] = true; continue; }
        $done++;
        if ($changes) admin_log($conn, $admin_id, $entity, $r, "bulk_edit", "Bulk edit of " . label_of($entity, $r) . ": " . implode(", ", $changes));
    }
    if ($done === 0) fail("Nothing was changed" . ($why ? ": " . implode("; ", array_keys($why)) : "") . ".");
    $msg = "Updated " . $plural($done) . "." . ($skipped ? " Skipped $skipped (" . implode("; ", array_keys($why)) . ")." : "");
    json_out(["success" => true, "message" => $msg, "done" => $done, "skipped" => $skipped]);
}

$id = (int) ($_POST["id"] ?? 0);
if ($id <= 0) fail("Missing record.");
$row = load_row($conn, $cfg, $id);
if (!$row) fail("That record no longer exists.", 404);

/* schedule: every taken date range of a property (bookings + owner blocks) */
if ($op === "schedule") {
    if ($entity !== "properties") fail("Not supported here.");
    $rows = [["property_id" => $id, "slots" => $row["slots"]]];
    attach_availability($conn, $rows, true);
    json_out(["success" => true, "slots" => $rows[0]["slots"], "slots_free" => $rows[0]["slots_free"], "schedule" => $rows[0]["schedule"], "taken" => $rows[0]["taken"]]);
}

/* set_status: properties.status, bookings.booking_status, payments.payment_status */
if ($op === "set_status") {
    $value = (string) ($_POST["value"] ?? "");
    $map = [
        "properties" => ["table" => "properties", "col" => "status", "pk" => "property_id"],
        "bookings"   => ["table" => "bookings", "col" => "booking_status", "pk" => "booking_id"],
        "payments"   => ["table" => "payments", "col" => "payment_status", "pk" => "payment_id"],
    ];
    if (!isset($map[$entity]) || !in_array($value, $cfg["filters"]["status"]["values"], true)) fail("Invalid status.");
    $m = $map[$entity];

    if ($entity === "payments") {
        // paid_at holds a timestamp string, or the text 'Not paid'
        $paidAt = $value === "paid" ? date("Y-m-d H:i:s") : "Not paid";
        run($conn, "UPDATE payments SET payment_status = ?, paid_at = ? WHERE payment_id = ? LIMIT 1", [$value, $paidAt, $id])->close();
    } else {
        run($conn, "UPDATE `{$m["table"]}` SET `{$m["col"]}` = ? WHERE `{$m["pk"]}` = ? LIMIT 1", [$value, $id])->close();
    }

    // Same rule as the owner flow: confirmed booking -> pending payment record.
    if ($entity === "bookings" && $value === "confirmed") {
        $stmt = run($conn, "SELECT 1 FROM payments WHERE booking_id = ? LIMIT 1", [$id]);
        $has = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if (!$has) {
            run(
                $conn,
                "INSERT INTO payments (booking_id, method_id, amount, payment_status)
                 VALUES (?, (SELECT method_id FROM payment_methods WHERE method_name = 'Pending'), ?, 'pending')",
                [$id, (string) $row["total_amount"]]
            )->close();
        }
    }
    admin_log($conn, $admin_id, $entity, $row, "status_change", "Changed status of " . label_of($entity, $row) . ": " . $row["status"] . " → " . $value);
    json_out(["success" => true, "message" => "Status updated.", "row" => load_row($conn, $cfg, $id)]);
}

/* set_verified: properties.verified, users.email_verified */
if ($op === "set_verified") {
    $v = ((string) ($_POST["value"] ?? "")) === "1" ? "1" : "0";
    if ($entity === "properties") run($conn, "UPDATE properties SET verified = ? WHERE property_id = ? LIMIT 1", [$v, $id])->close();
    elseif ($entity === "users") run($conn, "UPDATE users SET email_verified = ? WHERE user_id = ? LIMIT 1", [$v, $id])->close();
    else fail("Not supported here.");
    admin_log($conn, $admin_id, $entity, $row, "verify_change", ($v === "1" ? "Verified " : "Unverified ") . label_of($entity, $row));
    json_out(["success" => true, "message" => "Updated.", "row" => load_row($conn, $cfg, $id)]);
}

/* set_role: users only, password required */
if ($op === "set_role") {
    if ($entity !== "users") fail("Not supported here.");
    confirm_password($conn, $admin_id);
    $role = (string) ($_POST["value"] ?? "");
    if (!in_array($role, ["user", "admin"], true)) fail("Invalid role.");
    if ($id === $admin_id && $role !== "admin") fail("You can't remove your own admin access.");
    run($conn, "UPDATE users SET role_id = (SELECT role_id FROM roles WHERE role_name = ?) WHERE user_id = ? LIMIT 1", [$role, $id])->close();
    admin_log($conn, $admin_id, $entity, $row, "role_change", "Changed role of " . label_of($entity, $row) . ": " . $row["role"] . " → " . $role);
    json_out(["success" => true, "message" => "Role changed to $role.", "row" => load_row($conn, $cfg, $id)]);
}

/* edit */
if ($op === "edit") {
    $f = $_POST["fields"] ?? [];
    if (!is_array($f)) $f = [];

    if ($entity === "users") {
        confirm_password($conn, $admin_id);
        $name = trim((string) ($f["full_name"] ?? ""));
        $email = trim((string) ($f["email"] ?? ""));
        if ($name === "" || mb_strlen($name) > 150) fail("Enter a name (150 characters max).");
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) fail("Enter a valid email address.");
        $newPw = (string) ($_POST["new_password"] ?? "");
        if ($newPw !== "") {
            if (strlen($newPw) < 8) fail("New password must be at least 8 characters.");
            run($conn, "UPDATE users SET full_name = ?, email = ?, password = ? WHERE user_id = ? LIMIT 1", [$name, $email, password_hash($newPw, PASSWORD_DEFAULT), $id])->close();
        } else {
            run($conn, "UPDATE users SET full_name = ?, email = ? WHERE user_id = ? LIMIT 1", [$name, $email, $id])->close();
        }
    } elseif ($entity === "properties") {
        $title = trim((string) ($f["title"] ?? ""));
        $street = trim((string) ($f["street_address"] ?? ""));
        $unit = (string) ($f["price_unit"] ?? "");
        $price = (string) ($f["price"] ?? "");
        if ($title === "" || mb_strlen($title) > 150) fail("Enter a title (150 characters max).");
        if ($street === "" || mb_strlen($street) > 255) fail("Enter a street address (255 characters max).");
        if (!in_array($unit, ["daily", "monthly"], true)) fail("Invalid price unit.");
        if (!is_numeric($price) || (float) $price < 0 || (float) $price > 99999999) fail("Enter a valid price.");
        $bed = max(0, min(255, (int) ($f["bedrooms"] ?? 0)));
        $bath = max(0, min(255, (int) ($f["bathrooms"] ?? 0)));
        $slots = parse_slots($f["slots"] ?? $row["slots"]);
        if ($slots === null) fail("Slots must be a whole number from 1 to " . MAX_SLOTS . ".");
        $stay_items = load_availability_items($conn, [$id])[$id] ?? [];
        $peak = peak_booking_load($stay_items, date("Y-m-d"));
        if ($slots < $peak) fail("This listing already has $peak overlapping bookings, so it needs at least $peak slots.");
        run(
            $conn,
            "UPDATE properties SET title = ?, street_address = ?, price = ?, price_unit = ?, bedrooms = ?, bathrooms = ?, slots = ? WHERE property_id = ? LIMIT 1",
            [$title, $street, number_format((float) $price, 2, ".", ""), $unit, (string) $bed, (string) $bath, (string) $slots, $id]
        )->close();
    } else {
        fail("Not supported here.");
    }
    $after = load_row($conn, $cfg, $id) ?: $row;
    $changed = [];
    foreach (($entity === "users" ? ["full_name", "email"] : ["title", "street_address", "price", "price_unit", "bedrooms", "bathrooms", "slots"]) as $k) {
        if ((string) ($row[$k] ?? "") !== (string) ($after[$k] ?? "")) $changed[] = $k;
    }
    if ($entity === "users" && (string) ($_POST["new_password"] ?? "") !== "") $changed[] = "password reset";
    admin_log($conn, $admin_id, $entity, $row, "edit", "Edited " . label_of($entity, $row) . ($changed ? " (changed: " . implode(", ", $changed) . ")" : " (no changes)"));
    json_out(["success" => true, "message" => "Changes saved.", "row" => $after]);
}

/* delete */
if ($op === "delete") {
    confirm_password($conn, $admin_id);
    if ($entity === "users" && $id === $admin_id) fail("You can't delete your own account here.");

    if ($entity === "properties") {
        // also delete uploaded image files (rows cascade, files wouldn't)
        require_once __DIR__ . "/../../api/property_helpers.php";
        $stmt = run($conn, "SELECT image_path FROM property_images WHERE property_id = ?", [$id]);
        $paths = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), "image_path");
        $stmt->close();
        run($conn, "DELETE FROM properties WHERE property_id = ? LIMIT 1", [$id])->close();
        foreach ($paths as $p) delete_uploaded_image($p);
    } else {
        $pk = ["users" => ["users", "user_id"], "bookings" => ["bookings", "booking_id"], "payments" => ["payments", "payment_id"]][$entity];
        run($conn, "DELETE FROM `{$pk[0]}` WHERE `{$pk[1]}` = ? LIMIT 1", [$id])->close();
    }
    admin_log($conn, $admin_id, $entity, $row, "delete", "Deleted " . label_of($entity, $row));
    json_out(["success" => true, "message" => "Deleted."]);
}

fail("Unknown action.");
