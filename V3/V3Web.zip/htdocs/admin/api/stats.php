<?php
/*
 * Read-only live stats for the admin dashboard (polled every few seconds).
 *   GET ?period=day|week|year|all &date=YYYY-MM-DD
 *       -> KPIs, chart series, status breakdowns, recent activity and security
 *          numbers for the chosen period (default: all time).
 *
 * The admin gate in _bootstrap.php runs first, so non-admins get 401/403.
 * Period/date are validated and rebuilt in _period.php, never pasted into SQL.
 * Each block fails soft, so one missing table doesn't take the dashboard down.
 */
require_once __DIR__ . "/_bootstrap.php";
require_once __DIR__ . "/_period.php";

header("Cache-Control: no-store");

/* status => count for rows created in the period; every expected status is present (0 if none) */
function breakdown(mysqli $conn, array $r, string $table, string $col, array $expected): array
{
    $out = array_fill_keys($expected, 0);
    foreach (period_rows($conn, "SELECT `$col` AS k, COUNT(*) AS n FROM `$table` " . period_where($r, "created_at") . " GROUP BY `$col`") as $row) {
        $out[$row["k"]] = (int) $row["n"];
    }
    return $out;
}

$r = period_range($conn);
$spec = period_buckets($conn, $r);

json_out([
    "success"     => true,
    "server_time" => time(),
    "period"      => ["period" => $r["period"], "date" => $r["date"], "label" => $r["label"], "from" => $r["from_date"], "to" => $r["to_date"], "today" => $r["today"]],
    "kpis"        => dash_kpis($conn, $r),
    "breakdowns"  => [
        "bookings"   => breakdown($conn, $r, "bookings", "booking_status", ["pending", "confirmed", "cancelled"]),
        "properties" => breakdown($conn, $r, "properties", "status", ["available", "rented", "inactive"]),
        "payments"   => breakdown($conn, $r, "payments", "payment_status", ["pending", "paid", "failed", "refunded"]),
    ],
    "series"      => [
        "unit"     => $spec["unit"],
        "bookings" => period_series($conn, $spec, "bookings"),
        "users"    => period_series($conn, $spec, "users"),
    ],
    "activity"       => dash_activity($conn, $r, 15),
    "activity_total" => dash_activity_total($conn, $r),
    "security"    => [
        "counts"       => dash_security($conn, $r),
        "last_unlock"  => ((int) period_one($conn, "SELECT UNIX_TIMESTAMP(MAX(created_at)) FROM audit_log WHERE action = 'unlock_success'")) ?: null,
        "mfa"          => ADMIN_MFA_ENABLED,
        "recent"       => dash_audit($conn, $r, 10),
        "recent_total" => dash_audit_total($conn, $r),
    ],
]);
