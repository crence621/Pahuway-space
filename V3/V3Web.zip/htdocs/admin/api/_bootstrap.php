<?php
/*
 * Shared bootstrap + admin gate for everything under /admin/api.
 * The account type is ALWAYS read from the database on every request,
 * never from the session or the browser.
 */
session_start();
require_once __DIR__ . "/../../api/db.php";
require_once __DIR__ . "/../../api/audit.php";
require_once __DIR__ . "/../../api/account_helpers.php";
ensure_account_no($conn);

mysqli_report(MYSQLI_REPORT_OFF);
header("Content-Type: application/json");

function json_out(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function require_admin(mysqli $conn): int
{
    if (!isset($_SESSION["user_id"])) {
        json_out(["success" => false, "message" => "You must be logged in."], 401);
    }

    $id = (int) $_SESSION["user_id"];
    $stmt = $conn->prepare(
        "SELECT roles.role_name AS account_type
         FROM users
         INNER JOIN roles ON roles.role_id = users.role_id
         WHERE users.user_id = ? LIMIT 1"
    );
    if (!$stmt) {
        json_out(["success" => false, "message" => "Could not check your role. Make sure the normalized database (users.role_id and the roles table) is installed."], 500);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || $row["account_type"] !== "admin") {
        json_out(["success" => false, "message" => "Admin access required."], 403);
    }
    return $id;
}

/*
 * Second gate: being an admin is not enough, the panel must be unlocked with
 * the admin's own password (api/unlock.php). The unlock lives in the session,
 * is tied to this admin's id, and expires after ADMIN_IDLE_SECONDS without
 * real user activity (the page sends a ping when the admin actually uses it;
 * its background auto-refresh does not count).
 */
const ADMIN_IDLE_SECONDS = 900; // 15 minutes

/* Second factor: after the password, a 6-digit code is emailed to the admin.
 * Set to false ONLY if the site's email sending is broken and you are locked out. */
const ADMIN_MFA_ENABLED = true;
const ADMIN_OTP_MINUTES = 3; // emailed sign-in code lifetime

function admin_is_unlocked(int $id): bool
{
    return isset($_SESSION["admin_unlocked_for"], $_SESSION["admin_last_activity"])
        && (int) $_SESSION["admin_unlocked_for"] === $id
        && time() - (int) $_SESSION["admin_last_activity"] <= ADMIN_IDLE_SECONDS;
}

function admin_lock_session(): void
{
    unset($_SESSION["admin_unlocked_for"], $_SESSION["admin_last_activity"], $_SESSION["admin_pw_ok_for"], $_SESSION["admin_pw_ok_at"]);
}

$admin_id = require_admin($conn);
ensure_security_tables($conn);

if (!defined("ADMIN_SKIP_UNLOCK") && !admin_is_unlocked($admin_id)) {
    admin_lock_session();
    json_out(["success" => false, "locked" => true, "message" => "Enter your password to open the admin panel."], 423);
}
