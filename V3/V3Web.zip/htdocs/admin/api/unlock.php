<?php
/*
 * Unlock / lock the admin panel: password + emailed one-time code.
 *
 *   GET                 -> { unlocked, mfa, step: "password"|"code", email_hint }
 *   POST op=unlock      -> password. With MFA on, emails a 6-digit code and returns step "code".
 *   POST op=verify_code -> the emailed code. Unlocks the panel.
 *   POST op=resend      -> new code (60 s cooldown, max 5 per hour)
 *   POST op=ping        -> real user activity; extends the idle timer if unlocked
 *   POST op=lock        -> lock now
 *
 * Protection:
 *   - wrong passwords: 5 failures block further tries for 60 s (per session) + a small delay
 *   - codes: random 6 digits, stored salted + hashed, valid ADMIN_OTP_MINUTES,
 *     single use; 5 wrong tries kill the code and send the admin back to the password step
 *   - every unlock attempt, code email and lock is written to the audit log
 */
define("ADMIN_SKIP_UNLOCK", true);
require_once __DIR__ . "/_bootstrap.php"; // still requires a logged-in admin
require_once __DIR__ . "/../../api/mail.php";

header("Cache-Control: no-store");

const OTP_MAX_TRIES = 5;
const OTP_COOLDOWN = 60;
const OTP_MAX_PER_HOUR = 5;

function mask_email(string $e): string
{
    $at = strrpos($e, "@");
    if ($at === false || $at < 1) return "your email";
    $local = substr($e, 0, $at);
    return substr($local, 0, min(2, strlen($local))) . str_repeat("*", max(2, strlen($local) - 2)) . substr($e, $at);
}

function pw_step_ok(int $id): bool
{
    return isset($_SESSION["admin_pw_ok_for"], $_SESSION["admin_pw_ok_at"])
        && (int) $_SESSION["admin_pw_ok_for"] === $id
        && time() - (int) $_SESSION["admin_pw_ok_at"] <= ADMIN_OTP_MINUTES * 60;
}

function admin_row(mysqli $conn, int $id): ?array
{
    $stmt = $conn->prepare("SELECT full_name, email, password FROM users WHERE user_id = ? LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function do_unlock(mysqli $conn, int $id, string $how): void
{
    session_regenerate_id(true);
    unset($_SESSION["admin_fail_count"], $_SESSION["admin_fail_until"], $_SESSION["admin_pw_ok_for"], $_SESSION["admin_pw_ok_at"]);
    $_SESSION["admin_unlocked_for"] = $id;
    $_SESSION["admin_last_activity"] = time();
    $conn->query("DELETE FROM admin_otp WHERE user_id = " . (int) $id);
    audit_log($conn, "security", "unlock_success", "Admin panel unlocked ($how)", ["actor_id" => $id]);
    json_out(["success" => true, "unlocked" => true]);
}

/* Emails a fresh code. Returns null on success, or an error message. */
function send_admin_otp(mysqli $conn, int $id, array $user): ?string
{
    $stmt = $conn->prepare("SELECT TIMESTAMPDIFF(SECOND, sent_at, NOW()) FROM admin_otp WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_row();
    $stmt->close();
    if ($r && (int) $r[0] < OTP_COOLDOWN) {
        return "Please wait " . (OTP_COOLDOWN - (int) $r[0]) . " seconds before asking for another code.";
    }

    $stmt = $conn->prepare("SELECT COUNT(*) FROM audit_log WHERE action = 'otp_sent' AND actor_id = ? AND created_at >= NOW() - INTERVAL 1 HOUR");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $sent = (int) $stmt->get_result()->fetch_row()[0];
    $stmt->close();
    if ($sent >= OTP_MAX_PER_HOUR) {
        return "Too many codes requested. Try again in a while.";
    }

    $code = str_pad((string) random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $salt = bin2hex(random_bytes(16));
    $hash = hash("sha256", $salt . ":" . $id . ":" . $code);
    $minutes = (int) ADMIN_OTP_MINUTES;

    $stmt = $conn->prepare(
        "REPLACE INTO admin_otp (user_id, salt, code_hash, expires_at, attempts, sent_at)
         VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL {$minutes} MINUTE), 0, NOW())"
    );
    $stmt->bind_param("iss", $id, $salt, $hash);
    $stmt->execute();
    $stmt->close();

    $name = htmlspecialchars((string) $user["full_name"], ENT_QUOTES, "UTF-8");
    $html = "<div style=\"font-family:Arial,sans-serif;max-width:480px;margin:auto;color:#222;line-height:1.5\">"
        . "<p>Hi {$name},</p>"
        . "<p>Someone entered your password to open the Pahuway Space Admin Panel. Use this code to finish signing in:</p>"
        . "<p style=\"font-size:28px;font-weight:bold;letter-spacing:6px;margin:16px 0\">{$code}</p>"
        . "<p style=\"font-size:13px;color:#666\">The code expires in {$minutes} minutes and works once. "
        . "If this wasn't you, change your password now, because someone else knows it.</p>"
        . "<p style=\"font-size:13px;color:#666\">Pahuway Space</p></div>";
    $text = "Hi {$user["full_name"]},\n\nSomeone entered your password to open the Pahuway Space Admin Panel. "
        . "Use this code to finish signing in:\n\n{$code}\n\nThe code expires in {$minutes} minutes and works once. "
        . "If this wasn't you, change your password now, because someone else knows it.\n\nPahuway Space";

    $ok = sendPahuwayEmail((string) $user["email"], (string) $user["full_name"], "Your Pahuway Space admin sign-in code", $html, $text);
    if (!$ok) {
        $conn->query("DELETE FROM admin_otp WHERE user_id = " . (int) $id);
        audit_log($conn, "security", "otp_send_failed", "Could not email the admin sign-in code", ["actor_id" => $id, "result" => "failure"]);
        return "We couldn't email the code. Check the site's email settings (or see ADMIN_MFA_ENABLED in admin/api/_bootstrap.php).";
    }
    audit_log($conn, "security", "otp_sent", "Admin sign-in code emailed", ["actor_id" => $id]);
    return null;
}

/* ------------------------------------------------------------------ GET */
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $unlocked = admin_is_unlocked($admin_id);
    $step = (!$unlocked && ADMIN_MFA_ENABLED && pw_step_ok($admin_id)) ? "code" : "password";
    $hint = "";
    if ($step === "code" && ($u = admin_row($conn, $admin_id))) $hint = mask_email((string) $u["email"]);
    json_out(["success" => true, "unlocked" => $unlocked, "mfa" => ADMIN_MFA_ENABLED, "step" => $step, "email_hint" => $hint, "idle_seconds" => ADMIN_IDLE_SECONDS]);
}
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    json_out(["success" => false, "message" => "Invalid request."], 405);
}

$op = $_POST["op"] ?? "";

/* ------------------------------------------------------------------ lock / ping */
if ($op === "lock") {
    admin_lock_session();
    audit_log($conn, "security", "panel_locked", "Admin panel locked manually", ["actor_id" => $admin_id]);
    json_out(["success" => true, "unlocked" => false]);
}

if ($op === "ping") {
    $ok = admin_is_unlocked($admin_id);
    if ($ok) $_SESSION["admin_last_activity"] = time();
    json_out(["success" => true, "unlocked" => $ok]);
}

/* ------------------------------------------------------------------ step 1: password */
if ($op === "unlock") {
    $until = (int) ($_SESSION["admin_fail_until"] ?? 0);
    if (time() < $until) {
        json_out(["success" => false, "message" => "Too many wrong passwords. Try again in " . ($until - time()) . " seconds."], 429);
    }

    $user = admin_row($conn, $admin_id);
    $pw = (string) ($_POST["password"] ?? "");

    if ($pw === "" || !$user || !password_verify($pw, $user["password"])) {
        usleep(600000);
        $_SESSION["admin_fail_count"] = (int) ($_SESSION["admin_fail_count"] ?? 0) + 1;
        $paused = false;
        if ($_SESSION["admin_fail_count"] >= 5) {
            $_SESSION["admin_fail_count"] = 0;
            $_SESSION["admin_fail_until"] = time() + 60;
            $paused = true;
        }
        audit_log($conn, "security", "unlock_failed", "Wrong password for the admin panel" . ($paused ? " (5 in a row: attempts paused for 60 s)" : ""), ["actor_id" => $admin_id, "result" => "failure"]);
        json_out(["success" => false, "message" => "Incorrect password."], 403);
    }

    if (!ADMIN_MFA_ENABLED) do_unlock($conn, $admin_id, "password only");

    $_SESSION["admin_pw_ok_for"] = $admin_id;
    $_SESSION["admin_pw_ok_at"] = time();
    unset($_SESSION["admin_fail_count"], $_SESSION["admin_fail_until"]);

    $err = send_admin_otp($conn, $admin_id, $user);
    if ($err !== null) {
        // A valid code may already be on its way (cooldown): let the admin continue to the code step.
        $stmt = $conn->prepare("SELECT 1 FROM admin_otp WHERE user_id = ? AND expires_at > NOW() LIMIT 1");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $has = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if (!$has) {
            unset($_SESSION["admin_pw_ok_for"], $_SESSION["admin_pw_ok_at"]);
            json_out(["success" => false, "message" => $err], 500);
        }
    }
    json_out(["success" => true, "unlocked" => false, "step" => "code", "email_hint" => mask_email((string) $user["email"])]);
}

/* ------------------------------------------------------------------ step 2: emailed code */
if ($op === "resend") {
    if (!ADMIN_MFA_ENABLED || !pw_step_ok($admin_id)) {
        json_out(["success" => false, "restart" => true, "message" => "Please enter your password again."], 403);
    }
    $user = admin_row($conn, $admin_id);
    $err = $user ? send_admin_otp($conn, $admin_id, $user) : "Account not found.";
    if ($err !== null) json_out(["success" => false, "message" => $err], 429);
    json_out(["success" => true, "message" => "A new code is on its way.", "email_hint" => mask_email((string) $user["email"])]);
}

if ($op === "verify_code") {
    if (!ADMIN_MFA_ENABLED || !pw_step_ok($admin_id)) {
        json_out(["success" => false, "restart" => true, "message" => "Please enter your password again."], 403);
    }
    $code = preg_replace('/\D/', "", (string) ($_POST["code"] ?? ""));

    $stmt = $conn->prepare("SELECT salt, code_hash, attempts, expires_at > NOW() AS fresh FROM admin_otp WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $restart = function (string $msg) use ($conn, $admin_id) {
        $conn->query("DELETE FROM admin_otp WHERE user_id = " . (int) $admin_id);
        unset($_SESSION["admin_pw_ok_for"], $_SESSION["admin_pw_ok_at"]);
        json_out(["success" => false, "restart" => true, "message" => $msg], 403);
    };

    if (!$row || !(int) $row["fresh"]) $restart("That code has expired. Enter your password to get a new one.");
    if ((int) $row["attempts"] >= OTP_MAX_TRIES) $restart("Too many wrong codes. Enter your password to start again.");

    $good = strlen($code) === 6 && hash_equals($row["code_hash"], hash("sha256", $row["salt"] . ":" . $admin_id . ":" . $code));
    if (!$good) {
        usleep(400000);
        $conn->query("UPDATE admin_otp SET attempts = attempts + 1 WHERE user_id = " . (int) $admin_id);
        $left = OTP_MAX_TRIES - ((int) $row["attempts"] + 1);
        audit_log($conn, "security", "otp_failed", "Wrong sign-in code entered", ["actor_id" => $admin_id, "result" => "failure"]);
        if ($left <= 0) $restart("Too many wrong codes. Enter your password to start again.");
        json_out(["success" => false, "message" => "Incorrect code. " . $left . " attempt" . ($left === 1 ? "" : "s") . " left."], 403);
    }

    do_unlock($conn, $admin_id, "password + email code");
}

json_out(["success" => false, "message" => "Unknown action."], 400);
