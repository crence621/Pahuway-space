<?php
/*
 * Unlock / lock the Owner Panel with the owner's own password (no emailed code).
 *
 *   GET            -> { unlocked, idle_seconds, name }
 *   POST op=unlock -> password
 *   POST op=ping   -> real user activity; extends the idle timer if unlocked
 *   POST op=lock   -> lock now
 *
 * 5 wrong passwords in a row pause further tries for 60 s (per session); every
 * attempt is written to the audit log.
 */
define("OWNER_SKIP_UNLOCK", true);
require_once __DIR__ . "/_bootstrap.php";

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    json_out(["success" => true, "unlocked" => owner_is_unlocked($owner_id), "idle_seconds" => OWNER_IDLE_SECONDS, "name" => $owner["full_name"]]);
}
if ($_SERVER["REQUEST_METHOD"] !== "POST") json_out(["success" => false, "message" => "Invalid request."], 405);

$op = $_POST["op"] ?? "";

if ($op === "lock") {
    owner_lock_session();
    audit_log($conn, "security", "owner_locked", "Owner panel locked manually", ["actor_id" => $owner_id]);
    json_out(["success" => true, "unlocked" => false]);
}

if ($op === "ping") {
    $ok = owner_is_unlocked($owner_id);
    if ($ok) $_SESSION["owner_last_activity"] = time();
    json_out(["success" => true, "unlocked" => $ok]);
}

if ($op === "unlock") {
    $until = (int) ($_SESSION["owner_fail_until"] ?? 0);
    if (time() < $until) {
        json_out(["success" => false, "message" => "Too many wrong passwords. Try again in " . ($until - time()) . " seconds."], 429);
    }

    $pw = (string) ($_POST["password"] ?? "");
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $owner_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($pw === "" || !$row || !password_verify($pw, $row["password"])) {
        usleep(600000);
        $_SESSION["owner_fail_count"] = (int) ($_SESSION["owner_fail_count"] ?? 0) + 1;
        $paused = false;
        if ($_SESSION["owner_fail_count"] >= 5) {
            $_SESSION["owner_fail_count"] = 0;
            $_SESSION["owner_fail_until"] = time() + 60;
            $paused = true;
        }
        audit_log($conn, "security", "owner_unlock_fail", "Wrong password for the owner panel" . ($paused ? " (5 in a row: paused for 60 s)" : ""), ["actor_id" => $owner_id, "result" => "failure"]);
        json_out(["success" => false, "message" => "Incorrect password."], 403);
    }

    session_regenerate_id(true);
    unset($_SESSION["owner_fail_count"], $_SESSION["owner_fail_until"]);
    $_SESSION["owner_unlocked_for"] = $owner_id;
    $_SESSION["owner_last_activity"] = time();
    audit_log($conn, "security", "owner_unlock_ok", "Owner panel unlocked", ["actor_id" => $owner_id]);
    json_out(["success" => true, "unlocked" => true]);
}

json_out(["success" => false, "message" => "Unknown action."], 400);
