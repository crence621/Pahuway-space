<?php
/*
 * Shared bootstrap + gate for everything under /owner/api.
 *
 * Gate 1: a logged-in account that is a property owner (users.member_type = 'owner'
 *         or it already owns at least one property). Read from the database on every
 *         request, never from the session or the browser.
 * Gate 2: the panel must be unlocked with the owner's own password (api/unlock.php).
 *         Password only, no emailed code. The unlock lives in the session, is tied to
 *         this owner's id and expires after OWNER_IDLE_SECONDS without real activity.
 *
 * Every query in the owner panel is limited to properties.owner_id = <this owner>.
 */
session_start();
require_once __DIR__ . "/../../api/db.php";
require_once __DIR__ . "/../../api/audit.php";
require_once __DIR__ . "/../../api/property_helpers.php";
require_once __DIR__ . "/../../api/payment_helpers.php";

mysqli_report(MYSQLI_REPORT_OFF);
header("Content-Type: application/json");
header("Cache-Control: no-store");

const OWNER_IDLE_SECONDS = 900; // 15 minutes

function json_out(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function require_owner(mysqli $conn): array
{
    if (!isset($_SESSION["user_id"])) {
        json_out(["success" => false, "message" => "You must be logged in."], 401);
    }
    $id = (int) $_SESSION["user_id"];
    $stmt = $conn->prepare(
        "SELECT u.user_id, u.full_name, u.email, u.member_type, r.role_name,
                (SELECT COUNT(*) FROM properties p WHERE p.owner_id = u.user_id) AS owned
           FROM users u INNER JOIN roles r ON r.role_id = u.role_id WHERE u.user_id = ? LIMIT 1"
    );
    if (!$stmt) json_out(["success" => false, "message" => "Could not check your account."], 500);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || ($row["role_name"] !== "admin" && $row["member_type"] !== "owner" && (int) $row["owned"] === 0)) {
        json_out(["success" => false, "message" => "The Owner Panel is for property owners only."], 403);
    }
    return $row;
}

function owner_is_unlocked(int $id): bool
{
    return isset($_SESSION["owner_unlocked_for"], $_SESSION["owner_last_activity"])
        && (int) $_SESSION["owner_unlocked_for"] === $id
        && time() - (int) $_SESSION["owner_last_activity"] <= OWNER_IDLE_SECONDS;
}

function owner_lock_session(): void
{
    unset($_SESSION["owner_unlocked_for"], $_SESSION["owner_last_activity"]);
}

$owner = require_owner($conn);
$owner_id = (int) $owner["user_id"];

if (!defined("OWNER_SKIP_UNLOCK")) {
    if (!owner_is_unlocked($owner_id)) {
        owner_lock_session();
        json_out(["success" => false, "locked" => true, "message" => "Enter your password to open the Owner Panel."], 423);
    }
    // Actions the owner takes extend the timer; background refreshes never call this file with "ping".
    if (($_SERVER["REQUEST_METHOD"] ?? "GET") === "POST") $_SESSION["owner_last_activity"] = time();
}
