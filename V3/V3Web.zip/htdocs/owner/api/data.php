<?php
/*
 * Owner Panel data + actions. Everything is scoped to the signed-in owner's own properties.
 *
 *   GET  ?view=overview
 *   GET  ?view=properties|requests|transactions  &page= &q= &status=
 *   POST op=request_status  booking_id, status = confirmed|cancelled   (pending requests only)
 *   POST op=confirm_payment booking_id                                  (proof must be uploaded)
 *   POST op=reject_proof    booking_id                                  (clears proof so the renter can resend)
 *   POST op=property_status property_id, status = available|rented|inactive
 */
require_once __DIR__ . "/_bootstrap.php";

const PAGE_SIZE = 15;

function fail(string $msg, int $code = 400): void
{
    json_out(["success" => false, "message" => $msg], $code);
}

function q_run(mysqli $conn, string $sql, string $types = "", array $params = []): mysqli_stmt
{
    try {
        return db_run($conn, $sql, $types, $params);
    } catch (Throwable $e) {
        error_log("[pahuway] owner panel: " . $e->getMessage());
        fail("Database error. Please try again.", 500);
    }
}

ensure_payment_schema($conn);

/* ------------------------------------------------------------------ actions */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $op = $_POST["op"] ?? "";

    /* the booking must belong to one of THIS owner's properties */
    $own_booking = function (int $booking_id) use ($conn, $owner_id): ?array {
        $stmt = q_run($conn,
            "SELECT b.booking_id, b.booking_status, b.total_amount, p.title
               FROM bookings b INNER JOIN properties p ON p.property_id = b.property_id
              WHERE b.booking_id = ? AND p.owner_id = ? LIMIT 1", "ii", [$booking_id, $owner_id]);
        $r = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $r ?: null;
    };
    $latest_payment = function (int $booking_id) use ($conn): ?array {
        $stmt = q_run($conn,
            "SELECT payment_id, payment_status, proof_image FROM payments WHERE booking_id = ? ORDER BY payment_id DESC LIMIT 1", "i", [$booking_id]);
        $r = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $r ?: null;
    };

    if ($op === "request_status") {
        $bid = (int) ($_POST["booking_id"] ?? 0);
        $status = $_POST["status"] ?? "";
        if ($bid <= 0 || !in_array($status, ["confirmed", "cancelled"], true)) fail("Invalid request or status.");
        $b = $own_booking($bid);
        if (!$b) fail("Request not found for your properties.", 404);
        if ($b["booking_status"] !== "pending") fail("Only pending requests can be updated.");

        q_run($conn, "UPDATE bookings SET booking_status = ? WHERE booking_id = ? AND booking_status = 'pending'", "si", [$status, $bid])->close();
        if ($status === "confirmed" && !$latest_payment($bid)) {
            q_run($conn,
                "INSERT INTO payments (booking_id, method_id, amount, payment_status)
                 VALUES (?, (SELECT method_id FROM payment_methods WHERE method_name = 'Pending'), ?, 'pending')",
                "id", [$bid, (float) $b["total_amount"]])->close();
        }
        audit_log($conn, "admin", "owner_request_" . $status, "Owner " . ($status === "confirmed" ? "approved" : "declined") . " request #$bid ({$b["title"]})", ["actor_id" => $owner_id, "target_type" => "booking", "target_id" => $bid]);
        json_out(["success" => true, "message" => $status === "confirmed" ? "Request approved. The renter can now pay." : "Request declined."]);
    }

    if ($op === "confirm_payment" || $op === "reject_proof") {
        $bid = (int) ($_POST["booking_id"] ?? 0);
        $b = $bid > 0 ? $own_booking($bid) : null;
        if (!$b) fail("Transaction not found for your properties.", 404);
        if ($b["booking_status"] !== "confirmed") fail("Only approved requests have payments.");
        $pay = $latest_payment($bid);
        if (!$pay || $pay["proof_image"] === "") fail("The renter has not uploaded proof of payment yet.");
        if ($pay["payment_status"] === "paid") fail("This payment is already confirmed.");

        if ($op === "confirm_payment") {
            q_run($conn, "UPDATE payments SET payment_status = 'paid', paid_at = ? WHERE payment_id = ?", "si", [date("Y-m-d H:i:s"), (int) $pay["payment_id"]])->close();
            audit_log($conn, "admin", "owner_pay_confirm", "Owner confirmed payment for booking #$bid", ["actor_id" => $owner_id, "target_type" => "payment", "target_id" => (int) $pay["payment_id"]]);
            json_out(["success" => true, "message" => "Payment confirmed."]);
        }

        // reject: remove the screenshot so the renter can upload a new one
        q_run($conn, "UPDATE payments SET proof_image = '' WHERE payment_id = ?", "i", [(int) $pay["payment_id"]])->close();
        $path = (string) $pay["proof_image"];
        if (strpos($path, PROOF_DIR) === 0 && strpos($path, "..") === false) {
            $full = __DIR__ . "/../../" . $path;
            if (is_file($full)) @unlink($full);
        }
        audit_log($conn, "admin", "owner_pay_reject", "Owner rejected payment proof for booking #$bid", ["actor_id" => $owner_id, "target_type" => "payment", "target_id" => (int) $pay["payment_id"]]);
        json_out(["success" => true, "message" => "Proof rejected. The renter can upload a new one."]);
    }

    if ($op === "property_status") {
        $pid = (int) ($_POST["property_id"] ?? 0);
        $status = $_POST["status"] ?? "";
        if ($pid <= 0 || !in_array($status, ["available", "rented", "inactive"], true)) fail("Invalid property or status.");
        $stmt = q_run($conn, "UPDATE properties SET status = ? WHERE property_id = ? AND owner_id = ?", "sii", [$status, $pid, $owner_id]);
        $stmt->close();
        $stmt = q_run($conn, "SELECT 1 FROM properties WHERE property_id = ? AND owner_id = ?", "ii", [$pid, $owner_id]);
        $found = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if (!$found) fail("Property not found.", 404);
        audit_log($conn, "admin", "owner_prop_status", "Owner set property #$pid to $status", ["actor_id" => $owner_id, "target_type" => "property", "target_id" => $pid]);
        json_out(["success" => true, "message" => "Property marked $status."]);
    }

    fail("Unknown action.");
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") fail("Invalid request.", 405);

/* ------------------------------------------------------------------ reads */
$view = $_GET["view"] ?? "overview";

if ($view === "overview") {
    $one = function (string $sql, string $t = "i", array $p = null) use ($conn, $owner_id) {
        $stmt = q_run($conn, $sql, $t, $p ?? [$owner_id]);
        $r = $stmt->get_result()->fetch_row();
        $stmt->close();
        return $r;
    };
    $props = $one("SELECT COUNT(*), SUM(status='available'), SUM(status='rented'), SUM(status='inactive') FROM properties WHERE owner_id = ?");
    $reqs = $one("SELECT COUNT(*), SUM(b.booking_status='pending'), SUM(b.booking_status='confirmed'), SUM(b.booking_status='cancelled')
                    FROM bookings b INNER JOIN properties p ON p.property_id = b.property_id WHERE p.owner_id = ?");
    $money = $one("SELECT COALESCE(SUM(CASE WHEN y.payment_status='paid' THEN y.amount END),0),
                          COALESCE(SUM(CASE WHEN y.payment_status='pending' AND y.proof_image <> '' THEN y.amount END),0),
                          SUM(y.payment_status='pending' AND y.proof_image <> ''),
                          COALESCE(SUM(CASE WHEN y.payment_status='paid' AND y.created_at >= DATE_FORMAT(NOW(), '%Y-%m-01') THEN y.amount END),0)
                     FROM payments y INNER JOIN bookings b ON b.booking_id = y.booking_id
                     INNER JOIN properties p ON p.property_id = b.property_id WHERE p.owner_id = ?");
    $stmt = q_run($conn,
        "SELECT b.booking_id AS id, p.title AS property, t.full_name AS tenant, b.total_amount, b.booking_status AS status, b.created_at
           FROM bookings b INNER JOIN properties p ON p.property_id = b.property_id
           INNER JOIN users t ON t.user_id = b.user_id
          WHERE p.owner_id = ? ORDER BY b.booking_id DESC LIMIT 6", "i", [$owner_id]);
    $recent = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    json_out(["success" => true,
        "owner" => ["name" => $owner["full_name"], "email" => $owner["email"]],
        "properties" => ["total" => (int) $props[0], "available" => (int) $props[1], "rented" => (int) $props[2], "inactive" => (int) $props[3]],
        "requests" => ["total" => (int) $reqs[0], "pending" => (int) $reqs[1], "confirmed" => (int) $reqs[2], "cancelled" => (int) $reqs[3]],
        "money" => ["paid" => (float) $money[0], "to_verify" => (float) $money[1], "to_verify_count" => (int) $money[2], "this_month" => (float) $money[3]],
        "recent" => $recent,
    ]);
}

$VIEWS = [
    "properties" => [
        "from" => "properties p INNER JOIN property_types pt ON pt.type_id = p.type_id INNER JOIN cities c ON c.city_id = p.city_id",
        "select" => "p.property_id AS id, p.property_code AS code, p.title, pt.type_name AS type, c.city_name AS city, p.price, p.price_unit, p.slots, p.status, p.verified,
                     (SELECT COUNT(*) FROM bookings b WHERE b.property_id = p.property_id) AS requests,
                     (SELECT COUNT(*) FROM bookings b WHERE b.property_id = p.property_id AND b.booking_status = 'pending') AS pending",
        "scope" => "p.owner_id = ?",
        "search" => ["p.title", "p.property_code", "c.city_name", "pt.type_name"],
        "status" => ["expr" => "p.status", "values" => ["available", "rented", "inactive"]],
        "order" => "p.property_id DESC",
    ],
    "requests" => [
        "from" => "bookings b INNER JOIN properties p ON p.property_id = b.property_id INNER JOIN users t ON t.user_id = b.user_id",
        "select" => "b.booking_id AS id, p.title AS property, p.property_code AS code, t.full_name AS tenant, t.email AS tenant_email, t.phone AS tenant_phone,
                     b.check_in, b.check_out, b.guests, b.total_amount, b.booking_status AS status, b.created_at,
                     (SELECT x.payment_status FROM payments x WHERE x.booking_id = b.booking_id ORDER BY x.payment_id DESC LIMIT 1) AS payment",
        "scope" => "p.owner_id = ?",
        "search" => ["p.title", "p.property_code", "t.full_name", "t.email"],
        "status" => ["expr" => "b.booking_status", "values" => ["pending", "confirmed", "cancelled"]],
        "order" => "(b.booking_status = 'pending') DESC, b.booking_id DESC",
    ],
    "transactions" => [
        "from" => "payments y INNER JOIN bookings b ON b.booking_id = y.booking_id INNER JOIN properties p ON p.property_id = b.property_id
                   INNER JOIN users t ON t.user_id = b.user_id INNER JOIN payment_methods m ON m.method_id = y.method_id",
        "select" => "y.payment_id AS id, y.booking_id, p.title AS property, t.full_name AS tenant, m.method_name AS method, y.amount,
                     y.payment_status AS status, y.paid_at, y.created_at, y.proof_image AS proof",
        "scope" => "p.owner_id = ?",
        "search" => ["p.title", "t.full_name", "m.method_name", "CAST(y.booking_id AS CHAR)"],
        "status" => ["expr" => "y.payment_status", "values" => ["pending", "paid", "failed", "refunded"]],
        "order" => "(y.payment_status = 'pending' AND y.proof_image <> '') DESC, y.payment_id DESC",
    ],
];
if (!isset($VIEWS[$view])) fail("Unknown section.");
$cfg = $VIEWS[$view];

$where = [$cfg["scope"]];
$types = "i";
$params = [$owner_id];
$q = trim((string) ($_GET["q"] ?? ""));
if ($q !== "") {
    $like = "%" . addcslashes($q, "%_\\") . "%";
    $ors = [];
    foreach ($cfg["search"] as $expr) { $ors[] = "$expr LIKE ?"; $types .= "s"; $params[] = $like; }
    $where[] = "(" . implode(" OR ", $ors) . ")";
}
$st = (string) ($_GET["status"] ?? "");
if ($st !== "" && in_array($st, $cfg["status"]["values"], true)) {
    $where[] = $cfg["status"]["expr"] . " = ?";
    $types .= "s";
    $params[] = $st;
}
$whereSql = "WHERE " . implode(" AND ", $where);

$stmt = q_run($conn, "SELECT COUNT(*) FROM {$cfg["from"]} $whereSql", $types, $params);
$total = (int) $stmt->get_result()->fetch_row()[0];
$stmt->close();

$page = max(1, (int) ($_GET["page"] ?? 1));
$offset = ($page - 1) * PAGE_SIZE;
$stmt = q_run($conn, "SELECT {$cfg["select"]} FROM {$cfg["from"]} $whereSql ORDER BY {$cfg["order"]} LIMIT " . PAGE_SIZE . " OFFSET $offset", $types, $params);
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// chip counts (ignore the search and status filter, scoped to this owner)
$facets = [];
$stmt = q_run($conn, "SELECT {$cfg["status"]["expr"]} AS k, COUNT(*) FROM {$cfg["from"]} WHERE {$cfg["scope"]} GROUP BY {$cfg["status"]["expr"]}", "i", [$owner_id]);
foreach ($stmt->get_result()->fetch_all(MYSQLI_NUM) as $r) $facets[$r[0]] = (int) $r[1];
$stmt->close();

// the proof state for the transactions list / requests list
foreach ($rows as &$r) {
    if (isset($r["check_out"])) $r["check_out"] = checkout_for_api($r["check_out"]);
    if ($view === "transactions") $r["has_proof"] = $r["proof"] !== "";
}
unset($r);

json_out(["success" => true, "rows" => $rows, "total" => $total, "page" => $page, "page_size" => PAGE_SIZE, "facets" => $facets, "status_values" => $cfg["status"]["values"]]);
