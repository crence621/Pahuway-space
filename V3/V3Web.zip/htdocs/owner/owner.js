(() => {
  const API = "api/data.php", UNLOCK = "api/unlock.php";
  const $ = (id) => document.getElementById(id);
  const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const date = (s) => (s ? String(s).slice(0, 10) : "");
  const state = { view: "overview", page: 1, q: "", status: "", data: null };
  let idleTimer = null, lastPing = 0, searchTimer = null;

  /* ---------- helpers ---------- */
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function badge(v) { const b = el("span", "own-badge", v || "—"); b.dataset.v = v; return b; }
  function btn(text, fn, cls) { const b = el("button", "adm-btn adm-btn--sm" + (cls ? " " + cls : ""), text); b.type = "button"; b.addEventListener("click", fn); return b; }
  function toast(msg, bad) {
    const t = $("own-toast"); t.textContent = msg; t.dataset.bad = bad ? "1" : ""; t.hidden = false;
    clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), 3500);
  }

  async function call(url, opts) {
    const res = await fetch(url, opts);
    let d; try { d = await res.json(); } catch { throw new Error("Server returned an unexpected response."); }
    if (res.status === 423) { showLock(); throw new Error(d.message || "Locked."); }
    if (res.status === 401) { location.href = "../login.html"; throw new Error(d.message); }
    if (!d.success) { const e = new Error(d.message || "Request failed."); e.status = res.status; throw e; }
    return d;
  }
  const get = (params) => call(API + "?" + new URLSearchParams(params));
  const post = (body, url) => call(url || API, { method: "POST", body: new URLSearchParams(body) });

  /* ---------- lock screen ---------- */
  function showLock() { $("own-main").hidden = true; $("own-lock").hidden = false; $("own-lock-now").hidden = true; $("own-lock-pw").focus(); }
  function showPanel() { $("own-lock").hidden = true; $("own-main").hidden = false; $("own-lock-now").hidden = false; }

  $("own-lock-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("own-lock-err"); err.hidden = true;
    $("own-lock-btn").disabled = true;
    try {
      await post({ op: "unlock", password: $("own-lock-pw").value }, UNLOCK);
      $("own-lock-pw").value = "";
      showPanel(); go("overview");
    } catch (ex) { err.textContent = ex.message; err.hidden = false; }
    $("own-lock-btn").disabled = false;
  });
  $("own-lock-now").addEventListener("click", async () => { try { await post({ op: "lock" }, UNLOCK); } catch {} showLock(); });

  // Real activity extends the idle timer (at most once a minute).
  ["click", "keydown"].forEach((ev) => document.addEventListener(ev, () => {
    if ($("own-main").hidden || Date.now() - lastPing < 60000) return;
    lastPing = Date.now(); post({ op: "ping" }, UNLOCK).catch(() => {});
  }));

  /* ---------- navigation ---------- */
  document.querySelectorAll(".adm-view-btn").forEach((b) => b.addEventListener("click", () => go(b.dataset.view)));
  document.querySelectorAll("[data-goto]").forEach((b) => b.addEventListener("click", () => go(b.dataset.goto)));

  function go(view) {
    Object.assign(state, { view, page: 1, q: "", status: "" });
    $("own-search").value = "";
    document.querySelectorAll(".adm-view-btn").forEach((b) => b.classList.toggle("is-active", b.dataset.view === view));
    $("own-pane-overview").hidden = view !== "overview";
    $("own-pane-list").hidden = view === "overview";
    view === "overview" ? loadOverview() : loadList();
  }

  /* ---------- overview ---------- */
  async function loadOverview(silent) {
    try {
      const d = await get({ view: "overview" });
      $("own-who").textContent = d.owner.name;
      const k = (n) => document.querySelector('#own-kpis [data-k="' + n + '"]');
      k("props").textContent = d.properties.total;
      k("props_sub").textContent = d.properties.available + " available · " + d.properties.rented + " rented · " + d.properties.inactive + " inactive";
      k("pending").textContent = d.requests.pending;
      k("req_sub").textContent = d.requests.total + " requests in total";
      k("verify").textContent = d.money.to_verify_count;
      k("verify_sub").textContent = d.money.to_verify_count ? peso(d.money.to_verify) + " waiting for your check" : "Nothing waiting";
      k("paid").textContent = peso(d.money.paid);
      k("month_sub").textContent = peso(d.money.this_month) + " this month";
      pills(d.requests.pending, d.money.to_verify_count);

      const ul = $("own-recent");
      ul.replaceChildren();
      if (!d.recent.length) ul.append(el("li", "adm-empty", "No requests for your properties yet."));
      d.recent.forEach((r) => {
        const li = el("li");
        li.append(el("span", "", "#" + r.id + " · " + r.tenant + " → " + r.property + " · " + peso(r.total_amount) + " · " + date(r.created_at) + "  "), badge(r.status));
        ul.append(li);
      });
          live(true);
    } catch (ex) { if (silent) live(false); else if (ex.status !== 423) toast(ex.message, true); }
  }
  function pills(req, tx) {
    const a = $("own-pill-requests"), b = $("own-pill-transactions");
    a.textContent = req; a.hidden = !req; b.textContent = tx; b.hidden = !tx;
  }

  /* ---------- lists ---------- */
  const COLS = {
    properties: [["Code", "code"], ["Property", "title"], ["Type", "type"], ["City", "city"], ["Price", (r) => peso(r.price) + " /" + (r.price_unit === "daily" ? "day" : "mo")], ["Slots", "slots"], ["Requests", (r) => r.requests + (+r.pending ? " (" + r.pending + " pending)" : "")], ["Status", "status", "badge"]],
    requests: [["#", "id"], ["Property", "property"], ["Renter", (r) => r.tenant + " · " + r.tenant_email + (r.tenant_phone ? " · " + r.tenant_phone : "")], ["Check-in", (r) => date(r.check_in)], ["Check-out", (r) => r.check_out || "Open-ended"], ["Guests", "guests"], ["Total", (r) => peso(r.total_amount)], ["Status", "status", "badge"], ["Payment", (r) => r.payment || "—", "badge"]],
    transactions: [["Booking", (r) => "#" + r.booking_id], ["Property", "property"], ["Renter", "tenant"], ["Method", (r) => (r.method === "Pending" ? "Not chosen yet" : r.method)], ["Amount", (r) => peso(r.amount)], ["Status", "status", "badge"], ["Paid at", (r) => (r.status === "paid" ? date(r.paid_at) : "—")], ["Date", (r) => date(r.created_at)]],
  };

  async function loadList(silent) {
    try {
      const v = state.view;
      const d = await get({ view: v, page: state.page, q: state.q, status: state.status });
      if (v !== state.view) return; // owner switched tabs while this was loading
      state.data = d; renderList(); live(true);
    } catch (ex) { if (silent) live(false); else if (ex.status !== 423) toast(ex.message, true); }
  }

  function renderList() {
    const d = state.data, cols = COLS[state.view];
    // status chips
    const chips = $("own-chips"); chips.replaceChildren();
    const total = Object.values(d.facets).reduce((a, b) => a + b, 0);
    [["", "All", total], ...d.status_values.map((s) => [s, s[0].toUpperCase() + s.slice(1), d.facets[s] || 0])].forEach(([v, label, n]) => {
      const c = el("button", "own-chip" + (state.status === v ? " is-active" : ""), label); c.type = "button";
      c.append(el("small", "", n));
      c.addEventListener("click", () => { state.status = v; state.page = 1; loadList(); });
      chips.append(c);
    });
    if (state.view === "requests") pills(d.facets.pending || 0, +($("own-pill-transactions").textContent) || 0);

    // table
    const thead = el("thead"), hr = el("tr");
    cols.forEach((c) => hr.append(el("th", "", c[0]))); hr.append(el("th", "", "Actions")); thead.append(hr);
    const tbody = el("tbody");
    d.rows.forEach((r) => {
      const tr = el("tr");
      cols.forEach(([, f, kind]) => {
        const td = el("td"), v = typeof f === "function" ? f(r) : r[f];
        if (kind === "badge") td.append(badge(String(v))); else { td.textContent = v == null ? "" : String(v); td.title = td.textContent; }
        tr.append(td);
      });
      const act = el("td", "own-actions"), box = el("div");
      actions(r).forEach((b) => box.append(b)); act.append(box); tr.append(act);
      tbody.append(tr);
    });
    if (!d.rows.length) { const tr = el("tr"), td = el("td", "adm-empty", "Nothing here yet."); td.colSpan = cols.length + 1; tr.append(td); tbody.append(tr); }
    $("own-table").replaceChildren(thead, tbody);

    const pages = Math.max(1, Math.ceil(d.total / d.page_size));
    $("own-count").textContent = d.total + " result" + (d.total === 1 ? "" : "s");
    $("own-page").textContent = "Page " + d.page + " of " + pages;
    $("own-prev").disabled = d.page <= 1; $("own-next").disabled = d.page >= pages;
  }

  $("own-prev").addEventListener("click", () => { state.page--; loadList(); });
  $("own-next").addEventListener("click", () => { state.page++; loadList(); });
  $("own-search").addEventListener("input", (e) => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { state.q = e.target.value.trim(); state.page = 1; loadList(); }, 300); });

  /* ---------- row actions ---------- */
  function actions(r) {
    const out = [];
    if (state.view === "requests") {
      if (r.status === "pending") {
        out.push(btn("Approve", () => confirmDialog("Approve request #" + r.id + "?", r.tenant + " will be able to pay for " + r.property + ".", () => act({ op: "request_status", booking_id: r.id, status: "confirmed" }))));
        out.push(btn("Decline", () => confirmDialog("Decline request #" + r.id + "?", "This cannot be undone.", () => act({ op: "request_status", booking_id: r.id, status: "cancelled" })), "adm-btn--danger"));
      }
    } else if (state.view === "transactions") {
      if (r.has_proof) out.push(btn("View proof", () => viewProof(r)));
      if (r.status === "pending" && r.has_proof) out.push(btn("Confirm paid", () => confirmDialog("Confirm payment for booking #" + r.booking_id + "?", "Mark " + peso(r.amount) + " from " + r.tenant + " as received.", () => act({ op: "confirm_payment", booking_id: r.booking_id }))));
    } else if (state.view === "properties") {
      const sel = el("select", "own-select"); sel.setAttribute("aria-label", "Change status of " + r.title);
      ["available", "rented", "inactive"].forEach((s) => { const o = el("option", "", s); o.value = s; o.selected = s === r.status; sel.append(o); });
      sel.addEventListener("change", () => act({ op: "property_status", property_id: r.id, status: sel.value }));
      out.push(sel);
    }
    return out;
  }

  async function act(body) {
    try { const d = await post(body); toast(d.message); state.view === "overview" ? loadOverview() : loadList(); refreshPills(); }
    catch (ex) { if (ex.status !== 423) toast(ex.message, true); loadList(); }
  }
  async function refreshPills() { try { const d = await get({ view: "overview" }); pills(d.requests.pending, d.money.to_verify_count); } catch {} }

  /* ---------- dialogs ---------- */
  const dlg = $("own-dialog");
  let onOk = null;
  function openDialog(title, bodyNode, okText, okFn) {
    $("own-dialog-title").textContent = title;
    $("own-dialog-body").replaceChildren(bodyNode);
    const ok = $("own-dialog-ok"); ok.hidden = !okFn; ok.textContent = okText || "Confirm"; onOk = okFn;
    dlg.showModal();
  }
  function confirmDialog(title, msg, fn) { openDialog(title, el("p", "adm-muted", msg), "Confirm", fn); }
  $("own-dialog-cancel").addEventListener("click", () => dlg.close());
  $("own-dialog-form").addEventListener("submit", (e) => { e.preventDefault(); const f = onOk; dlg.close(); if (f) f(); });

  function viewProof(r) {
    const box = el("div");
    // only ever show files from the payment-proof upload folder
    if (/^assets\/uploads\/payments\/[A-Za-z0-9._-]+$/.test(r.proof)) {
      const img = el("img", "own-proof"); img.src = "../" + r.proof; img.alt = "Proof of payment from " + r.tenant; box.append(img);
    } else box.append(el("p", "adm-muted", "Proof file unavailable."));
    box.append(el("p", "adm-muted", peso(r.amount) + " via " + r.method + " · booking #" + r.booking_id));
    if (r.status === "pending") {
      const reject = btn("Reject proof (ask renter to resend)", () => { dlg.close(); confirmDialog("Reject this proof?", "The screenshot is removed and " + r.tenant + " can upload a new one.", () => act({ op: "reject_proof", booking_id: r.booking_id })); }, "adm-btn--danger");
      box.append(reject);
    }
    openDialog("Proof of payment", box, r.status === "pending" ? "Confirm paid" : null, r.status === "pending" ? () => act({ op: "confirm_payment", booking_id: r.booking_id }) : null);
  }

  /* ---------- live updates ---------- */
  const LIVE_MS = 5000;
  let paused = false, busy = false;
  function live(ok) {
    const b = $("own-live"); if (!b) return;
    b.dataset.state = paused ? "paused" : ok ? "live" : "error";
    $("own-live-text").textContent = paused ? "Paused" : ok ? "Live · updated " + new Date().toLocaleTimeString() : "Reconnecting…";
  }
  async function tick() {
    // skip while hidden, locked, paused, mid-request, or while the owner is using a dialog / dropdown
    if (paused || busy || document.hidden || $("own-main").hidden || dlg.open) return;
    if (document.activeElement && document.activeElement.tagName === "SELECT") return;
    busy = true;
    try {
      if (state.view === "overview") await loadOverview(true);
      else { await loadList(true); await refreshPills(); }
    } finally { busy = false; }
  }
  setInterval(tick, LIVE_MS);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) tick(); });
  $("own-live-pause").addEventListener("click", () => {
    paused = !paused; $("own-live-pause").textContent = paused ? "Resume" : "Pause";
    paused ? live(true) : tick();
  });

  /* ---------- start ---------- */
  (async function init() {
    try {
      const res = await fetch(UNLOCK);
      const d = await res.json();
      if (res.status === 401) { location.href = "../login.html"; return; }
      if (res.status === 403) { $("own-denied").textContent = d.message; $("own-denied").hidden = false; return; }
      $("own-who").textContent = d.name || "";
      if (d.unlocked) { showPanel(); go("overview"); } else showLock();
    } catch { $("own-denied").textContent = "Could not reach the server."; $("own-denied").hidden = false; }
  })();
})();
