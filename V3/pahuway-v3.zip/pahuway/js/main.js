/**
 * ------------------------------------------------------------------
 * Entry point. Wires up header/nav interactions and kicks off every
 * section module. 
 * ------------------------------------------------------------------ */

(function bootstrap() {
  document.addEventListener("DOMContentLoaded", () => {
    initMobileNav();
    initSearchForm();
    initListingAccess();
    initTagFilter();
    setFooterYear();

    PropertySections.init();
    DestinationsSection.init();
    ContentSections.init();
  });

    function initListingAccess() {
    const modal = document.querySelector("#listing-access-modal");
    if (!modal) return;

    const closeBtn = document.querySelector("#listing-access-close");
    const backdrop = modal.querySelector(".listing-access-modal__backdrop");
    const triggers = document.querySelectorAll(".listing-access-trigger");

    async function openModal(e) {
      e.preventDefault();

      try {
        const response = await fetch("api/session.php");
        const data = await response.json();

        if (data.loggedIn) {
          window.location.href = "list-property.html";
          return;
        }

        modal.hidden = false;
        document.body.style.overflow = "hidden";
      } catch (error) {
        window.location.href = "login.html";
      }
    }

    function closeModal() {
      modal.hidden = true;
      document.body.style.overflow = "";
    }

    triggers.forEach((trigger) => {
      trigger.addEventListener("click", openModal);
    });

    closeBtn.addEventListener("click", closeModal);
    backdrop.addEventListener("click", closeModal);

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !modal.hidden) {
        closeModal();
      }
    });
  }

  function initMobileNav() {
    const toggle = document.querySelector("#nav-toggle");
    const nav = document.querySelector("#main-nav");
    if (!toggle || !nav) return;

    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });

    nav.querySelectorAll("a").forEach((link) =>
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      })
    );
  }

  async function initSearchForm() {
    const form = document.querySelector("#search-form");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const norm = (v) => String(v || "").toLowerCase().replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
      const location = norm(document.querySelector("#search-location").value);
      const type = norm(document.querySelector("#search-type").value);
      const budget = document.querySelector("#search-budget").value;

      const resultsSection = document.querySelector("#search-results");
      const resultsGrid = document.querySelector("#search-results-grid");
      const resultsCount = document.querySelector("#search-results-count");
      const emptyState = document.querySelector("#search-results-empty");

      if (!resultsSection || !resultsGrid || !resultsCount || !emptyState) return;

      resetResultsHeading();
      resultsSection.hidden = false;
      resultsGrid.innerHTML = "<p>Searching...</p>";
      emptyState.hidden = true;

      try {
        const properties = await PahuwaySpaceData.getAllProperties();

        const results = properties.filter((property) => {
          if (property.status !== "available") return false;

          // Match every typed word against location, title or type
          const haystack = norm(`${property.location} ${property.title} ${property.badge}`);
          if (location && !location.split(" ").every((w) => haystack.includes(w))) {
            return false;
          }

          if (type && norm(property.badge) !== type) {
            return false;
          }

          // Budget is monthly: convert daily rates to a monthly figure
          const raw = Number(property.price) || 0;
          const price = property.priceUnit === "daily" ? raw * 30 : raw;

          if (budget === "0-10000" && price >= 10000) return false;
          if (budget === "10000-25000" && (price < 10000 || price > 25000)) return false;
          if (budget === "25000-60000" && (price < 25000 || price > 60000)) return false;
          if (budget === "60000+" && price < 60000) return false;

          return true;
        });

        resultsGrid.innerHTML = "";

        if (results.length === 0) {
          resultsCount.textContent = "0 properties found";
          emptyState.hidden = false;
        } else {
          resultsCount.textContent = `${results.length} ${results.length === 1 ? "property" : "properties"} found`;

          // Favorites are optional (logged-out visitors / failed request must not break search)
          let favorites = null; // null = guest: no save buttons
          try {
            const response = await fetch("api/favorites.php");
            const favoriteData = await response.json();
            if (favoriteData.success) favorites = new Set(favoriteData.favorites.map(Number));
          } catch (_) {}

          results.forEach((property) => {
            const card = PropertyCard.render(property, {
              favorited: !!favorites && favorites.has(Number(property.id)),
              canFavorite: favorites !== null,
              onToggleFavorite: async (id, isFav) => {
                const formData = new FormData();
                formData.append("property_id", id);
                formData.append("action", isFav ? "add" : "remove");

                const response = await fetch("api/favorites.php", {
                  method: "POST",
                  body: formData
                });

                const data = await response.json();

                if (!data.success) {
                  alert(data.message);
                }
              },
              onOpenDetails: (property) => {
                if (typeof window.onPropertyCardOpen === "function") {
                  window.onPropertyCardOpen(property);
                }
              }
            });

            resultsGrid.appendChild(card);
          });
        }

        resultsSection.scrollIntoView({ behavior: "smooth" });

      } catch (error) {
        console.error("Search failed:", error);
        resultsGrid.innerHTML = "<p>Unable to load search results.</p>";
      }
    });
  }

  // ---------- Tag filter ----------
  // Clicking a tag on a property shows every property with that tag
  // in the "search results" section (created here if the page has none).

  const DEFAULT_RESULTS_KICKER = "Your search results";
  const DEFAULT_RESULTS_HEADING = 'Properties <span class="accent">That Match</span>';

  function ensureResultsSection() {
    let section = document.querySelector("#search-results");
    if (section) return section;

    section = document.createElement("section");
    section.className = "section section--tight";
    section.id = "search-results";
    section.hidden = true;
    section.innerHTML = `
      <div class="container">
        <div class="section-heading">
          <span class="section-heading__kicker">${DEFAULT_RESULTS_KICKER}</span>
          <h2>${DEFAULT_RESULTS_HEADING}</h2>
        </div>
        <p id="search-results-count"></p>
        <div class="search-results-grid" id="search-results-grid"></div>
        <div class="dashboard-empty" id="search-results-empty" hidden>
          <p>No properties match your search.</p>
        </div>
      </div>
    `;

    const anchor = document.querySelector("#properties-near-you");
    if (anchor && anchor.parentNode) {
      anchor.parentNode.insertBefore(section, anchor);
    } else {
      (document.querySelector("main") || document.body).prepend(section);
    }
    return section;
  }

  function resetResultsHeading() {
    const section = document.querySelector("#search-results");
    if (!section) return;

    const kicker = section.querySelector(".section-heading__kicker");
    const heading = section.querySelector(".section-heading h2");
    if (kicker) kicker.textContent = DEFAULT_RESULTS_KICKER;
    if (heading) heading.innerHTML = DEFAULT_RESULTS_HEADING;

    const bar = section.querySelector("#tag-filter-bar");
    if (bar) bar.remove();

    const emptyText = section.querySelector("#search-results-empty p");
    if (emptyText) emptyText.textContent = "No properties match your search.";
  }

  async function showTagResults(tag) {
    tag = String(tag || "").trim().toLowerCase();
    if (!tag) return;

    showFilteredResults({
      kicker: "Filtered by tag",
      headingPrefix: "Properties tagged ",
      accent: tag,
      emptyText: "No properties have this tag yet.",
      predicate: (property) => (property.tags || []).includes(tag),
    });
  }

  function normalizeLocation(text) {
    return " " + String(text || "")
      .toLowerCase()
      .replace(/metro manila|national capital region|\bncr\b/g, " ")
      .replace(/philippines|\bph\b/g, " ")
      .replace(/[^a-z0-9ñ]+/g, " ")
      .trim() + " ";
  }

  function locationMatches(location, keywords) {
    const text = normalizeLocation(location);
    return keywords.some((kw) => text.indexOf(" " + normalizeLocation(kw).trim() + " ") !== -1);
  }

  function showCityResults(detail) {
    const name = String((detail && detail.name) || "").trim();
    const keywords = ((detail && detail.match) || [name]).filter(Boolean);
    if (!name) return;

    showFilteredResults({
      kicker: "Popular destination",
      headingPrefix: "Properties in ",
      accent: name,
      emptyText: "No properties are listed in " + name + " yet.",
      predicate: (property) => locationMatches(property.location, keywords),
    });
  }

  async function showFilteredResults(opts) {
    const section = ensureResultsSection();
    const resultsGrid = section.querySelector("#search-results-grid");
    const resultsCount = section.querySelector("#search-results-count");
    const emptyState = section.querySelector("#search-results-empty");
    const kicker = section.querySelector(".section-heading__kicker");
    const heading = section.querySelector(".section-heading h2");

    if (kicker) kicker.textContent = opts.kicker;
    if (heading) {
      heading.textContent = "";
      heading.append(opts.headingPrefix);
      const accent = document.createElement("span");
      accent.className = "accent";
      accent.textContent = opts.accent;
      heading.appendChild(accent);
    }

    let bar = section.querySelector("#tag-filter-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "tag-filter-bar";
      bar.className = "tag-filter-bar";
      bar.innerHTML = `<button type="button" class="btn btn--ghost">Clear filter</button>`;
      bar.querySelector("button").addEventListener("click", () => {
        section.hidden = true;
        resetResultsHeading();
        if (window.history.replaceState && new URLSearchParams(window.location.search).has("tag")) {
          window.history.replaceState(null, "", window.location.pathname + window.location.hash);
        }
      });
      resultsCount.parentNode.insertBefore(bar, resultsCount);
    }

    section.hidden = false;
    resultsGrid.innerHTML = "<p>Loading properties...</p>";
    emptyState.hidden = true;
    resultsCount.textContent = "";

    try {
      const properties = await PahuwaySpaceData.getAllProperties();
      const results = properties.filter(opts.predicate);

      resultsGrid.innerHTML = "";

      if (results.length === 0) {
        resultsCount.textContent = "0 properties found";
        emptyState.querySelector("p").textContent = opts.emptyText;
        emptyState.hidden = false;
      } else {
        resultsCount.textContent = `${results.length} ${results.length === 1 ? "property" : "properties"} found`;

        let favorites = null; // null = guest: no save buttons
        try {
          const response = await fetch("api/favorites.php");
          const favoriteData = await response.json();
          if (favoriteData.success) favorites = new Set(favoriteData.favorites.map(Number));
        } catch (err) {
          console.error("Failed to load favorites:", err);
        }

        results.forEach((property) => {
          const card = PropertyCard.render(property, {
            favorited: !!favorites && favorites.has(Number(property.id)),
            canFavorite: favorites !== null,
            onToggleFavorite: async (id, isFav) => {
              const formData = new FormData();
              formData.append("property_id", id);
              formData.append("action", isFav ? "add" : "remove");

              const response = await fetch("api/favorites.php", {
                method: "POST",
                body: formData
              });

              const data = await response.json();
              if (!data.success) alert(data.message);
            },
            onOpenDetails: (p) => {
              if (typeof window.onPropertyCardOpen === "function") {
                window.onPropertyCardOpen(p);
              }
            }
          });

          resultsGrid.appendChild(card);
        });
      }

      section.scrollIntoView({ behavior: "smooth" });
    } catch (error) {
      console.error("Filter failed:", error);
      resultsGrid.innerHTML = "<p>Unable to load properties.</p>";
    }
  }

  function initTagFilter() {
    window.addEventListener("pahuway:filter-tag", (e) => {
      e.preventDefault(); // tells PropertyCard this page handles it
      showTagResults(e.detail && e.detail.tag);
    });

    window.addEventListener("pahuway:filter-city", (e) => {
      showCityResults(e.detail);
    });

    // Arriving from another page (e.g. dashboard) via member-home.html?tag=hospital
    const tag = new URLSearchParams(window.location.search).get("tag");
    if (tag) showTagResults(tag);
  }

  function setFooterYear() {
    const el = document.querySelector("#footer-year");
    if (el) el.textContent = new Date().getFullYear();
  }
})();