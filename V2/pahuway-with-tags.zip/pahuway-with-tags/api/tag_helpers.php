<?php

/*
 * Property tags (nearby places such as "hospital", "mall", "near school").
 *
 * Normalized like the rest of the database: a lookup table `tags` (one row per
 * distinct tag) and a link table `property_tags` (which property has which tags,
 * in the order the owner typed them). No NULL columns.
 *
 * The listing form sends the tags as one comma-separated string in "tags".
 * Each tag is trimmed, lower-cased, limited to 30 characters and de-duplicated.
 * A property can have at most 8 tags.
 */

const MAX_PROPERTY_TAGS = 8;
const MAX_TAG_LENGTH = 30;

/* "Hospital, near  school,hospital" -> ["hospital", "near school"] */
function normalize_tags($raw): array
{
    $parts = is_array($raw) ? $raw : explode(",", (string) $raw);
    $tags = [];

    foreach ($parts as $part) {
        $tag = preg_replace('/\s+/u', ' ', trim((string) $part));
        $tag = trim(mb_substr(mb_strtolower($tag), 0, MAX_TAG_LENGTH));

        if ($tag === "" || in_array($tag, $tags, true)) {
            continue;
        }

        $tags[] = $tag;

        if (count($tags) >= MAX_PROPERTY_TAGS) {
            break;
        }
    }

    return $tags;
}

/* Replace a property's tags. Call inside a transaction (needs db_run from property_helpers.php). */
function save_property_tags(mysqli $conn, int $property_id, array $tags): void
{
    db_run($conn, "DELETE FROM property_tags WHERE property_id = ?", "i", [$property_id])->close();

    foreach (array_values($tags) as $position => $tag) {
        db_run($conn, "INSERT IGNORE INTO tags (tag_name) VALUES (?)", "s", [$tag])->close();

        db_run(
            $conn,
            "INSERT IGNORE INTO property_tags (property_id, tag_id, sort_order)
             SELECT ?, tag_id, ? FROM tags WHERE tag_name = ?",
            "iis",
            [$property_id, $position, $tag]
        )->close();
    }
}

/* Adds tags[] to a list of property rows (one query for the whole list). */
function attach_property_tags(mysqli $conn, array &$rows): void
{
    $index = [];
    foreach ($rows as $i => $row) {
        $rows[$i]["tags"] = [];
        $index[(int) $row["property_id"]] = $i;
    }

    if (!$index) return;

    $in = implode(",", array_keys($index)); // ints only

    $res = $conn->query(
        "SELECT pt.property_id, t.tag_name
           FROM property_tags pt
           INNER JOIN tags t ON t.tag_id = pt.tag_id
          WHERE pt.property_id IN ($in)
          ORDER BY pt.property_id ASC, pt.sort_order ASC"
    );

    while ($res && ($r = $res->fetch_assoc())) {
        $rows[$index[(int) $r["property_id"]]]["tags"][] = $r["tag_name"];
    }
}

?>
