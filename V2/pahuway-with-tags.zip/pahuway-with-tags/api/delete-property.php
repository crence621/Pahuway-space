<?php

session_start();

require_once "db.php";
require_once "property_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$owner_id = (int) $_SESSION["user_id"];
$property_id = isset($_POST["property_id"]) ? (int) $_POST["property_id"] : 0;

if ($property_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid property."]);
    exit;
}

/*
| A property can only be deleted by its owner, and only when it has no
| pending or confirmed booking. The property row is locked while we check,
| so a booking request that arrives at the same moment cannot slip in.
|
| Cancelled bookings do not block deletion; they are removed with the
| property (the database does not allow a property with bookings to be
| deleted otherwise). Photos, amenities, bills, tags and favorites are
| removed automatically with the property.
*/

$images = [];

try {
    $conn->begin_transaction();

    $stmt = db_run(
        $conn,
        "SELECT property_id FROM properties
          WHERE property_id = ? AND owner_id = ?
          FOR UPDATE",
        "ii",
        [$property_id, $owner_id]
    );
    $owned = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$owned) {
        $conn->rollback();
        echo json_encode(["success" => false, "message" => "Property not found or you do not own it."]);
        $conn->close();
        exit;
    }

    $stmt = db_run(
        $conn,
        "SELECT
            SUM(booking_status = 'pending')   AS pending_count,
            SUM(booking_status = 'confirmed') AS confirmed_count
           FROM bookings
          WHERE property_id = ?",
        "i",
        [$property_id]
    );
    $counts = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ((int) $counts["pending_count"] > 0) {
        $conn->rollback();
        echo json_encode([
            "success" => false,
            "message" => "This property has a pending booking request. Please confirm or decline it first before deleting the property."
        ]);
        $conn->close();
        exit;
    }

    if ((int) $counts["confirmed_count"] > 0) {
        $conn->rollback();
        echo json_encode([
            "success" => false,
            "message" => "This property has a confirmed booking, so it can't be deleted."
        ]);
        $conn->close();
        exit;
    }

    // remember the uploaded photos so the files can be removed after the delete
    $stmt = db_run($conn, "SELECT image_path FROM property_images WHERE property_id = ?", "i", [$property_id]);
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $images[] = $row["image_path"];
    }
    $stmt->close();

    // only cancelled bookings are left at this point
    db_run($conn, "DELETE FROM bookings WHERE property_id = ?", "i", [$property_id])->close();

    db_run(
        $conn,
        "DELETE FROM properties WHERE property_id = ? AND owner_id = ?",
        "ii",
        [$property_id, $owner_id]
    )->close();

    $conn->commit();

    foreach ($images as $path) {
        delete_uploaded_image($path); // only touches files inside assets/uploads/properties/
    }

    echo json_encode(["success" => true, "message" => "Property deleted."]);

} catch (Throwable $e) {

    @$conn->rollback();
    error_log("[pahuway] delete-property: " . $e->getMessage());

    echo json_encode(["success" => false, "message" => "Failed to delete property."]);
}

$conn->close();

?>
