-- Run this ONCE on your existing (already live) database, e.g. in phpMyAdmin > SQL tab.
-- It adds the two tables used for the nearby-place tags (hospital, mall, school, ...):
--   tags           one row per distinct tag
--   property_tags  which property has which tags (in the order the owner typed them)
-- Nothing in your existing tables is changed; existing properties simply have no tags.

CREATE TABLE IF NOT EXISTS `tags` (
  `tag_id`   int unsigned NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(30) NOT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `uq_tags_name` (`tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `property_tags` (
  `property_id` int unsigned NOT NULL,
  `tag_id`      int unsigned NOT NULL,
  `sort_order`  tinyint unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`property_id`, `tag_id`),
  KEY `idx_property_tags_tag` (`tag_id`),
  CONSTRAINT `fk_pt_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_pt_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`tag_id`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
