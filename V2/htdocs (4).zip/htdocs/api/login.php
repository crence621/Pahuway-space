<?php

ini_set("display_errors", "0");
header("Content-Type: application/json");

// Report any server-side failure as readable JSON instead of an empty 500
set_exception_handler(function ($e) {
    http_response_code(200);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
});
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err["type"], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (!headers_sent()) { http_response_code(200); header("Content-Type: application/json"); }
        echo json_encode([
            "success" => false,
            "message" => "Server error: " . $err["message"]
        ]);
    }
});

@session_start();

require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

if ($email === "" || $password === "") {
    echo json_encode([
        "success" => false,
        "message" => "Please enter your email and password."
    ]);
    exit;
}

/* Find user */
$stmt = $conn->prepare(
    "SELECT user_id, full_name, email, password, email_verified 
     FROM users 
     WHERE email = ?"
);

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

/* Verify password.
 * Also accepts legacy plain-text / md5 values (e.g. users inserted by hand
 * in phpMyAdmin) and upgrades them to a proper hash on first login. */
$stored = (string) $user["password"];
$ok = password_verify($password, $stored);

if (!$ok && !preg_match('/^\$(2[abxy]|argon2)/', $stored)) {
    if (hash_equals($stored, $password) || hash_equals(strtolower($stored), md5($password))) {
        $ok = true;
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $up = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
        $up->bind_param("si", $newHash, $user["user_id"]);
        $up->execute();
        $up->close();
    }
}

if (!$ok) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

/* Block accounts whose email hasn't been verified yet */
if ((int) $user["email_verified"] !== 1) {
    echo json_encode([
        "success" => false,
        "code" => "unverified",
        "email" => $user["email"],
        "message" => "Please verify your email first. Check your inbox for the verification link."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

/* Create session */
@session_regenerate_id(true);
$_SESSION["user_id"] = $user["user_id"];
$_SESSION["full_name"] = $user["full_name"];
$_SESSION["email"] = $user["email"];

echo json_encode([
    "success" => true,
    "message" => "Login successful.",
    "user" => [
        "user_id" => $user["user_id"],
        "full_name" => $user["full_name"],
        "email" => $user["email"]
    ]
]);

$stmt->close();
$conn->close();

?>