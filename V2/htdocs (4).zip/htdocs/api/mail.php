<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$GLOBALS['pahuway_mail_error'] = '';

function sendPahuwayEmail(
    string $recipientEmail,
    string $recipientName,
    string $subject,
    string $htmlBody
): bool {
    $autoload = __DIR__ . '/../vendor/autoload.php';
    $real = __DIR__ . '/../vendor/composer/autoload_real.php';
    if (!is_file($autoload) || !is_file($real)) {
        $GLOBALS['pahuway_mail_error'] = 'vendor/ (PHPMailer) is missing or incomplete on the server.';
        error_log('Pahuway email error: ' . $GLOBALS['pahuway_mail_error']);
        return false;
    }
    require_once $autoload;

    $config = require __DIR__ . '/mail_config.php';

    $mail = new PHPMailer(true);

    try {
        $mail->Timeout = 15;
        $mail->isSMTP();
        $mail->Host = $config['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $config['username'];
        $mail->Password = $config['password'];
        $mail->SMTPSecure = $config['encryption'];
        $mail->Port = (int) $config['port'];

        $mail->CharSet = 'UTF-8';
        $mail->setFrom(
            $config['from_email'],
            $config['from_name']
        );

        $mail->addAddress($recipientEmail, $recipientName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlBody;
        $mail->AltBody = strip_tags($htmlBody);

        $mail->send();
        return true;
    } catch (Exception $e) {
        $GLOBALS['pahuway_mail_error'] = $mail->ErrorInfo;
        error_log('Pahuway email error: ' . $mail->ErrorInfo);
        return false;
    }
}
