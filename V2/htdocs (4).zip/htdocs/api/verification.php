<?php

/*
 * Email-verification helpers shared by signup.php, resend-verification.php
 * and verify-email.php.
 */

require_once __DIR__ . "/mail.php";

/** Public base URL of the site (folder that contains /api), no trailing slash. */
function site_base_url(): string
{
    $config = require __DIR__ . "/mail_config.php";
    if (!empty($config["site_url"])) {
        return rtrim($config["site_url"], "/");
    }

    $https = (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off")
        || (($_SERVER["HTTP_X_FORWARDED_PROTO"] ?? "") === "https");
    $dir = rtrim(str_replace("\\", "/", dirname(dirname($_SERVER["SCRIPT_NAME"] ?? "/api/x.php"))), "/");

    return ($https ? "https" : "http") . "://" . ($_SERVER["HTTP_HOST"] ?? "localhost") . $dir;
}

/**
 * Creates a fresh 24h token for the user (replacing any older one) and emails the link.
 * Returns true if the email was handed to the SMTP server.
 */
function send_verification_email(mysqli $conn, int $userId, string $email, string $name): bool
{
    $token = bin2hex(random_bytes(32));
    $hash = hash("sha256", $token);

    $stmt = $conn->prepare(
        "REPLACE INTO email_verifications (user_id, token_hash, expires_at)
         VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))"
    );
    $stmt->bind_param("is", $userId, $hash);
    $stmt->execute();
    $stmt->close();

    $link = site_base_url() . "/api/verify-email.php?token=" . $token;
    $safeName = htmlspecialchars($name, ENT_QUOTES, "UTF-8");
    $safeLink = htmlspecialchars($link, ENT_QUOTES, "UTF-8");

    $html = "<div style=\"font-family:Arial,sans-serif;max-width:480px;margin:auto;color:#222\">"
        . "<h2>Welcome to Pahuway Space, {$safeName}!</h2>"
        . "<p>Please confirm your email address to activate your account.</p>"
        . "<p><a href=\"{$safeLink}\" style=\"display:inline-block;padding:12px 24px;"
        . "background:#d4af1a;color:#111;text-decoration:none;border-radius:999px;font-weight:bold\">"
        . "Verify my email</a></p>"
        . "<p style=\"font-size:13px;color:#666\">Or paste this link into your browser:<br>{$safeLink}</p>"
        . "<p style=\"font-size:13px;color:#666\">This link expires in 24 hours. "
        . "If you didn't create an account, you can ignore this email.</p></div>";

    return sendPahuwayEmail($email, $name, "Verify your Pahuway Space email", $html);
}
