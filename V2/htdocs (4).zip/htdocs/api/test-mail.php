<?php

/*
 * Admin-only mail diagnostic. While logged in as an admin, open in your browser:
 *   /api/test-mail.php?email=you@example.com
 * It sends a test email and shows the exact SMTP error if it fails.
 */

ini_set("display_errors", "0");
header("Content-Type: application/json");
session_start();

require_once "db.php";
require_once "admin-auth.php";
require_admin($conn);

$recipient = filter_var($_REQUEST["email"] ?? "", FILTER_VALIDATE_EMAIL);

if (!$recipient) {
    echo json_encode(["success" => false, "message" => "Add ?email=you@example.com to the URL."]);
    exit;
}

require_once __DIR__ . "/mail.php";

$sent = sendPahuwayEmail(
    $recipient,
    "Pahuway Space Test",
    "Pahuway Space Email Test",
    "<h2>Email test successful</h2><p>Your Pahuway Space email configuration is working.</p>"
);

echo json_encode([
    "success" => $sent,
    "message" => $sent ? "Email sent successfully." : "Email sending failed.",
    "error" => $sent ? "" : $GLOBALS["pahuway_mail_error"]
]);
