<?php

/* Opened from the link in the verification email. Redirects back to login.html. */

require_once "db.php";

$token = (string) ($_GET["token"] ?? "");
$status = "invalid";

if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $hash = hash("sha256", $token);

    $stmt = $conn->prepare(
        "SELECT user_id, (expires_at < NOW()) AS expired
         FROM email_verifications WHERE token_hash = ? LIMIT 1"
    );
    $stmt->bind_param("s", $hash);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row && (int) $row["expired"] === 1) {
        $status = "expired";
    } elseif ($row) {
        $uid = (int) $row["user_id"];

        $up = $conn->prepare("UPDATE users SET email_verified = 1 WHERE user_id = ?");
        $up->bind_param("i", $uid);
        $up->execute();
        $up->close();

        $del = $conn->prepare("DELETE FROM email_verifications WHERE user_id = ?");
        $del->bind_param("i", $uid);
        $del->execute();
        $del->close();

        $status = "success";
    }
}

header("Location: ../login.html?verified=" . $status);
exit;
