<?php

return [
    "host" => "smtp.gmail.com",
    "port" => 587,
    "encryption" => "tls",
    "username" => "bsiteducationmanagementsystems@gmail.com",
    "password" => "djnyoqzjiinzsovs",
    "from_email" => "bsiteducationmanagementsystems@gmail.com",
    "from_name" => "Pahuway Space",
    // Public URL of your site (used in verification links), e.g. "https://pahuwayspace.rf.gd". Leave "" to auto-detect.
    "site_url" => "https://pahuwayspace.42web.io/"
];

