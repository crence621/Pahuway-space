-- OPTIONAL. Adds the account-setup fields (mobile number, Facebook, renter/owner).
-- The site adds these columns by itself the first time they are needed, so you only
-- need to run this if you want to do it by hand (phpMyAdmin > SQL tab). Run it once.
ALTER TABLE `users`
  ADD COLUMN `phone`       varchar(20)  NOT NULL DEFAULT '',
  ADD COLUMN `facebook`    varchar(255) NOT NULL DEFAULT '',
  ADD COLUMN `member_type` enum('unset','renter','owner') NOT NULL DEFAULT 'unset';
