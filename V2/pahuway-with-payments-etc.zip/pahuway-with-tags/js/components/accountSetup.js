/* ==========================================================================
   "Complete your account setup" popup
   Shown to a logged-in user until they have given a mobile number and chosen
   renter or owner. Facebook is optional. Saved through api/complete-setup.php.
   ========================================================================== */
(function () {
  "use strict";

  fetch("api/session.php", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(function (s) {
      if (s && s.loggedIn && s.user && s.user.needs_setup) show();
    })
    .catch(function () {});

  function show() {
    var overlay = document.createElement("div");
    overlay.className = "setup-overlay";
    overlay.innerHTML =
      '<form class="setup-card" role="dialog" aria-modal="true" aria-labelledby="setup-title" novalidate>' +
        '<h2 id="setup-title">Complete your account setup</h2>' +
        '<div class="setup-field">' +
          '<label for="setup-phone">Mobile number</label>' +
          '<input type="tel" id="setup-phone" name="phone" placeholder="09XX XXX XXXX" autocomplete="tel" maxlength="20" required />' +
        '</div>' +
        '<div class="setup-field">' +
          '<label for="setup-fb">Facebook <span class="setup-opt">(optional)</span></label>' +
          '<input type="text" id="setup-fb" name="facebook" placeholder="facebook.com/yourname" maxlength="255" />' +
        '</div>' +
        '<fieldset class="setup-field">' +
          '<legend>Are you a renter or an owner?</legend>' +
          '<div class="setup-choices">' +
            '<label class="setup-choice"><input type="radio" name="member_type" value="renter" /> Renter</label>' +
            '<label class="setup-choice"><input type="radio" name="member_type" value="owner" /> Owner</label>' +
          '</div>' +
        '</fieldset>' +
        '<p class="setup-error" role="alert"></p>' +
        '<button type="submit" class="btn btn--primary setup-submit">Save</button>' +
      '</form>';
    document.body.appendChild(overlay);
    document.body.style.overflow = "hidden";

    var form = overlay.querySelector("form");
    var err = overlay.querySelector(".setup-error");
    var btn = overlay.querySelector(".setup-submit");
    overlay.querySelector("#setup-phone").focus();

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      err.textContent = "";

      var phone = form.phone.value.trim();
      var digits = phone.replace(/\D/g, "");
      var type = form.member_type.value;

      if (!phone) { err.textContent = "Please enter your mobile number."; return; }
      if (!/^[0-9+()\-\s]+$/.test(phone) || digits.length < 7 || digits.length > 15) {
        err.textContent = "Please enter a valid mobile number."; return;
      }
      if (!type) { err.textContent = "Please choose renter or owner."; return; }

      btn.disabled = true;
      var body = new URLSearchParams();
      body.append("phone", phone);
      body.append("facebook", form.facebook.value.trim());
      body.append("member_type", type);

      fetch("api/complete-setup.php", { method: "POST", body: body, credentials: "same-origin" })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.success) {
            overlay.remove();
            window.dispatchEvent(new Event("pahuway:setup-complete"));
            document.body.style.overflow = "";
          } else {
            err.textContent = (d && d.message) || "Could not save. Please try again.";
            btn.disabled = false;
          }
        })
        .catch(function () {
          err.textContent = "Could not save. Please try again.";
          btn.disabled = false;
        });
    });
  }
})();