const BookingModal = (() => {
  const peso = new Intl.NumberFormat("en-PH", { maximumFractionDigits: 0 });

  // Daily rentals can only be booked for up to 1 month (30 nights).
  const MAX_DAILY_NIGHTS = 30;

  let overlayEl, modalEl, formEl, resultEl;
  let currentProperty = null;
  let termsEl = null;

  // Property ids this user already requested (pending / confirmed).
  const requestedIds = new Set();
  let requestedLoaded = false;

  // Latest approved (confirmed) booking of this user per property id, and the user's name.
  let confirmedByProperty = new Map();
  let currentUserName = "";
  let currentUserId = null;
  let activeApproved = null; // approved booking being shown in the popup

  function buildDom() {
    overlayEl = document.createElement("div");
    overlayEl.className = "modal-overlay";
    overlayEl.innerHTML = `
      <div class="booking-modal" role="dialog" aria-modal="true" aria-labelledby="booking-modal-title">
        <div class="booking-modal__media">
          <img class="booking-modal__image" src="" alt="" />
          <span class="booking-modal__badge"></span>
          <button type="button" class="booking-modal__close" aria-label="Close">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 6l12 12M18 6 6 18"/></svg>
          </button>
        </div>

        <div class="booking-modal__body">
          <div class="booking-approved" hidden>
            <div class="booking-approved__head">
              <span class="booking-approved__icon">✓</span>
              <div>
                <strong>Property approved</strong>
                <p>You can now message the owner.</p>
              </div>
            </div>
            <ul class="booking-approved__contact"></ul>
          </div>

          <div class="booking-owner-pay" hidden>
            <p class="booking-owner-pay__title">Payments from renters</p>
            <div class="booking-owner-pay__list"></div>
          </div>

          <p class="booking-modal__code"></p>
          <h2 class="booking-modal__title" id="booking-modal-title"></h2>
          <p class="booking-modal__location"></p>
          <div class="booking-modal__specs"></div>
          <div class="booking-modal__tags" hidden></div>
          <ul class="booking-modal__amenities"></ul>
          <div class="booking-modal__facilities-wrap" hidden>
            <p class="booking-modal__facilities-title">Amenities &amp; facilities</p>
            <ul class="booking-modal__facilities"></ul>
          </div>
          <p class="booking-modal__price"></p>

          <hr class="booking-modal__divider" />

          <form class="booking-form" novalidate>
            <div class="booking-field">
              <label for="booking-name">Full name</label>
              <input type="text" id="booking-name" placeholder="Juan Dela Cruz" required autocomplete="name" />
            </div>

            <div class="booking-field-row" id="booking-date-row">
              <div class="booking-field">
                <label for="booking-guests">Guests</label>
                <input type="number" id="booking-guests" min="1" value="1" required />
              </div>
              <div class="booking-field">
                <label for="booking-checkin" id="booking-checkin-label">Check-in</label>
                <input type="date" id="booking-checkin" required />
              </div>
              <div class="booking-field" id="booking-checkout-field">
                <label for="booking-checkout">Check-out</label>
                <input type="date" id="booking-checkout" required />
              </div>
            </div>

            <p class="booking-field-error" id="booking-date-error">Check-out must be after check-in.</p>

            <div class="booking-summary">
              <div class="booking-summary__row">
                <span id="booking-nights-label">0 nights</span>
                <span id="booking-nights-rate">₱ 0</span>
              </div>
              <div class="booking-summary__bills" id="booking-bills"></div>
              <div class="booking-summary__row booking-summary__row--total">
                <span id="booking-total-label">Estimated total</span>
                <span id="booking-total">₱ 0</span>
              </div>
              <p class="booking-summary__note" id="booking-bills-note" hidden>
              </p>
            </div>

            <div class="booking-payment" hidden>
              <p class="booking-payment__title">Payment</p>
              <div class="booking-payment__form">
                <label for="booking-pay-method">Payment method</label>
                <select id="booking-pay-method"></select>
                <label for="booking-pay-proof">Proof of payment</label>
                <input type="file" id="booking-pay-proof" accept="image/png,image/jpeg,image/webp" />
                <p class="booking-payment__hint">Pay the owner outside the site, then upload a screenshot of your payment.</p>
              </div>
              <div class="booking-payment__done" hidden></div>
            </div>

            <button type="submit" class="btn btn--primary booking-submit-block">Request to Book</button>
            <p class="booking-form__note">Booking request only — payment is not collected here.</p>
          </form>

          <div class="booking-confirmation" hidden>
            <div class="booking-confirmation__icon">✓</div>
            <h3>Booking request sent</h3>
            <p class="booking-confirmation__status">Already requested · waiting for the owner to confirm</p>
            <p class="booking-confirmation__summary"></p>
            <p class="booking-form__note">Booking request saved — payment is not collected here.</p>
            <button type="button" class="btn btn--ghost booking-submit-block booking-confirmation__close">Close</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(overlayEl);

    modalEl = overlayEl.querySelector(".booking-modal");
    formEl = overlayEl.querySelector(".booking-form");
    resultEl = overlayEl.querySelector(".booking-confirmation");

    const checkin = overlayEl.querySelector("#booking-checkin");
    const checkout = overlayEl.querySelector("#booking-checkout");
    const guests = overlayEl.querySelector("#booking-guests");

    overlayEl.querySelector(".booking-modal__close").addEventListener("click", close);
    overlayEl.querySelector(".booking-modal__tags").addEventListener("click", (e) => {
      const btn = e.target.closest("[data-tag]");
      if (!btn) return;
      const tag = btn.dataset.tag;
      close();
      if (typeof PropertyCard !== "undefined") PropertyCard.filterByTag(tag);
    });
    overlayEl.addEventListener("click", (e) => {
      if (e.target === overlayEl) close();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      if (termsEl && termsEl.classList.contains("is-open")) {
        closeTerms();
      } else if (overlayEl.classList.contains("is-open")) {
        close();
      }
    });

    checkin.addEventListener("change", () => {
      if (checkin.value) {
        const next = new Date(checkin.value);
        next.setDate(next.getDate() + 1);
        checkout.min = next.toISOString().slice(0, 10);
        const last = new Date(checkin.value);
        last.setDate(last.getDate() + MAX_DAILY_NIGHTS);
        checkout.max = last.toISOString().slice(0, 10);
        if (checkout.value && checkout.value <= checkin.value) checkout.value = "";
        if (checkout.value && checkout.value > checkout.max) checkout.value = "";
      }
      updateSummary();
    });

    [checkout, guests].forEach((input) => input.addEventListener("input", updateSummary));

    overlayEl.querySelector("#booking-pay-method").addEventListener("change", syncPayButton);
    overlayEl.querySelector("#booking-pay-proof").addEventListener("change", syncPayButton);
    overlayEl.querySelector(".booking-owner-pay__list").addEventListener("click", handleConfirmPayment);

    resultEl.querySelector(".booking-confirmation__close").addEventListener("click", close);
    formEl.addEventListener("submit", handleSubmit);

    buildTermsDom();
  }

  // ---------- Terms & Conditions pop-up ----------

  function buildTermsDom() {
    termsEl = document.createElement("div");
    termsEl.className = "terms-overlay";
    termsEl.innerHTML = `
      <div class="terms-dialog" role="dialog" aria-modal="true" aria-labelledby="terms-title">
        <h3 class="terms-dialog__title" id="terms-title">Terms &amp; Conditions</h3>
        <p class="terms-dialog__intro">Please read these before sending your booking request.</p>

        <div class="terms-dialog__scroll" tabindex="0">
          <ol>
            <li><strong>Booking request only.</strong> Sending a request does not guarantee your stay. The property owner reviews it and may accept or decline.</li>
            <li><strong>Payment is made directly to the owner.</strong> Pahuway Space does not collect, receive, hold, or process rental payments through a Pahuway account. Once your booking request is confirmed, any required payment must be sent directly to the property owner's personal account, e-wallet, bank account, or other payment method provided by the owner. Pahuway Space only displays the payment method provided by the owner and does not act as the recipient of the payment.</li>
            <li><strong>Rent and bills.</strong> The amount shown is the rent only. Bills marked "Paid Separately" are not included and depend on actual usage and applicable rates.</li>
            <li><strong>Accurate details.</strong> The name, number of guests and dates you entered must be correct. The owner may decline requests with incorrect details.</li>
            <li><strong>House rules.</strong> You agree to follow the owner's rules for the property (for example on pets, parking, visitors and quiet hours) and to take care of the space and its facilities.</li>
            <li><strong>Changes and cancellation.</strong> Cancellation and refund terms are set by the owner. Contact the owner to change or cancel a request.</li>
            <li><strong>Availability.</strong> Dates are not held until the owner confirms. Another renter's confirmed booking may make the property unavailable.</li>
          </ol>
        </div>



        <label class="terms-check">
          <input type="checkbox" class="terms-check__box" />
          <span>I have read and agree to the Terms &amp; Conditions.</span>
        </label>
        <label class="terms-check">
          <input type="checkbox" class="terms-check__box" />
          <span>I understand this is a booking request and is not confirmed until the owner accepts it.</span>
        </label>
        <label class="terms-check">
          <input type="checkbox" class="terms-check__box" />
          <span>I confirm that my details are correct and I am requesting to book this property.</span>
        </label>

        <div class="terms-dialog__actions">
          <button type="button" class="btn btn--ghost terms-dialog__cancel">Go back</button>
          <button type="button" class="btn btn--primary terms-dialog__confirm" disabled>Confirm request</button>
        </div>
      </div>
    `;
    document.body.appendChild(termsEl);

    const boxes = termsEl.querySelectorAll(".terms-check__box");
    const confirmBtn = termsEl.querySelector(".terms-dialog__confirm");

    boxes.forEach((box) =>
      box.addEventListener("change", () => {
        confirmBtn.disabled = !Array.from(boxes).every((b) => b.checked);
      })
    );

    termsEl.querySelector(".terms-dialog__cancel").addEventListener("click", closeTerms);
    termsEl.addEventListener("click", (e) => {
      if (e.target === termsEl) closeTerms();
    });
    confirmBtn.addEventListener("click", () => {
      if (confirmBtn.disabled) return;
      closeTerms();
      sendBooking();
    });
  }

  function openTerms() {
    termsEl.querySelectorAll(".terms-check__box").forEach((b) => (b.checked = false));
    termsEl.querySelector(".terms-dialog__confirm").disabled = true;
    termsEl.querySelector(".terms-dialog__scroll").scrollTop = 0;
    termsEl.classList.add("is-open");
  }

  function closeTerms() {
    if (termsEl) termsEl.classList.remove("is-open");
  }

  // ---------- "Already requested" state ----------

  async function loadRequestedIds() {
    try {
      const [response, sessionRes] = await Promise.all([
        fetch("api/bookings.php"),
        fetch("api/session.php"),
      ]);
      const data = await response.json();
      if (!data.success) return;

      try {
        const sess = await sessionRes.json();
        if (sess && sess.loggedIn) {
          currentUserName = sess.user.full_name || "";
          currentUserId = Number(sess.user.user_id);
        }
      } catch (e) {}

      requestedIds.clear();
      const confirmed = new Map();

      data.bookings.forEach((b) => {
        const id = String(b.property_id);
        if (b.booking_status === "pending" || b.booking_status === "confirmed") requestedIds.add(id);
        if (b.booking_status === "confirmed" && !confirmed.has(id)) confirmed.set(id, b);
      });
      confirmedByProperty = confirmed;

      requestedLoaded = true;
    } catch (error) {
      // Not logged in or offline: the button just stays as "Request to Book".
    }
  }

  // ---------- Approved booking view ----------

  function facebookHref(value) {
    const v = value.trim();
    if (/^https?:\/\//i.test(v)) return v;
    if (/(facebook|fb)\.com/i.test(v)) return "https://" + v.replace(/^\/+/, "");
    if (/^[A-Za-z0-9.]+$/.test(v)) return "https://facebook.com/" + v;
    return "";
  }

  function setInputsLocked(locked) {
    formEl.querySelectorAll("input").forEach((input) => {
      if (input.closest(".booking-payment")) return;
      input.disabled = locked;
    });
    formEl.querySelector(".booking-form__note").hidden = locked;
  }

  function hideApprovedView() {
    const box = overlayEl.querySelector(".booking-approved");
    box.hidden = true;
    activeApproved = null;
    const pay = overlayEl.querySelector(".booking-payment");
    pay.hidden = true;
    delete pay.dataset.key;
    setInputsLocked(false);
  }

  // ---------- Payment (proof uploaded here) ----------

  function syncPayButton() {
    if (!activeApproved || activeApproved.payment_state !== "awaiting_proof") return;
    const btn = formEl.querySelector(".booking-submit-block");
    const method = overlayEl.querySelector("#booking-pay-method").value;
    const file = overlayEl.querySelector("#booking-pay-proof").files.length > 0;
    btn.disabled = !(method && file);
  }

  function renderPayment(booking) {
    const box = overlayEl.querySelector(".booking-payment");
    const formPart = box.querySelector(".booking-payment__form");
    const done = box.querySelector(".booking-payment__done");
    const select = overlayEl.querySelector("#booking-pay-method");
    const hint = box.querySelector(".booking-payment__hint");
    const btn = formEl.querySelector(".booking-submit-block");
    const state = booking.payment_state;
    const key = booking.booking_id + ":" + state;

    box.hidden = false;
    btn.classList.remove("is-loading");

    if (state === "awaiting_proof") {
      done.hidden = true;
      formPart.hidden = false;
      btn.classList.remove("is-requested");
      btn.textContent = "Already paid";

      if (box.dataset.key !== key) {
        const methods = currentProperty.paymentMethods || [];
        select.innerHTML =
          `<option value="">Select payment method</option>` +
          methods.map((m) => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join("");
        select.disabled = methods.length === 0;
        overlayEl.querySelector("#booking-pay-proof").value = "";
        hint.textContent = methods.length
          ? "Pay the owner outside the site, then upload a screenshot of your payment."
          : "The owner has not set any payment methods yet. Please message the owner.";
      }
      box.dataset.key = key;
      btn.disabled = true;
      syncPayButton();
      return;
    }

    formPart.hidden = true;
    done.hidden = false;
    box.dataset.key = key;

    const proof = booking.proof_image
      ? `<a href="${escapeHtml(booking.proof_image)}" target="_blank" rel="noopener"><img class="booking-payment__proof" src="${escapeHtml(booking.proof_image)}" alt="Your proof of payment" /></a>`
      : "";
    const status =
      state === "paid"
        ? `<p class="booking-payment__status is-paid">Payment confirmed by the owner.</p>`
        : `<p class="booking-payment__status">Waiting for the owner to confirm your payment.</p>`;

    done.innerHTML =
      `<p class="booking-payment__method">Paid via <strong>${escapeHtml(booking.payment_method || "—")}</strong></p>` +
      proof + status;

    btn.disabled = true;
    btn.classList.add("is-requested");
    btn.textContent = state === "paid" ? "Successfully booked ✓" : "Payment pending";
  }

  async function shrinkImage(file) {
    if (file.size < 1500000) return file;
    try {
      const bmp = await createImageBitmap(file);
      const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(bmp.width * scale);
      canvas.height = Math.round(bmp.height * scale);
      canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.85));
      if (blob && blob.size < file.size) return new File([blob], "proof.jpg", { type: "image/jpeg" });
    } catch (e) {}
    return file;
  }

  async function submitPayment() {
    const method = overlayEl.querySelector("#booking-pay-method").value;
    const fileInput = overlayEl.querySelector("#booking-pay-proof");
    const btn = formEl.querySelector(".booking-submit-block");

    if (!method || !fileInput.files.length || !activeApproved) return;

    btn.disabled = true;
    btn.classList.add("is-loading");
    btn.textContent = "Sending…";

    const formData = new FormData();
    formData.append("booking_id", activeApproved.booking_id);
    formData.append("method", method);
    formData.append("proof_file", await shrinkImage(fileInput.files[0]));

    try {
      const response = await fetch("api/submit-payment.php", { method: "POST", body: formData });
      const data = await response.json();
      if (!data.success) throw new Error(data.message || "Could not send your payment.");

      await loadRequestedIds();
      applyRequestedState();
    } catch (error) {
      btn.classList.remove("is-loading");
      btn.textContent = "Already paid";
      syncPayButton();
      alert(error.message);
    }
  }

  // ---------- Owner view, proofs of payment for this property ----------

  async function loadOwnerPayments(property) {
    const panel = overlayEl.querySelector(".booking-owner-pay");
    if (currentUserId === null || Number(property.ownerId) !== currentUserId) {
      panel.hidden = true;
      return;
    }

    try {
      const response = await fetch("api/owner-bookings.php");
      const data = await response.json();
      if (currentProperty !== property) return;
      if (!data.success) throw new Error();

      const pending = data.bookings.filter(
        (b) => Number(b.property_id) === Number(property.id) && b.booking_status === "pending"
      ).length;
      const ownBtn = formEl.querySelector(".booking-submit-block");
      ownBtn.dataset.pendingCount = String(pending);
      if (property.status !== "rented") ownBtn.textContent = `Pending requests: ${pending}`;

      const rows = data.bookings.filter(
        (b) => Number(b.property_id) === Number(property.id) && b.booking_status === "confirmed"
      );

      if (!rows.length) {
        panel.hidden = true;
        return;
      }

      panel.querySelector(".booking-owner-pay__list").innerHTML = rows
        .map((b) => {
          const proof = b.proof_image
            ? `<a href="${escapeHtml(b.proof_image)}" target="_blank" rel="noopener"><img class="booking-payment__proof" src="${escapeHtml(b.proof_image)}" alt="Proof of payment" /></a>`
            : "";
          let action;
          if (b.payment_state === "proof_sent") {
            action = `<button type="button" class="btn btn--primary booking-owner-pay__confirm" data-booking="${b.booking_id}">Confirm payment</button>`;
          } else if (b.payment_state === "paid") {
            action = `<p class="booking-payment__status is-paid">Payment confirmed ✓</p>`;
          } else {
            action = `<p class="booking-payment__status">Waiting for the renter to upload proof of payment.</p>`;
          }
          const how = b.payment_method ? ` · ${escapeHtml(b.payment_method)}` : "";
          return `
            <div class="booking-owner-pay__item">
              <div class="booking-owner-pay__head">
                <strong>${escapeHtml(b.guest_name)}</strong>
                <span>₱ ${peso.format(Number(b.total_amount))}${how}</span>
              </div>
              ${proof}
              ${action}
            </div>`;
        })
        .join("");
      panel.hidden = false;
    } catch (error) {
      panel.hidden = true;
    }
  }

  async function handleConfirmPayment(e) {
    const btn = e.target.closest(".booking-owner-pay__confirm");
    if (!btn) return;

    btn.disabled = true;
    btn.textContent = "Confirming…";

    const formData = new FormData();
    formData.append("booking_id", btn.dataset.booking);

    try {
      const response = await fetch("api/confirm-payment.php", { method: "POST", body: formData });
      const data = await response.json();
      if (!data.success) throw new Error(data.message || "Could not confirm the payment.");
      await loadOwnerPayments(currentProperty);
    } catch (error) {
      btn.disabled = false;
      btn.textContent = "Confirm payment";
      alert(error.message);
    }
  }

  async function showApprovedView(booking) {
    const monthly = isMonthly(currentProperty);
    activeApproved = booking;

    overlayEl.querySelector("#booking-name").value = currentUserName;
    overlayEl.querySelector("#booking-guests").value = booking.guests;
    overlayEl.querySelector("#booking-checkin").value = booking.check_in;
    overlayEl.querySelector("#booking-checkout").value = monthly ? "" : booking.check_out || "";

    updateSummary();
    overlayEl.querySelector("#booking-total").textContent = `₱ ${peso.format(Number(booking.total_amount))}`;

    setInputsLocked(true);

    // Instead of "Request to Book", payment step, pending, or successfully booked.
    renderPayment(booking);

    const box = overlayEl.querySelector(".booking-approved");
    const paid = booking.payment_state === "paid";
    box.querySelector(".booking-approved__head strong").textContent = paid ? "Successfully booked" : "Property approved";
    box.querySelector(".booking-approved__head p").textContent = paid
      ? "Your payment was confirmed. You can message the owner."
      : "You can now message the owner.";
    const list = box.querySelector(".booking-approved__contact");
    box.hidden = false;
    list.innerHTML = `<li class="booking-approved__loading">Loading owner contact…</li>`;

    const shownFor = currentProperty;
    try {
      const response = await fetch("api/booking-contact.php?booking_id=" + encodeURIComponent(booking.booking_id));
      const data = await response.json();
      if (currentProperty !== shownFor) return;
      if (!data.success) throw new Error(data.message);

      const c = data.contact;
      const rows = [];
      if (c.phone) rows.push(`<li><span>Number</span><a href="tel:${escapeHtml(c.phone)}">${escapeHtml(c.phone)}</a></li>`);
      if (c.email) rows.push(`<li><span>Email</span><a href="mailto:${escapeHtml(c.email)}">${escapeHtml(c.email)}</a></li>`);
      if (c.facebook) {
        const href = facebookHref(c.facebook);
        rows.push(
          href
            ? `<li><span>Facebook</span><a href="${escapeHtml(href)}" target="_blank" rel="noopener">${escapeHtml(c.facebook)}</a></li>`
            : `<li><span>Facebook</span><span>${escapeHtml(c.facebook)}</span></li>`
        );
      }
      list.innerHTML = rows.join("");
    } catch (error) {
      if (currentProperty === shownFor) {
        list.innerHTML = `<li class="booking-approved__loading">Owner contact is unavailable right now.</li>`;
      }
    }
  }

  function applyRequestedState() {
    if (!formEl || !currentProperty) return;

    const submitBtn = formEl.querySelector(".booking-submit-block");

    // The owner can never book their own property, show the pending request count instead.
    if (currentUserId !== null && Number(currentProperty.ownerId) === currentUserId) {
      hideApprovedView();
      setInputsLocked(true);
      submitBtn.disabled = true;
      submitBtn.classList.remove("is-loading");
      submitBtn.classList.add("is-requested");
      if (currentProperty.status === "rented") {
        submitBtn.textContent = "Currently rented";
      } else if (!submitBtn.dataset.pendingCount) {
        submitBtn.textContent = "Pending requests: …";
      }
      return;
    }

    const approved = confirmedByProperty.get(String(currentProperty.id));
    if (approved) {
      showApprovedView(approved);
      return;
    }
    hideApprovedView();

    const already = requestedIds.has(String(currentProperty.id));

    // A rented property cannot be requested by anyone new.
    if (currentProperty.status === "rented" && !already) {
      setInputsLocked(true);
      submitBtn.disabled = true;
      submitBtn.classList.add("is-requested");
      submitBtn.textContent = "Currently rented";
      return;
    }

    submitBtn.disabled = already;
    submitBtn.classList.toggle("is-requested", already);
    submitBtn.textContent = already
      ? "Already requested"
      : submitBtn.dataset.originalLabel || "Request to Book";
  }

  function updateSummary() {
    if (!currentProperty) return { nights: 0, total: 0, valid: false };

    const checkin = overlayEl.querySelector("#booking-checkin").value;
    const checkout = overlayEl.querySelector("#booking-checkout").value;
    const nightsLabel = overlayEl.querySelector("#booking-nights-label");
    const rateEl = overlayEl.querySelector("#booking-nights-rate");
    const totalEl = overlayEl.querySelector("#booking-total");
    const errorEl = overlayEl.querySelector("#booking-date-error");

    // Monthly rentals: move-in date only, billed per month, no check-out.
    if (isMonthly(currentProperty)) {
      const monthlyRent = Math.round(currentProperty.price);

      errorEl.classList.remove("is-visible");
      nightsLabel.textContent = "First month's rent";
      rateEl.textContent = `₱ ${peso.format(monthlyRent)} per month`;
      totalEl.textContent = `₱ ${peso.format(monthlyRent)}`;

      return { nights: 0, total: monthlyRent, valid: Boolean(checkin) };
    }

    let nights = 0;
    let datesValid = true;

    if (checkin && checkout) {
      const diffDays = Math.round((new Date(checkout) - new Date(checkin)) / (1000 * 60 * 60 * 24));
      if (diffDays > MAX_DAILY_NIGHTS) {
        datesValid = false;
        errorEl.textContent = `Daily stays can be up to ${MAX_DAILY_NIGHTS} nights (1 month) only.`;
        errorEl.classList.add("is-visible");
      } else if (diffDays > 0) {
        nights = diffDays;
        errorEl.classList.remove("is-visible");
      } else {
        datesValid = false;
        errorEl.textContent = "Check-out must be after check-in.";
        errorEl.classList.add("is-visible");
      }
    }

    const nightlyRate = currentProperty.price;
    const total = Math.round(nightlyRate * nights);

    nightsLabel.textContent = `${nights} night${nights === 1 ? "" : "s"}`;
    rateEl.textContent = `₱ ${peso.format(Math.round(nightlyRate))} per day`;
    totalEl.textContent = `₱ ${peso.format(total)}`;

    return { nights, total, valid: datesValid && nights > 0 };
  }

async function handleSubmit(e) {

  e.preventDefault();

  if (activeApproved) {
    if (activeApproved.payment_state === "awaiting_proof") submitPayment();
    return;
  }

    try {
    const response = await fetch("api/session.php");
    const data = await response.json();

    if (!data.loggedIn) {
      window.location.href = "login.html";
      return;
    }
  } catch (error) {
    alert("Unable to verify your login. Please try again.");
    return;
  }

  const nameInput = overlayEl.querySelector("#booking-name");
  const guestsInput = overlayEl.querySelector("#booking-guests");
  const checkinInput = overlayEl.querySelector("#booking-checkin");
  const checkoutInput = overlayEl.querySelector("#booking-checkout");

  const monthly = isMonthly(currentProperty);

  const name = nameInput.value.trim();
  const guests = guestsInput.value;
  const checkin = checkinInput.value;
  const checkout = monthly ? "" : checkoutInput.value;
  const summary = updateSummary();

  if (!name) {
    nameInput.focus();
    return;
  }

  if (monthly && !checkin) {
    checkinInput.focus();
    return;
  }

  if (!monthly && (!checkin || !checkout || !summary.valid)) {
    overlayEl.querySelector("#booking-date-error").classList.add("is-visible");
    return;
  }

  openTerms();
}

// Runs after the renter ticks the boxes and confirms in the Terms pop-up.
async function sendBooking() {

  const nameInput = overlayEl.querySelector("#booking-name");
  const guestsInput = overlayEl.querySelector("#booking-guests");
  const checkinInput = overlayEl.querySelector("#booking-checkin");
  const checkoutInput = overlayEl.querySelector("#booking-checkout");

  const monthly = isMonthly(currentProperty);

  const name = nameInput.value.trim();
  const guests = guestsInput.value;
  const checkin = checkinInput.value;
  const checkout = monthly ? "" : checkoutInput.value;

  const submitBtn = formEl.querySelector(".booking-submit-block");
  const originalLabel = submitBtn.dataset.originalLabel || "Request to Book";

  submitBtn.dataset.originalLabel = originalLabel;
  submitBtn.disabled = true;
  submitBtn.classList.add("is-loading");
  submitBtn.textContent = "Processing…";

  const formData = new FormData();

  formData.append("property_id", currentProperty.id);
  formData.append("check_in", checkin);
  if (!monthly) formData.append("check_out", checkout);
  formData.append("guests", guests);

  try {
    const response = await fetch("api/create-booking.php", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.message || "Failed to create booking.");
    }

    submitBtn.disabled = false;
    submitBtn.classList.remove("is-loading");
    submitBtn.textContent = originalLabel;

    requestedIds.add(String(currentProperty.id));

    formEl.hidden = true;
    resultEl.hidden = false;

    resultEl.querySelector(".booking-confirmation__summary").textContent =
      monthly
        ? `${name} · ${guests} guest${Number(guests) > 1 ? "s" : ""} · Move-in ${formatDate(checkin)} · ₱ ${peso.format(Number(data.total_amount))} first month's rent`
        : `${name} · ${guests} guest${Number(guests) > 1 ? "s" : ""} · ${formatDate(checkin)} → ${formatDate(checkout)} · ₱ ${peso.format(Number(data.total_amount))} total`;

  } catch (error) {
    submitBtn.disabled = false;
    submitBtn.classList.remove("is-loading");
    submitBtn.textContent = originalLabel;

    alert(error.message);
  }
}

  function isMonthly(property) {
    return Boolean(property) && property.priceUnit === "monthly";
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[c]));
  }

  const checkIcon = `<svg class="amenity-icon amenity-icon--yes" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>`;
  const crossIcon = `<svg class="amenity-icon amenity-icon--no" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>`;
  const parkingIcon = `<svg class="amenity-icon amenity-icon--info" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.5 16.5v-9h3.2a2.7 2.7 0 0 1 0 5.4H9.5"/></svg>`;

  function renderAmenities(property) {
    const items = [];

    if (property.pets) {
      if (property.pets.allowed) {
        const note = property.pets.conditions
          ? ` <span class="amenity-note">(${escapeHtml(property.pets.conditions)})</span>`
          : "";
        items.push(`<li>${checkIcon}<span>Pets allowed${note}</span></li>`);
      } else {
        items.push(`<li>${crossIcon}<span>Pets not allowed</span></li>`);
      }
    }

    if (property.parking && property.parking.nearby) {
      const fee = property.parking.fee ? ` <span class="amenity-note">(${escapeHtml(property.parking.fee)})</span>` : "";
      items.push(`<li>${parkingIcon}<span>Parking nearby${fee}</span></li>`);
    }

    return items.join("");
  }

  const FACILITY_LABELS = {
    aircon: "Air conditioning",
    heating: "Heating (water heating)",
    refrigerator: "Refrigerator",
    microwave: "Microwave",
    washing_machine: "Automatic washing machine",
    tv: "TV",
  };

  function renderFacilities(property) {
    const labels = [];

    const internet = (property.bills && property.bills.internet) || "separate";
    if (internet !== "none") labels.push("Wi-Fi");

    (property.amenities || []).forEach((key) => {
      if (FACILITY_LABELS[key]) labels.push(FACILITY_LABELS[key]);
    });

    return labels
      .map((label) => `<li>${checkIcon}<span>${label}</span></li>`)
      .join("");
  }

  const BILL_LABELS = { electricity: "Electricity", water: "Water", internet: "Internet" };

  const BILL_STATUS = {
    included: { text: "Covered by Rent", cls: "is-included" },
    separate: { text: "Paid Separately", cls: "is-separate" },
    none: { text: "Not available", cls: "is-none" },
  };

  function renderBills(property) {
    const bills = property.bills || {};

    return Object.keys(BILL_LABELS)
      .map((key) => {
        const status = BILL_STATUS[bills[key]] || BILL_STATUS.separate;
        return `
        <div class="booking-summary__bill">
          <span>${BILL_LABELS[key]}</span>
          <span class="${status.cls}">${status.text}</span>
        </div>`;
      })
      .join("");
  }

  function separateBills(property) {
    const bills = property.bills || {};
    return Object.keys(BILL_LABELS)
      .filter((key) => (bills[key] || "separate") === "separate")
      .map((key) => BILL_LABELS[key]);
  }

  function joinNames(names) {
    if (names.length <= 1) return names.join("");
    return names.slice(0, -1).join(", ") + " and " + names[names.length - 1];
  }

  function updateBillsNote(property) {
    const separate = separateBills(property);
    const noteEl = overlayEl.querySelector("#booking-bills-note");
    const totalLabel = overlayEl.querySelector("#booking-total-label");
    const period = isMonthly(property) ? "monthly rent" : "daily rate";

    if (separate.length === 0) {
      totalLabel.textContent = "Estimated total";
      noteEl.hidden = true;
      return;
    }

    totalLabel.textContent = "Total";
    noteEl.textContent =
      `${joinNames(separate)} ${separate.length > 1 ? "are" : "is"} not included in the ${period}. ` +
      `Final utility costs may vary depending on usage and applicable rates.`;
    noteEl.hidden = false;
  }

  function formatDate(iso) {
    return new Date(iso).toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
  }

  function open(property) {
    if (!overlayEl) buildDom();
    currentProperty = property;

    formEl.hidden = false;
    resultEl.hidden = true;
    formEl.reset();
    hideApprovedView();
    overlayEl.querySelector(".booking-owner-pay").hidden = true;

    const submitBtn = formEl.querySelector(".booking-submit-block");
    delete submitBtn.dataset.pendingCount;
    submitBtn.disabled = false;
    submitBtn.classList.remove("is-loading");
    submitBtn.textContent = submitBtn.dataset.originalLabel || "Request to Book";

    const monthly = isMonthly(property);
    overlayEl.querySelector("#booking-checkin-label").textContent = monthly ? "Move-in date" : "Check-in";
    overlayEl.querySelector("#booking-checkout-field").hidden = monthly;
    overlayEl.querySelector("#booking-date-row").classList.toggle("booking-field-row--two", monthly);

    const today = new Date().toISOString().slice(0, 10);
    const checkin = overlayEl.querySelector("#booking-checkin");
    const checkout = overlayEl.querySelector("#booking-checkout");
    checkin.min = today;
    checkin.value = "";
    checkout.min = today;
    checkout.removeAttribute("max");
    checkout.value = "";
    overlayEl.querySelector("#booking-guests").value = 1;
    overlayEl.querySelector("#booking-date-error").classList.remove("is-visible");

    overlayEl.querySelector(".booking-modal__image").src = property.image;
    overlayEl.querySelector(".booking-modal__image").alt = property.title;
    overlayEl.querySelector(".booking-modal__badge").textContent = property.badge;
    overlayEl.querySelector(".booking-modal__code").textContent = property.code;
    overlayEl.querySelector(".booking-modal__title").textContent = property.title;
    overlayEl.querySelector(".booking-modal__location").textContent = property.location;
    overlayEl.querySelector(".booking-modal__price").innerHTML =
      `₱ ${peso.format(property.price)} <span>/ ${property.priceUnit}</span>`;

    const specsWrap = overlayEl.querySelector(".booking-modal__specs");
    specsWrap.innerHTML = [
      property.specs.beds ? `<span>${property.specs.beds} Bed${property.specs.beds > 1 ? "s" : ""}</span>` : "",
      property.specs.baths ? `<span>${property.specs.baths} Bath${property.specs.baths > 1 ? "s" : ""}</span>` : "",
      property.specs.area ? `<span>${property.specs.area}</span>` : "",
    ]
      .filter(Boolean)
      .join("");

    const tagsWrap = overlayEl.querySelector(".booking-modal__tags");
    const tags = property.tags || [];
    tagsWrap.innerHTML = tags
      .map(
        (tag) =>
          `<button type="button" class="tag-chip" data-tag="${escapeHtml(tag)}">${escapeHtml(tag)}</button>`
      )
      .join("");
    tagsWrap.hidden = tags.length === 0;

    overlayEl.querySelector(".booking-modal__amenities").innerHTML = renderAmenities(property);

    const facilitiesHtml = renderFacilities(property);
    overlayEl.querySelector(".booking-modal__facilities").innerHTML = facilitiesHtml;
    overlayEl.querySelector(".booking-modal__facilities-wrap").hidden = !facilitiesHtml;

    overlayEl.querySelector("#booking-bills").innerHTML = renderBills(property);
    updateBillsNote(property);

    updateSummary();

    applyRequestedState();
    if (!confirmedByProperty.has(String(property.id)) && !requestedIds.has(String(property.id))) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Checking…";
    }
    // always refresh, so an approval that just happened shows up
    loadRequestedIds().then(() => {
      if (currentProperty === property && !formEl.hidden) applyRequestedState();
      if (currentProperty === property) loadOwnerPayments(property);
    });

    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => overlayEl.classList.add("is-open"));
  }
  
  function close() {
    if (!overlayEl) return;
    overlayEl.classList.remove("is-open");
    closeTerms();
    document.body.style.overflow = "";
  }

  return { open, close };
})();