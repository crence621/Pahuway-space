const DashboardSection = (() => {

let currentUser = null;


async function renderProfile() {
  try {
    const response = await fetch("api/session.php");

    const data = await response.json();

    if (!data.loggedIn) {
      window.location.href = "login.html";
      return;
    }

    currentUser = data.user;

    const name = data.user.full_name;
    const email = data.user.email;

    const isAdmin = data.user.account_type === "admin";

    const badgeEl = document.getElementById("dashboard-profile-badge");
    if (badgeEl) {
      if (isAdmin) {
        badgeEl.textContent = "Administrator";
      } else if (data.user.member_type === "owner") {
        badgeEl.textContent = "Verified owner";
      } else {
        badgeEl.textContent = "Verified renter";
      }
    }

    // Account-setup info (mobile number, facebook)
    const phoneEl = document.getElementById("dashboard-user-phone");
    if (phoneEl) {
      phoneEl.hidden = !data.user.phone;
      phoneEl.textContent = data.user.phone ? "Mobile: " + data.user.phone : "";
    }

    const fbEl = document.getElementById("dashboard-user-facebook");
    if (fbEl) {
      const fb = (data.user.facebook || "").trim();
      fbEl.hidden = !fb;
      fbEl.textContent = "";
      if (fb) {
        fbEl.append("Facebook: ");
        let href = "";
        if (/^https?:\/\//i.test(fb)) href = fb;
        else if (/(facebook|fb)\.com/i.test(fb)) href = "https://" + fb.replace(/^\/+/, "");
        else if (/^[A-Za-z0-9.]+$/.test(fb)) href = "https://facebook.com/" + fb;
        if (href) {
          const a = document.createElement("a");
          a.href = href;
          a.target = "_blank";
          a.rel = "noopener";
          a.textContent = fb;
          fbEl.appendChild(a);
        } else {
          fbEl.append(fb);
        }
      }
    }

    // Admin Panel button: only ever shown to admins; removed from the page for everyone else.
    const adminBtn = document.getElementById("dashboard-admin-btn");
    if (adminBtn) {
      if (isAdmin) {
        adminBtn.hidden = false;
      } else {
        adminBtn.remove();
      }
    }

    const nameEl = document.getElementById("dashboard-user-name");
    const emailEl = document.getElementById("dashboard-user-email");
    const avatarEl = document.getElementById("dashboard-user-avatar");

    if (nameEl) {
      nameEl.textContent = name;
    }

    if (emailEl) {
      emailEl.textContent = email;
    }

    if (avatarEl) {
      avatarEl.textContent = name
        .split(" ")
        .map((n) => n[0])
        .slice(0, 2)
        .join("")
        .toUpperCase();
    }

  } catch (error) {
    console.error("Session check failed:", error);
    window.location.href = "login.html";
  }
}

  async function renderFavorites() {
    const grid = document.getElementById("dashboard-favorites-grid");
    const emptyState = document.getElementById("dashboard-favorites-empty");
    const countEl = document.getElementById("dashboard-favorites-count");
    if (!grid) return;

    const [near, featured, rented] = await Promise.all([
      PahuwaySpaceData.getPropertiesNearYou(),
      PahuwaySpaceData.getFeaturedNewProperties(),
      PahuwaySpaceData.getRecentlyRentedProperties(),
    ]);

    const allProperties = [...near, ...featured, ...rented];

    let favoriteIds = new Set();

    try {
      const response = await fetch("api/favorites.php");
      const data = await response.json();

      if (data.success) {
        favoriteIds = new Set(data.favorites.map(Number));
      }
    } catch (error) {
      console.error("Failed to load favorites:", error);
    }

    const favorited = allProperties.filter((p) =>
      favoriteIds.has(Number(p.id))
    );

    if (countEl) countEl.textContent = String(favorited.length);
    grid.innerHTML = "";

    if (favorited.length === 0) {
      if (emptyState) emptyState.hidden = false;
      return;
    }
    if (emptyState) emptyState.hidden = true;

    favorited.forEach((property) => {
      const card = PropertyCard.render(property, {
        favorited: true,
        onToggleFavorite: async (id, isFav) => {
          const formData = new FormData();
          formData.append("property_id", id);
          formData.append("action", isFav ? "add" : "remove");

          try {
            const response = await fetch("api/favorites.php", {
              method: "POST",
              body: formData
            });

            const data = await response.json();

            if (!data.success) {
              alert(data.message);
              return;
            }

            if (!isFav) {
              card.remove();
              if (countEl) countEl.textContent = String(grid.children.length);

              if (!grid.children.length && emptyState) {
                emptyState.hidden = false;
              }
            }
          } catch (error) {
            console.error("Favorite update error:", error);
            alert("Unable to update favorite.");
          }
        },
        onOpenDetails: (p) => {
          if (typeof BookingModal !== "undefined") BookingModal.open(p);
        },
      });
      grid.appendChild(card);
    });
  }

  // Clicking an owner card (not its buttons) opens that property.
  function bindOpenProperty(listId) {
    const list = document.getElementById(listId);
    if (!list || list.dataset.openBound) return;
    list.dataset.openBound = "1";
    list.addEventListener("click", async (e) => {
      if (e.target.closest("button, a")) return;
      const card = e.target.closest("[data-property-id]");
      if (!card || typeof BookingModal === "undefined") return;
      try {
        const all = await PahuwaySpaceData.getAllProperties();
        const property = all.find((p) => String(p.id) === card.dataset.propertyId);
        if (property) BookingModal.open(property);
      } catch (err) {
        console.error(err);
      }
    });
  }

  async function init() {
    bindOpenProperty("dashboard-owner-bookings-list");
    bindOpenProperty("dashboard-owner-properties-list");
    window.addEventListener("pahuway:setup-complete", renderProfile);
    await renderProfile();
    renderFavorites();
    loadBookings();
    loadOwnerBookings();
    loadOwnerProperties();
  }

  async function loadBookings() {
  const list = document.getElementById("dashboard-bookings-list");
  const empty = document.getElementById("dashboard-bookings-empty");
  const count = document.getElementById("dashboard-bookings-count");

  if (!list) return;

  try {
    const response = await fetch("api/bookings.php");
    const data = await response.json();

    if (!data.success) {
      throw new Error(data.message || "Failed to load bookings.");
    }

    count.textContent = data.bookings.length;

    if (data.bookings.length === 0) {
      list.innerHTML = "";
      empty.hidden = false;
      return;
    }

    empty.hidden = true;

    list.innerHTML = data.bookings.map((booking) => {
      const status = booking.booking_status.charAt(0).toUpperCase() +
        booking.booking_status.slice(1);

      return `
        <article class="dashboard-booking-card" data-property-id="${booking.property_id}" title="View property details">
          <div class="dashboard-booking-card__image">
            <img src="${booking.image}" alt="${booking.title}">
          </div>

          <div class="dashboard-booking-card__content">
            <span class="dashboard-booking-card__code">${booking.property_code}</span>
            <h3>${booking.title}</h3>
            <p>${booking.location}</p>

            <div class="dashboard-booking-card__details">
              <span>${formatBookingPeriod(booking)}</span>
              <span>${booking.guests} guest${booking.guests > 1 ? "s" : ""}</span>
              <span>${formatBookingLength(booking)}</span>
            </div>
          </div>

          <div class="dashboard-booking-card__side">
            <span class="dashboard-booking-card__status status-${booking.booking_status}">
              ${status}
            </span>
            <strong>₱ ${Number(booking.total_amount).toLocaleString("en-PH")}</strong>
          </div>
        </article>
      `;
    }).join("");

    if (!list.dataset.clickBound) {
      list.dataset.clickBound = "1";
      list.addEventListener("click", async (e) => {
        const card = e.target.closest("[data-property-id]");
        if (!card || typeof BookingModal === "undefined") return;
        try {
          const all = await PahuwaySpaceData.getAllProperties();
          const property = all.find((p) => String(p.id) === card.dataset.propertyId);
          if (property) BookingModal.open(property);
        } catch (err) {
          console.error(err);
        }
      });
    }

  } catch (error) {
    list.innerHTML = `<p>Unable to load your bookings.</p>`;
    console.error(error);
  }
}

async function loadOwnerBookings() {
  const list = document.getElementById("dashboard-owner-bookings-list");
  const empty = document.getElementById("dashboard-owner-bookings-empty");
  const count = document.getElementById("owner-bookings-count");

  if (!list) return;

  try {
    const response = await fetch("api/owner-bookings.php");
    const data = await response.json();

    if (!data.success) {
      throw new Error(data.message || "Failed to load booking requests.");
    }

    count.textContent = data.bookings.length;

    if (data.bookings.length === 0) {
      list.innerHTML = "";
      empty.hidden = false;
      return;
    }

    empty.hidden = true;

    list.innerHTML = data.bookings.map((booking) => {
      const status =
        booking.booking_status.charAt(0).toUpperCase() +
        booking.booking_status.slice(1);

      return `
        <article class="dashboard-owner-booking-card" data-property-id="${booking.property_id}" title="View property and payments">
          <div class="dashboard-owner-booking-card__image">
            <img src="${booking.image}" alt="${booking.title}">
          </div>

          <div class="dashboard-owner-booking-card__content">
            <span class="dashboard-owner-booking-card__code">
              ${booking.property_code}
            </span>

            <h3>${booking.title}</h3>
            <p>${booking.location}</p>

            <div class="dashboard-owner-booking-card__guest">
              <strong>Guest</strong>
              <span>${booking.guest_name}</span>
              <span>${booking.guest_email}</span>
            </div>

            <div class="dashboard-owner-booking-card__details">
              <span>${formatBookingPeriod(booking)}</span>
              <span>${booking.guests} guest${booking.guests > 1 ? "s" : ""}</span>
              <span>${formatBookingLength(booking)}</span>
            </div>
          </div>

          <div class="dashboard-owner-booking-card__side">
            <span class="dashboard-owner-booking-card__status status-${booking.booking_status}">
              ${status}
            </span>

            <strong>₱ ${Number(booking.total_amount).toLocaleString("en-PH")}</strong>

            ${
              booking.booking_status === "pending"
                ? `
                  <div class="dashboard-owner-booking-card__actions">
                    <button type="button" onclick="updateOwnerBookingStatus(${booking.booking_id}, 'confirmed')">Confirm</button>
                    <button type="button" onclick="updateOwnerBookingStatus(${booking.booking_id}, 'cancelled')">Cancel</button>
                  </div>
                `
                : ""
            }
          </div>
        </article>
      `;
    }).join("");

  } catch (error) {
    list.innerHTML = `<p>Unable to load booking requests.</p>`;
    console.error(error);
  }
}

function formatBookingPeriod(booking) {
  if (booking.price_unit === "monthly" || !booking.check_out) {
    return `Move-in: ${formatBookingDate(booking.check_in)}`;
  }

  return `${formatBookingDate(booking.check_in)} → ${formatBookingDate(booking.check_out)}`;
}

function formatBookingLength(booking) {
  if (booking.price_unit === "monthly" || !booking.check_out) {
    return "Monthly rental";
  }

  return `${booking.nights} night${booking.nights > 1 ? "s" : ""}`;
}

function formatBookingDate(date) {
  return new Date(date + "T00:00:00").toLocaleDateString("en-PH", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

window.updateOwnerBookingStatus = async function(bookingId, status) {
  console.log("UPDATE CLICKED", bookingId, status);

  const formData = new FormData();
  formData.append("booking_id", bookingId);
  formData.append("status", status);

  try {
    const response = await fetch("api/update-booking-status.php", {
      method: "POST",
      body: formData
    });

    console.log("RESPONSE STATUS:", response.status);

    const text = await response.text();
    console.log("RESPONSE:", text);

    const data = JSON.parse(text);

    if (!data.success) {
      alert(data.message);
      return;
    }

    alert("Booking updated!");
    loadOwnerBookings();
    loadBookings();

  } catch (error) {
    console.error("UPDATE ERROR:", error);
    alert("Unable to update booking.");
  }
}

async function loadOwnerProperties() {
  const list = document.getElementById("dashboard-owner-properties-list");
  const empty = document.getElementById("dashboard-owner-properties-empty");
  const count = document.getElementById("owner-properties-count");

  if (!list) return;

  try {
    const response = await fetch("api/owner-properties.php");
    const data = await response.json();

    if (!data.success) throw new Error(data.message);

    count.textContent = data.properties.length;

    if (data.properties.length === 0) {
      list.innerHTML = "";
      empty.hidden = false;
      return;
    }

    empty.hidden = true;

    list.innerHTML = data.properties.map(property => `
      <article class="dashboard-owner-property-card" data-property-id="${property.property_id}" title="View property">
        <div class="dashboard-owner-property-card__image">
          <img src="${
            property.image.startsWith("assets/")
              ? property.image
              : `assets/images/${property.image}`
          }" alt="${property.title}">
        </div>

        <div>
          <span>${property.property_code}</span>
          <h3>${property.title}</h3>
          <p>${property.location}</p>
          <strong>₱ ${Number(property.price).toLocaleString("en-PH")}</strong>
        </div>

        <div class="dashboard-owner-property-card__actions">
          <span class="dashboard-owner-property-card__status status-${property.status}">
            ${property.status}
          </span>

          <button type="button"
            class="dashboard-owner-property-card__edit"
            onclick="window.location.href='list-property.html?edit=${property.property_id}'">
            Edit
          </button>

          <button type="button"
            onclick="updatePropertyStatus(${property.property_id}, '${property.status === "available" ? "rented" : "available"}')">
            Mark as ${property.status === "available" ? "Rented" : "Available"}
          </button>

          <button type="button"
            class="dashboard-owner-property-card__delete"
            onclick="deleteProperty(${property.property_id}, this.dataset.title)"
            data-title="${String(property.title).replace(/&/g, "&amp;").replace(/"/g, "&quot;")}">
            Delete
          </button>
        </div>
      </article>
    `).join("");

  } catch (error) {
    list.innerHTML = `<p>Unable to load your properties.</p>`;
    console.error(error);
  }
}

window.updatePropertyStatus = async function(propertyId, status) {
  const formData = new FormData();
  formData.append("property_id", propertyId);
  formData.append("status", status);

  try {
    const response = await fetch("api/update-property-status.php", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (!data.success) {
      alert(data.message);
      return;
    }

    loadOwnerProperties();
  } catch (error) {
    console.error(error);
    alert("Unable to update property.");
  }
};

window.deleteProperty = async function(propertyId, title) {
  const confirmed = confirm(
    `Are you sure you want to delete "${title}"?\n\nThis permanently removes the property and cannot be undone.`
  );

  if (!confirmed) return;

  const formData = new FormData();
  formData.append("property_id", propertyId);

  try {
    const response = await fetch("api/delete-property.php", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (!data.success) {
      alert(data.message);
      return;
    }

    alert("Property deleted.");
    loadOwnerProperties();
  } catch (error) {
    console.error(error);
    alert("Unable to delete property.");
  }
};

return { init };

})();