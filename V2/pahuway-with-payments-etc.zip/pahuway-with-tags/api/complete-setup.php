<?php

session_start();
require_once "db.php";
require_once "profile_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$phone = trim($_POST["phone"] ?? "");
$facebook = trim($_POST["facebook"] ?? "");
$member_type = $_POST["member_type"] ?? "";

if ($phone === "") {
    echo json_encode(["success" => false, "message" => "Please enter your mobile number."]);
    exit;
}

// digits with optional + ( ) - and spaces, 7 to 15 digits
$digits = preg_replace("/\D/", "", $phone);
if (!preg_match('/^[0-9+()\-\s]+$/', $phone) || strlen($digits) < 7 || strlen($digits) > 15 || strlen($phone) > 20) {
    echo json_encode(["success" => false, "message" => "Please enter a valid mobile number."]);
    exit;
}

if (strlen($facebook) > 255) {
    echo json_encode(["success" => false, "message" => "Facebook link is too long."]);
    exit;
}

if (!in_array($member_type, ["renter", "owner"], true)) {
    echo json_encode(["success" => false, "message" => "Please choose renter or owner."]);
    exit;
}

ensure_profile_columns($conn);

$stmt = $conn->prepare("UPDATE users SET phone = ?, facebook = ?, member_type = ? WHERE user_id = ?");
$stmt->bind_param("sssi", $phone, $facebook, $member_type, $user_id);

if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Could not save: " . $stmt->error]);
    exit;
}

$stmt->close();
$conn->close();

echo json_encode(["success" => true, "message" => "Account setup complete."]);

?>
