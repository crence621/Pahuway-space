<?php

session_start();
require_once "db.php";
require_once "profile_helpers.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$booking_id = isset($_GET["booking_id"]) ? (int) $_GET["booking_id"] : 0;

if ($booking_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid booking."]);
    exit;
}

ensure_profile_columns($conn);

/* Only the renter of an APPROVED booking can see the owner's contact details. */
$stmt = $conn->prepare(
    "SELECT owner.full_name, owner.email, owner.phone, owner.facebook
     FROM bookings
     INNER JOIN properties ON properties.property_id = bookings.property_id
     INNER JOIN users AS owner ON owner.user_id = properties.owner_id
     WHERE bookings.booking_id = ?
       AND bookings.user_id = ?
       AND bookings.booking_status = 'confirmed'
     LIMIT 1"
);
$stmt->bind_param("ii", $booking_id, $user_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    echo json_encode(["success" => false, "message" => "Booking not found or not approved."]);
    exit;
}

echo json_encode([
    "success" => true,
    "contact" => [
        "name" => $row["full_name"],
        "email" => $row["email"],
        "phone" => $row["phone"],
        "facebook" => $row["facebook"]
    ]
]);

$conn->close();

?>
