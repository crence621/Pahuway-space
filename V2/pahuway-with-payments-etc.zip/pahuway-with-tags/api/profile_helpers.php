<?php

/*
 * Account-setup fields on the users table: phone, facebook, member_type.
 * Adds the columns automatically if they are missing, so no manual SQL step is
 * needed (add_profile_fields.sql does the same thing by hand if you prefer).
 * No NULLs: '' = not provided, member_type 'unset' = not chosen yet.
 */
function ensure_profile_columns(mysqli $conn): void
{
    $res = $conn->query("SHOW COLUMNS FROM users LIKE 'member_type'");
    if ($res && $res->num_rows > 0) {
        return;
    }

    $conn->query("ALTER TABLE users
        ADD COLUMN phone varchar(20) NOT NULL DEFAULT '',
        ADD COLUMN facebook varchar(255) NOT NULL DEFAULT '',
        ADD COLUMN member_type enum('unset','renter','owner') NOT NULL DEFAULT 'unset'");
}

?>
