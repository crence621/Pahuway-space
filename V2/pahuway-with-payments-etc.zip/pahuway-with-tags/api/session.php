<?php

session_start();

require_once "db.php";
require_once "profile_helpers.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "loggedIn" => false
    ]);
    exit;
}

$user_id = (int) $_SESSION["user_id"];

ensure_profile_columns($conn);

// The role lives in the roles table; it is still sent to the front end as account_type.
$stmt = $conn->prepare(
    "SELECT users.user_id, users.full_name, users.email, roles.role_name AS account_type, users.email_verified, users.phone, users.facebook, users.member_type
     FROM users
     INNER JOIN roles ON roles.role_id = users.role_id
     WHERE users.user_id = ?
     LIMIT 1"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    $_SESSION = [];
    session_destroy();

    echo json_encode([
        "loggedIn" => false
    ]);
    exit;
}

echo json_encode([
    "loggedIn" => true,
    "user" => [
        "user_id" => (int) $user["user_id"],
        "full_name" => $user["full_name"],
        "email" => $user["email"],
        "account_type" => $user["account_type"],
        "email_verified" => (int) $user["email_verified"] === 1,
        "phone" => $user["phone"],
        "facebook" => $user["facebook"],
        "member_type" => $user["member_type"],
        "needs_setup" => $user["phone"] === "" || $user["member_type"] === "unset"
    ]
]);

$conn->close();

?>