<?php

session_start();

require_once "db.php";
require_once "property_helpers.php";
require_once "tag_helpers.php";
require_once "payment_helpers.php";

/*
| Bills: 1 = covered by rent, 0 = paid separately.
| Internet only: 2 = not available (the owner unticked "Has internet",
| so the field is not sent).
*/

function bill_value($value, $allow_none = false)
{
    if ($value === "1") return 1;
    if ($value === "0") return 0;
    return $allow_none ? 2 : 0;
}

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

/*
| Check if user is logged in
*/

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "You must be logged in to edit a property."
    ]);
    exit;
}

$owner_id = (int) $_SESSION["user_id"];
$property_id = isset($_POST["property_id"]) ? (int) $_POST["property_id"] : 0;

if ($property_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid property."
    ]);
    exit;
}

/*
| Make sure the property exists AND belongs to this user
*/

$check = $conn->prepare(
    "SELECT property_id FROM properties WHERE property_id = ? AND owner_id = ?"
);

$check->bind_param("ii", $property_id, $owner_id);
$check->execute();
$check->store_result();

if ($check->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Property not found or you do not own it."
    ]);

    $check->close();
    $conn->close();
    exit;
}

$check->close();

/*
| Get form data (property code and status are NOT editable here)
*/

$property_type = trim($_POST["property_type"] ?? "");
$title = trim($_POST["title"] ?? "");
$location = trim($_POST["location"] ?? "");
$description = trim($_POST["description"] ?? "");
$price = $_POST["price"] ?? "";
$price_unit = $_POST["price_unit"] ?? "monthly";
$bedrooms = $_POST["bedrooms"] ?? 0;
$bathrooms = $_POST["bathrooms"] ?? 0;
$area = trim($_POST["area"] ?? "");
$image = trim($_POST["image"] ?? "");

/*
| Pets and parking (checkboxes: missing = unchecked)
*/

$pets_allowed = isset($_POST["pets_allowed"]) ? 1 : 0;
$pet_conditions = trim($_POST["pet_conditions"] ?? "");
$parking_nearby = isset($_POST["parking_nearby"]) ? 1 : 0;
$parking_fee = $_POST["parking_fee"] ?? "";

if ($pets_allowed === 0 || $pet_conditions === "") {
    $pet_conditions = null;
} else {
    $pet_conditions = mb_substr($pet_conditions, 0, 255);
}

if ($parking_nearby === 1) {
    if (!in_array($parking_fee, ["free", "paid"])) {
        echo json_encode([
            "success" => false,
            "message" => "Please say if the nearby parking is free or paid."
        ]);
        exit;
    }
} else {
    $parking_fee = null;
}

/*
| Bills (1 = covered by rent, 0 = paid separately, 2 = not available)
*/

$electricity_included = bill_value($_POST["electricity_included"] ?? null);
$water_included = bill_value($_POST["water_included"] ?? null);
$internet_included = bill_value($_POST["internet_included"] ?? null, true);

/*
| Amenities & facilities (only known keys are kept)
*/

$allowed_amenities = [
    "aircon", "heating", "refrigerator",
    "microwave", "washing_machine", "tv"
];

$posted_amenities = $_POST["amenities"] ?? [];

if (!is_array($posted_amenities)) {
    $posted_amenities = [];
}

$amenities = array_values(array_intersect($allowed_amenities, $posted_amenities));

/*
| Payment methods the owner accepts (at least one)
*/

$payment_methods = clean_payment_methods($_POST["payment_methods"] ?? []);

if (count($payment_methods) === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Please choose at least one payment method."
    ]);
    exit;
}

ensure_payment_schema($conn);

/*
| Validate required fields
*/

if (
    $property_type === "" ||
    $title === "" ||
    $location === "" ||
    $price === ""
) {
    echo json_encode([
        "success" => false,
        "message" => "Please fill in all required fields."
    ]);
    exit;
}

if (!is_numeric($price) || $price <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid price."
    ]);
    exit;
}

$price = (float) $price;

if (!in_array($price_unit, ["daily", "monthly"])) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid price unit."
    ]);
    exit;
}

if (!is_numeric($bedrooms) || $bedrooms < 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid number of bedrooms."
    ]);
    exit;
}

if (!is_numeric($bathrooms) || $bathrooms < 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid number of bathrooms."
    ]);
    exit;
}

$bedrooms = (int) $bedrooms;
$bathrooms = (int) $bathrooms;

/*
| Tags (nearby places, max 8)
*/

$tags = normalize_tags($_POST["tags"] ?? "");

/*
| Look up the property type
*/

$type_id = property_type_id($conn, $property_type);

if ($type_id === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Please choose a valid property type."
    ]);
    $conn->close();
    exit;
}

/*
| Update property + its amenities, bills and image together.
| (a blank image keeps the current image)
*/

$description = $description === "" ? PH_DESCRIPTION : $description;
$area = $area === "" ? PH_AREA : $area;
$pet_conditions = ($pets_allowed === 1 && (string) $pet_conditions !== "")
    ? (string) $pet_conditions
    : PH_PET_CONDITIONS;

$parking = parking_value($parking_nearby === 1, $parking_fee);
$utilities = [
    "electricity" => $electricity_included,
    "water" => $water_included,
    "internet" => $internet_included
];

$uploaded = null;
$old_image = null;

try {
    $uploaded = handle_image_upload();
    if ($uploaded !== null) {
        $image = $uploaded;

        // remember the current photo so the old file can be removed afterwards
        $cur = db_run(
            $conn,
            "SELECT image_path FROM property_images
              WHERE property_id = ? AND is_primary = 1 LIMIT 1",
            "i",
            [$property_id]
        );
        $curRow = $cur->get_result()->fetch_assoc();
        $cur->close();
        $old_image = $curRow["image_path"] ?? null;
    }

    $conn->begin_transaction();

    $city_id = city_id_for($conn, $location);

    $stmt = db_run(
        $conn,
        "UPDATE properties SET
            type_id = ?,
            title = ?,
            city_id = ?,
            description = ?,
            price = ?,
            price_unit = ?,
            bedrooms = ?,
            bathrooms = ?,
            area = ?,
            pets_allowed = ?,
            pet_conditions = ?,
            parking = ?
         WHERE property_id = ?
           AND owner_id = ?",
        "isisdsiisissii",
        [
            $type_id,
            $title,
            $city_id,
            $description,
            $price,
            $price_unit,
            $bedrooms,
            $bathrooms,
            $area,
            $pets_allowed,
            $pet_conditions,
            $parking,
            $property_id,
            $owner_id
        ]
    );
    $stmt->close();

    save_property_relations($conn, $property_id, $amenities, $utilities, $image);
    save_payment_methods($conn, $property_id, $payment_methods);
    save_property_tags($conn, $property_id, $tags);

    $conn->commit();

    if ($uploaded !== null && $old_image !== $uploaded) {
        delete_uploaded_image($old_image);
    }

    echo json_encode([
        "success" => true,
        "message" => "Property updated successfully.",
        "property_id" => $property_id
    ]);

} catch (Throwable $e) {

    @$conn->rollback();
    delete_uploaded_image($uploaded);
    error_log("[pahuway] update-property: " . $e->getMessage());

    echo json_encode([
        "success" => false,
        "message" => $e instanceof UploadException ? $e->getMessage() : "Failed to update property."
    ]);
}

$conn->close();

?>