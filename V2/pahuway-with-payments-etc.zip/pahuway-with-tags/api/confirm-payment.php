<?php

session_start();
require_once "db.php";
require_once "property_helpers.php";
require_once "payment_helpers.php";

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in."]);
    exit;
}

$owner_id = (int) $_SESSION["user_id"];
$booking_id = isset($_POST["booking_id"]) ? (int) $_POST["booking_id"] : 0;

if ($booking_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid booking."]);
    exit;
}

ensure_payment_schema($conn);

try {
    /* Only the owner of the property, and only an approved booking. */
    $stmt = db_run(
        $conn,
        "SELECT bookings.booking_id
           FROM bookings
           INNER JOIN properties ON properties.property_id = bookings.property_id
          WHERE bookings.booking_id = ?
            AND properties.owner_id = ?
            AND bookings.booking_status = 'confirmed'
          LIMIT 1",
        "ii",
        [$booking_id, $owner_id]
    );
    $ok = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$ok) {
        echo json_encode(["success" => false, "message" => "Booking not found or you do not own this property."]);
        exit;
    }

    $stmt = db_run(
        $conn,
        "SELECT payment_id, payment_status, proof_image
           FROM payments WHERE booking_id = ? ORDER BY payment_id DESC LIMIT 1",
        "i",
        [$booking_id]
    );
    $pay = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$pay || $pay["proof_image"] === "") {
        echo json_encode(["success" => false, "message" => "The renter has not uploaded proof of payment yet."]);
        exit;
    }
    if ($pay["payment_status"] === "paid") {
        echo json_encode(["success" => false, "message" => "This payment is already confirmed."]);
        exit;
    }

    $paid_at = date("Y-m-d H:i:s");
    db_run(
        $conn,
        "UPDATE payments SET payment_status = 'paid', paid_at = ? WHERE payment_id = ?",
        "si",
        [$paid_at, (int) $pay["payment_id"]]
    )->close();

    echo json_encode(["success" => true, "message" => "Payment confirmed."]);

} catch (Throwable $e) {
    error_log("[pahuway] confirm-payment: " . $e->getMessage());
    echo json_encode(["success" => false, "message" => "Could not confirm the payment. Please try again."]);
}

$conn->close();

?>
