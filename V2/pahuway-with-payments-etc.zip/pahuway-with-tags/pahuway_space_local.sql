CREATE DATABASE IF NOT EXISTS `pahuway_space` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `pahuway_space`;

-- =====================================================================
-- Pahuway Space: fresh-install schema (normalized, 3NF, no NULL columns, placeholder values)
-- Target: MariaDB 10.5+ / 11.x, InnoDB, utf8mb4
--
-- Import this into an EMPTY database (phpMyAdmin > Import).
-- To move an existing database over instead, use pahuway_space_normalized.sql
-- (from the original flat tables) or upgrade_placeholders.sql (from the earlier normalized version).
--
-- Tables
--   lookups : roles, property_types, cities, amenities, utilities, payment_methods
--   core    : users, properties, bookings, payments, favorites
--   links   : property_images, property_amenities, property_utilities, tags, property_tags
--
-- No column allows NULL. "Not provided" is stored as a placeholder:
--   description 'No description provided' | area 'N/A' | street_address 'N/A'
--   pet_conditions 'None' | bookings.check_out 'Not checked out' (open-ended monthly stay)
--   payments.method_id -> 'Pending' method | payments.paid_at 'Not paid'
--   (check_out and paid_at are text columns: either a date/time or those words)
--
-- To make your first admin after importing (replace the email):
--   UPDATE users
--      SET role_id = (SELECT role_id FROM roles WHERE role_name = 'admin')
--    WHERE email = 'you@example.com';
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- 1. Lookup tables
-- ---------------------------------------------------------------------
CREATE TABLE `roles` (
  `role_id`   tinyint unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uq_roles_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `property_types` (
  `type_id`   smallint unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL,
  PRIMARY KEY (`type_id`),
  UNIQUE KEY `uq_property_types_name` (`type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `cities` (
  `city_id`   int unsigned NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) NOT NULL,
  PRIMARY KEY (`city_id`),
  UNIQUE KEY `uq_cities_name` (`city_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `amenities` (
  `amenity_id`   smallint unsigned NOT NULL AUTO_INCREMENT,
  `amenity_code` varchar(50) NOT NULL,   -- machine key, same values the app used before
  `amenity_name` varchar(80) NOT NULL,   -- display label
  PRIMARY KEY (`amenity_id`),
  UNIQUE KEY `uq_amenities_code` (`amenity_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `utilities` (
  `utility_id`   tinyint unsigned NOT NULL AUTO_INCREMENT,
  `utility_code` varchar(30) NOT NULL,
  `utility_name` varchar(50) NOT NULL,
  PRIMARY KEY (`utility_id`),
  UNIQUE KEY `uq_utilities_code` (`utility_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payment_methods` (
  `method_id`   tinyint unsigned NOT NULL AUTO_INCREMENT,
  `method_name` varchar(50) NOT NULL,
  PRIMARY KEY (`method_id`),
  UNIQUE KEY `uq_payment_methods_name` (`method_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed data
INSERT INTO `roles` (`role_name`) VALUES ('user'), ('admin');

INSERT INTO `property_types` (`type_name`) VALUES
  ('Apartment'), ('Condominium'), ('House'), ('Townhouse'),
  ('Dormitory'), ('Room'), ('Bed Space');

INSERT INTO `amenities` (`amenity_code`, `amenity_name`) VALUES
  ('aircon',          'Air conditioning'),
  ('heating',         'Heating'),
  ('refrigerator',    'Refrigerator'),
  ('microwave',       'Microwave'),
  ('washing_machine', 'Washing machine'),
  ('tv',              'Television');

INSERT INTO `utilities` (`utility_code`, `utility_name`) VALUES
  ('electricity', 'Electricity'),
  ('water',       'Water'),
  ('internet',    'Internet');

-- 'Pending' = no method chosen yet (placeholder instead of NULL)
INSERT INTO `payment_methods` (`method_name`) VALUES
  ('Pending'), ('Cash'), ('GCash'), ('Maya'), ('Bank Transfer'), ('Credit/Debit Card');

-- ---------------------------------------------------------------------
-- 2. Core tables
-- ---------------------------------------------------------------------
CREATE TABLE `users` (
  `user_id`    int unsigned NOT NULL AUTO_INCREMENT,
  `full_name`  varchar(150) NOT NULL,
  `email`      varchar(150) NOT NULL,
  `password`   varchar(255) NOT NULL,
  `role_id`    tinyint unsigned NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `email_verifications` (
  `user_id`    int unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_email_verifications_token` (`token_hash`),
  CONSTRAINT `fk_email_verifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `properties` (
  `property_id`     int unsigned NOT NULL AUTO_INCREMENT,
  `owner_id`        int unsigned NOT NULL,
  `property_code`   varchar(50) NOT NULL,
  `type_id`         smallint unsigned NOT NULL,
  `city_id`         int unsigned NOT NULL,
  `street_address`  varchar(255) NOT NULL DEFAULT 'N/A',
  `title`           varchar(150) NOT NULL,
  `description`     text NOT NULL DEFAULT 'No description provided',
  `price`           decimal(10,2) NOT NULL,
  `price_unit`      enum('daily','monthly') NOT NULL DEFAULT 'monthly',
  `bedrooms`        tinyint unsigned NOT NULL DEFAULT 0,
  `bathrooms`       tinyint unsigned NOT NULL DEFAULT 0,
  `area`            varchar(50) NOT NULL DEFAULT 'N/A',
  `verified`        tinyint(1) NOT NULL DEFAULT 0,
  `status`          enum('available','rented','inactive') NOT NULL DEFAULT 'available',
  `pets_allowed`    tinyint(1) NOT NULL DEFAULT 0,
  `pet_conditions`  varchar(255) NOT NULL DEFAULT 'None',  -- 'None' unless pets_allowed = 1
  `parking`         enum('none','free','paid') NOT NULL DEFAULT 'none',
  `created_at`      timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`property_id`),
  UNIQUE KEY `uq_properties_code` (`property_code`),
  KEY `idx_properties_owner` (`owner_id`),
  KEY `idx_properties_type`  (`type_id`),
  KEY `idx_properties_city`  (`city_id`),
  CONSTRAINT `fk_properties_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `fk_properties_type` FOREIGN KEY (`type_id`) REFERENCES `property_types` (`type_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `fk_properties_city` FOREIGN KEY (`city_id`) REFERENCES `cities` (`city_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `chk_properties_price` CHECK (`price` >= 0),
  CONSTRAINT `chk_properties_pet_conditions` CHECK (`pets_allowed` = 1 OR `pet_conditions` = 'None')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `property_images` (
  `image_id`    int unsigned NOT NULL AUTO_INCREMENT,
  `property_id` int unsigned NOT NULL,
  `image_path`  varchar(255) NOT NULL,
  `is_primary`  tinyint(1) NOT NULL DEFAULT 0,
  `sort_order`  smallint unsigned NOT NULL DEFAULT 0,
  `created_at`  timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`image_id`),
  KEY `idx_property_images_property` (`property_id`),
  CONSTRAINT `fk_property_images_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `property_amenities` (
  `property_id` int unsigned NOT NULL,
  `amenity_id`  smallint unsigned NOT NULL,
  PRIMARY KEY (`property_id`, `amenity_id`),
  KEY `idx_property_amenities_amenity` (`amenity_id`),
  CONSTRAINT `fk_pa_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_pa_amenity` FOREIGN KEY (`amenity_id`) REFERENCES `amenities` (`amenity_id`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One row per property per utility.
--   included    = covered by the rent        (old value 1)
--   separate    = tenant pays separately      (old value 0)
--   unavailable = property does not have it   (old value 2, used for internet)
CREATE TABLE `property_utilities` (
  `property_id` int unsigned NOT NULL,
  `utility_id`  tinyint unsigned NOT NULL,
  `coverage`    enum('included','separate','unavailable') NOT NULL DEFAULT 'separate',
  PRIMARY KEY (`property_id`, `utility_id`),
  KEY `idx_property_utilities_utility` (`utility_id`),
  CONSTRAINT `fk_pu_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_pu_utility` FOREIGN KEY (`utility_id`) REFERENCES `utilities` (`utility_id`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Nearby-place tags the owner types for a property (max 8), e.g. hospital, mall, school.
CREATE TABLE `tags` (
  `tag_id`   int unsigned NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(30) NOT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `uq_tags_name` (`tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `property_tags` (
  `property_id` int unsigned NOT NULL,
  `tag_id`      int unsigned NOT NULL,
  `sort_order`  tinyint unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`property_id`, `tag_id`),
  KEY `idx_property_tags_tag` (`tag_id`),
  CONSTRAINT `fk_pt_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_pt_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`tag_id`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `favorites` (
  `user_id`     int unsigned NOT NULL,
  `property_id` int unsigned NOT NULL,
  `created_at`  timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`, `property_id`),
  KEY `idx_favorites_property` (`property_id`),
  CONSTRAINT `fk_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_favorites_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- total_amount is kept as a price snapshot at booking time, so later price
-- changes on the property do not rewrite history. The night count is not stored:
-- when check_out is a date it is DATEDIFF(check_out, check_in); otherwise there are none.
CREATE TABLE `bookings` (
  `booking_id`     int unsigned NOT NULL AUTO_INCREMENT,
  `user_id`        int unsigned NOT NULL,
  `property_id`    int unsigned NOT NULL,
  `check_in`       date NOT NULL,
  `check_out`      varchar(20) NOT NULL DEFAULT 'Not checked out',  -- 'YYYY-MM-DD' or the words 'Not checked out' (monthly stay)
  `guests`         tinyint unsigned NOT NULL DEFAULT 1,
  `total_amount`   decimal(10,2) NOT NULL,
  `booking_status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at`     timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`booking_id`),
  KEY `idx_bookings_user`     (`user_id`),
  KEY `idx_bookings_property` (`property_id`, `check_in`),
  CONSTRAINT `fk_bookings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `fk_bookings_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `chk_bookings_dates` CHECK (`check_out` = 'Not checked out' OR `check_out` REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'),
  CONSTRAINT `chk_bookings_guests` CHECK (`guests` >= 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payments` (
  `payment_id`     int unsigned NOT NULL AUTO_INCREMENT,
  `booking_id`     int unsigned NOT NULL,
  `method_id`      tinyint unsigned NOT NULL,             -- the 'Pending' method until the user picks one
  `amount`         decimal(10,2) NOT NULL,
  `payment_status` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  `paid_at`        varchar(30) NOT NULL DEFAULT 'Not paid',   -- 'YYYY-MM-DD HH:MM:SS' or the words 'Not paid'
  `created_at`     timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`payment_id`),
  KEY `idx_payments_booking` (`booking_id`),
  KEY `idx_payments_method`  (`method_id`),
  CONSTRAINT `fk_payments_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_payments_method` FOREIGN KEY (`method_id`) REFERENCES `payment_methods` (`method_id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `chk_payments_amount` CHECK (`amount` >= 0),
  CONSTRAINT `chk_payments_paid_at` CHECK (`paid_at` = 'Not paid' OR `paid_at` REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
